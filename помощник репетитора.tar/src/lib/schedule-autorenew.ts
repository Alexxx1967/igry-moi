// Schedule auto-renewal logic — shared between the API endpoint and the
// dashboard (called directly, no self-fetch).

import { db } from "@/lib/db";
import { addDays, endOfMonth, monthOf, startOfMonth, todayInTZ } from "@/lib/tz";
import { getSettings } from "@/lib/report";

/**
 * Automatically extend recurring ("weekly") lessons into the NEXT month if
 * the latest lesson is still in the current month (or earlier). Idempotent:
 * skips any (student, date, timeStart) that already exists.
 *
 * Returns a summary of what was created.
 */
export async function autorenewSchedule(): Promise<{
  renewed: boolean;
  nextMonth?: string;
  created?: number;
  reason?: string;
}> {
  const settings = await getSettings();
  const tz = settings.timezone;
  const today = todayInTZ(tz);
  const currentMonth = monthOf(today);

  // Find the latest lesson date.
  const latest = await db.lesson.findFirst({
    orderBy: { date: "desc" },
    select: { date: true },
  });
  if (!latest) {
    return { renewed: false, reason: "no lessons" };
  }
  const latestMonth = monthOf(latest.date);
  // Only renew if the latest lesson is in the current month (or earlier) —
  // i.e. next month hasn't been pre-generated yet.
  if (latestMonth > currentMonth) {
    return { renewed: false, reason: `already extends to ${latestMonth}` };
  }

  // Determine the next month to generate.
  const nextMonthStart = addDays(endOfMonth(currentMonth), 1);
  const nextMonth = monthOf(nextMonthStart);
  const nextMonthEnd = endOfMonth(nextMonth);

  // Collect distinct (studentId, weekday, timeStart, ...) from recurring
  // lessons in the latest month (template).
  const templateStart = startOfMonth(latestMonth);
  const templateEnd = endOfMonth(latestMonth);
  const templates = await db.lesson.findMany({
    where: {
      recurring: "weekly",
      date: { gte: templateStart, lte: templateEnd },
    },
    select: {
      studentId: true,
      date: true,
      timeStart: true,
      durationMinutes: true,
      subject: true,
      format: true,
      price: true,
      link: true,
    },
  });

  // Build a set of unique slots: key = studentId|weekday|timeStart
  const slotMap = new Map<string, any>();
  for (const t of templates) {
    const [y, m, d] = t.date.split("-").map(Number);
    const wd = new Date(Date.UTC(y, m - 1, d)).getUTCDay(); // 0=Sun..6=Sat
    const key = `${t.studentId}|${wd}|${t.timeStart}`;
    if (!slotMap.has(key)) {
      slotMap.set(key, { ...t, weekday: wd });
    }
  }

  // For each slot, find all matching weekdays in next month and create lessons.
  const toCreate: Array<{
    date: string;
    timeStart: string;
    durationMinutes: number;
    studentId: string;
    subject: string;
    format: string;
    link: string | null;
    price: number;
    paidAmount: number;
    lessonStatus: string;
    paymentStatus: string;
    recurring: string | null;
  }> = [];

  const [ny, nm] = nextMonth.split("-").map(Number);
  const daysInNextMonth = new Date(Date.UTC(ny, nm, 0)).getUTCDate();
  for (let day = 1; day <= daysInNextMonth; day++) {
    const d = new Date(Date.UTC(ny, nm - 1, day));
    const wd = d.getUTCDay(); // 0=Sun..6=Sat
    const dateStr = `${ny}-${String(nm).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
    for (const slot of slotMap.values()) {
      if (slot.weekday !== wd) continue;
      // Skip weekends (0=Sun, 6=Sat) — tutor works Mon-Fri only.
      if (wd === 0 || wd === 6) continue;
      toCreate.push({
        date: dateStr,
        timeStart: slot.timeStart,
        durationMinutes: slot.durationMinutes,
        studentId: slot.studentId,
        subject: slot.subject,
        format: slot.format,
        link: slot.link,
        price: slot.price,
        paidAmount: 0,
        lessonStatus: "planned",
        paymentStatus: "unpaid",
        recurring: "weekly",
      });
    }
  }

  // Deduplicate against existing lessons in next month.
  const existing = await db.lesson.findMany({
    where: { date: { gte: nextMonthStart, lte: nextMonthEnd } },
    select: { studentId: true, date: true, timeStart: true },
  });
  const existingKeys = new Set(
    existing.map((e) => `${e.studentId}|${e.date}|${e.timeStart}`)
  );
  const filtered = toCreate.filter(
    (l) => !existingKeys.has(`${l.studentId}|${l.date}|${l.timeStart}`)
  );

  if (filtered.length > 0) {
    await db.lesson.createMany({ data: filtered });
  }

  return {
    renewed: true,
    nextMonth,
    created: filtered.length,
  };
}
