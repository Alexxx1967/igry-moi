import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json();
  const data: any = {};
  if (body.name !== undefined) data.name = String(body.name).trim();
  if (body.phone !== undefined) data.phone = body.phone || null;
  if (body.email !== undefined) data.email = body.email || null;
  if (body.grade !== undefined) data.grade = body.grade || null;
  if (body.pricePerLesson !== undefined)
    data.pricePerLesson = body.pricePerLesson ? Number(body.pricePerLesson) : null;
  if (body.comment !== undefined) data.comment = body.comment || null;
  if (body.color !== undefined) data.color = body.color;

  const updated = await db.student.update({ where: { id }, data });
  return NextResponse.json(updated);
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await db.student.delete({ where: { id } }).catch(() => {});
  return NextResponse.json({ ok: true });
}
