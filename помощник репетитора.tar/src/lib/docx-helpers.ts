// Word document helpers: read .docx text (mammoth) and generate report .docx (docx).
import mammoth from "mammoth";
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  AlignmentType,
  Table,
  TableRow,
  TableCell,
  WidthType,
  BorderStyle,
  ShadingType,
} from "docx";

/** Extract plain text from a .docx Buffer. */
export async function extractDocxText(buffer: Buffer): Promise<string> {
  const result = await mammoth.extractRawText({ buffer });
  return result.value || "";
}

type ReportSection = {
  heading?: string;
  paragraphs?: string[];
  table?: { headers: string[]; rows: string[][] };
};

/**
 * Build a .docx Buffer from a report title + sections. Used for downloading
 * daily/weekly/monthly/yearly reports as Word documents.
 */
export async function buildReportDocx(
  title: string,
  subtitle: string,
  sections: ReportSection[]
): Promise<Buffer> {
  const children: (Paragraph | Table)[] = [];

  // Title
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 120 },
      children: [
        new TextRun({
          text: title,
          bold: true,
          size: 32, // 16pt
          font: "Calibri",
        }),
      ],
    })
  );
  // Subtitle
  children.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { after: 320 },
      children: [
        new TextRun({
          text: subtitle,
          italics: true,
          size: 22, // 11pt
          color: "666666",
          font: "Calibri",
        }),
      ],
    })
  );

  for (const section of sections) {
    if (section.heading) {
      children.push(
        new Paragraph({
          heading: HeadingLevel.HEADING_2,
          spacing: { before: 280, after: 120 },
          children: [
            new TextRun({
              text: section.heading,
              bold: true,
              size: 26, // 13pt
              font: "Calibri",
              color: "047857", // emerald-700
            }),
          ],
        })
      );
    }
    if (section.paragraphs) {
      for (const p of section.paragraphs) {
        children.push(
          new Paragraph({
            spacing: { after: 80, line: 312 },
            children: [new TextRun({ text: p, size: 22, font: "Calibri" })],
          })
        );
      }
    }
    if (section.table) {
      children.push(buildTable(section.table.headers, section.table.rows));
      children.push(new Paragraph({ spacing: { after: 120 }, children: [] }));
    }
  }

  const doc = new Document({
    creator: "Ассистент репетитора",
    title,
    sections: [
      {
        properties: {
          page: {
            margin: { top: 1134, right: 1134, bottom: 1134, left: 1134 },
          },
        },
        children,
      },
    ],
  });

  return Packer.toBuffer(doc) as Promise<Buffer>;
}

function buildTable(headers: string[], rows: string[][]): Table {
  const borderProps = {
    top: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
    bottom: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
    left: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
    right: { style: BorderStyle.SINGLE, size: 1, color: "CCCCCC" },
  };
  const headerRow = new TableRow({
    tableHeader: true,
    children: headers.map(
      (h) =>
        new TableCell({
          shading: { type: ShadingType.CLEAR, fill: "D1FAE5", color: "auto" },
          margins: { top: 60, bottom: 60, left: 80, right: 80 },
          children: [
            new Paragraph({
              children: [
                new TextRun({
                  text: h,
                  bold: true,
                  size: 20,
                  font: "Calibri",
                  color: "065F46",
                }),
              ],
            }),
          ],
        })
    ),
  });
  const bodyRows = rows.map(
    (row) =>
      new TableRow({
        cantSplit: true,
        children: row.map(
          (cell) =>
            new TableCell({
              margins: { top: 50, bottom: 50, left: 80, right: 80 },
              children: [
                new Paragraph({
                  children: [
                    new TextRun({ text: cell, size: 20, font: "Calibri" }),
                  ],
                }),
              ],
            })
        ),
      })
  );
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: borderProps,
    rows: [headerRow, ...bodyRows],
  });
}

/** Parse a multi-line report text into sections for nicer Word formatting. */
export function textToSections(text: string): ReportSection[] {
  const sections: ReportSection[] = [];
  const lines = text.split("\n");
  let currentParagraphs: string[] = [];

  const flush = () => {
    if (currentParagraphs.length > 0) {
      sections.push({ paragraphs: currentParagraphs });
      currentParagraphs = [];
    }
  };

  for (const raw of lines) {
    const line = raw.trimEnd();
    if (!line) {
      flush();
      continue;
    }
    // Detect headings: lines without "-" prefix that end with ":"
    if (!line.startsWith("-") && line.endsWith(":") && line.length < 60) {
      flush();
      sections.push({ heading: line });
    } else {
      currentParagraphs.push(line);
    }
  }
  flush();
  return sections;
}
