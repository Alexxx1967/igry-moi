# Worklog — Ассистент репетитора

---
Task ID: 1
Agent: main (Z.ai Code)
Task: Построить комплексного личного ассистента онлайн-репетитора (напоминания о занятиях, учёт оплат, ежедневные и еженедельные отчёты, мягкие напоминания ученикам, парсинг расписания из текста).

Work Log:
- Спроектирована и применена Prisma-схема: модели Student, Lesson, Setting (SQLite).
- Созданы серверные lib-модули: constants.ts (enums/labels/цвета/настройки), tz.ts (часовые пояса, даты, деньги), report.ts (getSettings/saveSettings, buildDailyReport, buildWeeklyReport), reminders.ts (тиры напоминаний 24ч/1ч/15мин, тексты), llm.ts (parseScheduleText, generateStudentPaymentReminder, generateWeeklySummary через z-ai-web-dev-sdk), types.ts, api-client.ts, hooks.ts (TanStack Query).
- API-маршруты: /api/lessons (+[id]), /api/students (+[id]), /api/payments/[id], /api/reports/daily, /api/reports/weekly, /api/reports/summary, /api/settings, /api/dashboard, /api/seed, /api/parse-schedule, /api/reminder.
- Фронтенд (один маршрут /): оболочка с боковой навигацией (десктоп) + горизонтальной навигацией (мобильный), sticky-футер с часами/часовым поясом/долгом, переключатель тёмной темы.
- Секции: Сегодня (дашборд со статистикой, карточкой следующего занятия, напоминаниями, должниками), Расписание (недельная сетка + детали дня + парсинг текста), Оплаты (должники/неоплачено/ожидает подтверждения, отметка оплаты, генерация напоминания), Отчёты (ежедневный и еженедельный в точном формате спецификации + ИИ-итог недели), Ученики (карточки со статистикой и долгами), Настройки (часовой пояс, время отчётов, тумблеры напоминаний, демо-данные).
- Сид-данные: 6 учеников и ~63 занятия в окне ±7 дней от сегодня (Europe/Moscow), включая должников и частичные оплаты.
- Линт чист (eslint 0 ошибок), dev-сервер работает на 3000.

Self-verification (Agent Browser):
- Дашборд рендерится: 5 занятий сегодня, долг 4 000 ₽, 3 должника, напоминания с корректными тирами.
- LLM-парсинг расписания: «Завтра в 11:00 Сергей Волков…» → 2026-09-18 11:00; «Пятница 16:00 Анна Иванова…» → 2026-09-20 16:00. Распознано 2 занятия, импорт доступен.
- Отметка оплаты: клик «Оплачено» уменьшает список должников, появляется тост подтверждения.
- Напоминание об оплате: предзаполненный мягкий текст + «Улучшить через ИИ» даёт вежливое персонализированное сообщение.
- Ежедневный отчёт: точный формат спецификации (всего/проведено/отменено/оплачено, суммы, список занятий, должники, завтра).
- Еженедельный отчёт: разбивка по дням недели, должники, ИТог; ИИ-итог недели работает.
- Создание занятия end-to-end: форма с дефолтной датой=сегодня, выбор ученика, предмет → занятие появляется в расписании.
- Тёмная тема переключается (html.dark).
- Мобильный viewport 390×844: горизонтальная навигация, контент адаптируется.
- Sticky-футер: root min-h-screen flex-col + footer mt-auto (структура подтверждена).
- Ошибок в консоли браузера и dev.log нет.

Stage Summary:
- Готово production-ready приложение «Ассистент репетитора» на Next.js 16 + TypeScript + Prisma/SQLite + shadcn/ui + TanStack Query + z-ai-web-dev-sdk.
- Часовой пояс по умолчанию Europe/Moscow (настраивается), отчёты в 21:00, еженедельный — воскресенье 21:00 (настраивается).
- Все ключевые потоки проверены через Agent Browser: дашборд, расписание, парсинг текста ИИ, оплаты, напоминания ученикам ИИ, отчёты (день/неделя + ИИ-итог), настройки, тёмная тема, мобильная адаптивность, sticky-футер.
- Артефакты: src/app/page.tsx, src/app/api/**, src/lib/**, src/components/**, prisma/schema.prisma.

---
Task ID: 2
Agent: main (Z.ai Code)
Task: Добавить ежемесячный отчёт (в последний день месяца), кнопку годового отчёта, кнопку «Оплата за месяц» у каждого ученика с отсчётом проведённых/оставшихся занятий, ежедневное напоминание о подаче данных в налоговую.

Work Log:
- Схема БД: добавлена модель MonthlyPayment (studentId, month YYYY-MM, lessonsCount, amount, paid, paidAt, comment) с уникальным индексом [studentId, month]. prisma db:push + regenerate.
- constants.ts: добавлены SETTING_KEYS (monthlyReportTime, taxReminderTime, taxReminderLastDone, taxReminderEnabled) и DEFAULT_SETTINGS.
- types.ts: добавлены типы MonthlyPaymentInfo, MonthlyPayment, MonthlyReport, YearlyReport, TaxReminderStatus; StudentWithStats.monthPrepaid; Settings расширен.
- tz.ts: добавлены хелперы monthOf, startOfMonth, endOfMonth, nextMonth, prevMonth, monthLabel, monthShortLabel, monthWeeks, isLastDayOfMonth, monthsOfYear.
- report.ts: расширены getSettings/saveSettings (новые поля); добавлены getMonthlyPaymentsForMonth, getStudentMonthlyPayment, computeMonthlyPaymentInfo (проведено/осталось/запланировано за месяц), upsertMonthlyPayment, deleteMonthlyPayment, buildMonthlyReport (с предоплатами, по неделям, по ученикам с prepaid-инфо), buildYearlyReport (по месяцам с доходом), getTaxReminderStatus (due = текущее время >= reminder time и не done сегодня), markTaxReminderDone, undoTaxReminderDone.
- API: /api/reports/monthly, /api/reports/yearly, /api/monthly-payments (GET/POST), /api/monthly-payments/[id] (DELETE), /api/tax-reminder (GET), /api/tax-reminder/done (POST), /api/tax-reminder/undo (POST). Обновлены /api/students (monthPrepaid в ответе) и /api/dashboard (taxReminder в ответе).
- hooks.ts: useMonthlyReport, useYearlyReport, useMonthlyPayments, useUpsertMonthlyPayment, useDeleteMonthlyPayment, useTaxReminder, useMarkTaxDone, useUndoTaxDone.
- Сид: добавлены предоплаты за текущий месяц для Марии Смирновой (8 зан./12000₽), Дарьи Новиковой (8/9600), Павла Орлова (4/7200).
- UI monthly-payment-dialog.tsx: диалог с количеством занятий, суммой, тумблером «оплачено», комментарием; показывает оплачено/проведено/осталось; удаление с подтверждением.
- UI students-section.tsx: кнопка «Оплата за месяц» (или «Изменить») на каждой карточке + блок прогресса с прогресс-баром (оплачено N, проведено M, осталось K / лимит исчерпан); заголовок секции показывает сумму предоплат за месяц.
- UI reports-section.tsx: добавлены табы «Месяц» и «Год»; MonthlyReportView (статистика, деньги с предоплатами, по неделям, предоплаты с отсчётом, должники, по ученикам, текст); YearlyReportView (по месяцам с доходом, по ученикам, текст). Копирование текста отчёта.
- UI today-section.tsx: карточка «Налоговая» с состояниями (напоминание появится / Подайте данные / Сегодня подано) и кнопками «Подал(а)» / «Отменить».
- UI settings-section.tsx: поле «Время ежемесячного отчёта (в последний день месяца)» + отдельная карточка «Налоговая» с тумблером включения и временем напоминания.
- Lint чист, dev-сервер работает.

Self-verification (Agent Browser):
- Дашборд: карточка «Налоговая» видна, кнопка «Подал(а)» переключает на «Сегодня данные поданы / Отменить».
- Ученики: 3 ученика с предоплатами показывают «Осталось 5/1/2» с прогресс-баром; заголовок: «Предоплаты за Сентябрь 2026: 28 800 ₽»; создание предоплаты через диалог (Анна Иванова, 8 зан./12000₽) — появляется «Осталось 2».
- Отчёт «Месяц»: «Ежемесячный отчёт за Сентябрь 2026», 63 занятий, 30 проведено, оплата по занятиям 43 200 ₽, предоплаты 28 800 → 40 800 ₽ (после добавления), всего получено 72 000 → 84 000 ₽; по неделям; предоплаты с отсчётом «проведено 6, осталось 2»; должники; итог.
- Отчёт «Год»: «Ежегодный отчёт за 2026 год», по месяцам с доходом, по ученикам, итог.
- Настройки: поле времени месячного отчёта + карточка «Налоговая» с тумблером и временем.
- Sticky-футер корректен, ошибок в консоли и dev.log нет.

Stage Summary:
- Добавлены: ежемесячный отчёт (формируется в последний день месяца в указанное время), годовой отчёт по кнопке, предоплаты за месяц с отсчётом проведено/осталось по каждому ученику (кнопка «Оплата за месяц» + диалог + прогресс-бар, данные учитываются в месячном и годовом отчётах), ежедневное напоминание о подаче данных в налоговую (карточка на дашборде с кнопкой «Подал(а)», сбрасывается каждый день, настраивается время и вкл/выкл).
- Часовой пояс Europe/Moscow, по умолчанию: месячный отчёт в 21:00 в последний день месяца, налоговое напоминание в 20:00 ежедневно.
- Все новые потоки проверены через Agent Browser end-to-end.

---
Task ID: 3
Agent: main (Z.ai Code)
Task: Добавить остаток неизрасходованных предоплат с переносом на следующий месяц, поле «класс» у ученика, загрузку расписания и учеников документом Word, скачивание отчётов в Word.

Work Log:
- Схема: добавлено поле `grade` (String?) в модель Student. prisma db:push.
- types.ts: добавлены PrepaymentBalanceItem; StudentWithStats.grade + prepaymentBalance[] + prepaymentBalanceTotal; MonthlyReport.carryoverBalanceTotal + byStudent.carryoverBalance.
- report.ts: добавлена getStudentPrepaymentBalance(studentId, upToMonth) — для каждого прошлого месяца с предоплатой считает unusedLessons = max(0, lessonsCount - conductedThisMonth), perLessonPrice = amount/lessonsCount, unusedMoney. buildMonthlyReport обновлён: считает carryover для каждого ученика, добавляет в текст «Остались деньги с прошлых месяцев» с детализацией, возвращает carryoverBalanceTotal.
- API students GET: возвращает grade + prepaymentBalance + prepaymentBalanceTotal; POST/PATCH: принимает grade.
- Установлены пакеты docx (создание) и mammoth (чтение).
- lib/docx-helpers.ts: extractDocxText (mammoth), buildReportDocx (docx: заголовок, подзаголовок, секции с заголовками/параграфами, таблицы с emerald-шапкой), textToSections (разбор текста отчёта на секции).
- API docx-отчёты: /api/reports/{daily,weekly,monthly,yearly}/docx — генерируют .docx и отдают как attachment.
- API загрузки: /api/upload/docx-schedule (mammoth → parseScheduleText), /api/upload/docx-students (mammoth → parseStudentsText).
- llm.ts: добавлена parseStudentsText (имя/телефон/email/класс/комментарий из текста).
- Сид: добавлен grade для всех учеников; добавлены предоплаты за прошлый месяц (август) для Марии Смирновой и Дарьи Новиковой → демонстрация carryover.
- hooks.ts: useUploadDocxSchedule, useUploadDocxStudents, downloadReportDocx, ParsedStudent.
- UI student-form-dialog: поле «Класс / курс» (Input) рядом с цветом метки.
- UI students-section: класс в подзаголовке карточки; блок «Остались деньги с прошлых месяцев» (sky-цвет) с суммой и детализацией по месяцам; кнопка «Из Word» в шапке секции.
- UI upload-word-students-dialog: загрузка .docx → ИИ-распознавание → выбор учеников → импорт.
- UI parse-schedule-dialog: добавлена кнопка «Загрузить из Word (.docx)» над текстовым полем.
- UI reports-section: WordDownloadButton рядом с CopyButton во всех 4 отчётах (день/неделя/месяц/год); в месячном отчёте отображается carryoverBalanceTotal и блок «Остались деньги с прошлых месяцев».
- Lint чист, dev-сервер работает.

Self-verification (Agent Browser):
- Ученики: классы видны («9 класс», «11 класс», «7 класс»); блок «Остались деньги с прошлых месяцев: 9 600 ₽ / 12 000 ₽» с детализацией «с Август 2026 — 9 600 ₽ (8 из 8 занятий не проведено)».
- Месячный отчёт: «Остаток с прошлых месяцев: 21 600 ₽» + отдельный блок «Остались деньги с прошлых месяцев» с разбивкой по ученикам и месяцам.
- API /api/upload/docx-students: тестовый .docx → распознаны 3 ученика (имя, класс, телефон, email, комментарий).
- API /api/upload/docx-schedule: тестовый .docx → распознаны 3 занятия (Завтра→18.09, Пятница→20.09, Понедельник→22.09).
- API /api/reports/daily/docx и /monthly/docx: валидные .docx (Microsoft Word 2007+), 9 КБ.
- Кнопка «Word» в каждом отчёте скачивает .docx.
- Диалог «Из Word» у учеников и «Загрузить из Word» в расписании работают.
- Sticky-футер корректен, ошибок в консоли и dev.log нет.

Stage Summary:
- Добавлены: (1) остаток неизрасходованных предоплат с переносом на следующий месяц — отдельный блок на карточке ученика и в месячном отчёте с детализацией по месяцам; (2) поле «класс/курс» у ученика в форме и на карточке; (3) загрузка расписания и учеников из .docx через ИИ-распознавание (mammoth + LLM); (4) скачивание всех отчётов (день/неделя/месяц/год) в формат Word (.docx) с заголовками, секциями и таблицами.
- Все новые потоки проверены через Agent Browser end-to-end и через прямые API-вызовы.

---
Task ID: 4
Agent: main (Z.ai Code)
Task: Сделать приложение для Android (PWA) и настроить браузерные оповещения обо всех событиях.

Work Log:
- Сгенерирована иконка приложения (image-generation skill, 1024×1024) + варианты через sharp: icon-192, icon-512, icon-192-maskable, icon-512-maskable, apple-touch-icon, favicon-32.
- public/manifest.json: name/short_name, start_url=/, display=standalone, theme_color=#059669, background_color=#fff, lang=ru, icons (any + maskable 192/512), shortcuts (Расписание/Оплаты/Отчёты).
- public/sw.js: сервис-воркер — precache app shell, network-first для navigations, stale-while-revalidate для статики, обработка push + postMessage SHOW_NOTIFICATION, notificationclick (фокус/навигация).
- src/app/layout.tsx: добавлены manifest, themeColor (viewport), appleWebApp, icons; компонент ServiceWorkerRegister.
- src/components/sw-register.tsx: регистрация /sw.js на клиенте.
- src/app/api/notifications/feed/route.ts: агрегирует все подлежащие оповещению события со стабильными key для дедупликации: lesson_24h/1h/15min/now (по tier), tax (due), daily_report (>= dailyReportTime), weekly_report (день+время), monthly_report (последний день месяца+время), debt (есть должники).
- src/lib/use-notifications.ts: хук useNotifications — requestPermission, toggleEnabled, поллинг /api/notifications/feed каждые 60с, fireNotification через SW (postMessage) или fallback new Notification, дедупликация через localStorage (ta:notifSent, хранит 7 дней), recent-список + unread-счётчик, обработка ta:navigate из notificationclick.
- src/components/notification-bell.tsx: колокольчик в шапке с badge непрочитанных, dropdown с последними оповещениями, кнопка запроса разрешения, тумблер вкл/выкл.
- src/components/notification-settings.tsx: карточка в Настройках — «Приложение для телефона (Android)» с кнопкой Установить (beforeinstallprompt/appinstalled) + «Браузерные оповещения» с кнопкой Разрешить/Включить.
- src/app/page.tsx: NotificationBell в шапке; обработка ?section= из URL (PWA shortcuts) и ta:navigate из клика по оповещению.
- Lint чист, dev-сервер работает.

Self-verification (Agent Browser + API):
- manifest.json: 200, sw.js: 200, icon-192.png: 200.
- В браузере: link[rel=manifest] подключён, meta theme-color=#059669, navigator.serviceWorker.controller = true (SW зарегистрирован).
- /api/notifications/feed: 6 items (5 lesson_24h + 1 debt) с корректными title/body/key.
- Шапка: кнопка «Оповещения» (колокольчик) рядом с темой.
- Настройки: карточка «Оповещения и приложение» с кнопками «Установить» (Android PWA) и «Разрешить» (браузерные оповещения).
- Мобильный viewport 390×844: sticky-футер корректен, манифест подключён.
- Ошибок в консоли и dev.log нет. (В headless Agent Browser Notification.permission=denied — ожидаемо; на реальном Android/Chrome покажет стандартный диалог разрешения.)

Stage Summary:
- Приложение стало PWA: устанавливается на Android как нативное (иконка на главном экране, запуск в standalone-режиме, оффлайн-старт через SW, маскируемые иконки, shortcuts).
- Браузерные оповещения обо всех событиях: напоминания о занятиях (24ч/1ч/15мин/сейчас), ежедневный/еженедельный/ежемесячный отчёты готовы, налоговая, должники. Дедупликация по key, поллинг каждые 60с, показ через сервис-воркер (работает даже при свёрнутом приложении на Android).
- Колокольчик с непрочитанными в шапке + центр оповещений; карточка настроек с установкой PWA и управлением оповещениями.

---
Task ID: 5
Agent: main (Z.ai Code)
Task: Сделать ссылку/QR для скачивания приложения, синхронизацию браузер↔приложение, каналы оповещений MAX и ВКонтакте с настройками выбора куда посылать.

Work Log:
- Схема: добавлена модель NotificationLog (key, channel, sentAt, unique [key,channel]) для дедупликации внешних каналов. prisma db:push.
- constants.ts: добавлены SETTING_KEYS (browserNotifEnabled, maxEnabled, maxBotToken, maxChatId, vkEnabled, vkAccessToken, vkPeerId) + DEFAULT_SETTINGS.
- types.ts: Settings расширен полями каналов; добавлен NotifChannel = "browser"|"max"|"vk".
- report.ts: getSettings/saveSettings обновлены для новых полей.
- lib/notifications-channels.ts (новый): dispatchNotification (MAX через botapi.max.ru POST /messages?access_token + body {chat_id,text}; VK через api.vk.com/method/messages.send с access_token/peer_id/message/v/random_id), dispatchMany (для фида), sendTestMessage, дедупликация через NotificationLog (alreadySent/markSent).
- API /api/notifications/feed: после формирования items вызывает dispatchMany для включённых внешних каналов, возвращает channels: {max, vk, dispatched, failed}.
- API /api/notifications/test (POST): отправляет тестовое сообщение во все включённые внешние каналы.
- API /api/qr (GET ?url=): генерирует PNG QR-код (qrcode, emerald #059669, 480px) для ссылки на приложение.
- lib/use-sync-tabs.ts (новый): useSyncTabs (BroadcastChannel ta:sync + refetch on focus/visibility) + broadcastInvalidate(). providers.tsx подключает SyncManager.
- hooks.ts: все ключевые мутации (create/update/delete lesson, payment, student, settings, seed) вызывают broadcastInvalidate() → браузер и PWA-приложение обновляются в реальном времени.
- notification-settings.tsx (переписан): блок «Приложение для телефона» с QR-кодом + ссылкой + кнопкой Установить; блок «Куда отправлять оповещения» с тремя каналами: Браузер (toggle), MAX (switch + поля Токен бота/Chat ID), ВКонтакте (switch + поля Access token/Peer ID); кнопка «Отправить тестовое оповещение».
- Lint чист, dev-сервер работает.

Self-verification (Agent Browser + API):
- /api/qr?url=/: 200, PNG 2.8 КБ (валидный QR 480×480).
- /api/notifications/test: 400 с понятной ошибкой «Ни один внешний канал не включён» (без токенов).
- /api/notifications/feed: возвращает items (6) + channels {max:false, vk:false, dispatched:0, failed:0}.
- Настройки: QR-код рендерится (naturalWidth 480), ссылка на приложение видна, кнопка «Установить».
- Блок «Куда отправлять оповещения»: Браузер/MAX/ВКонтакте; включение MAX разворачивает «Токен бота MAX» + «Chat ID»; включение ВК — «Access token ВКонтакте» + «Peer ID».
- Кнопка «Отправить тестовое оповещение» disabled пока каналы выключены, с подсказкой.
- Синхронизация: BroadcastChannel поддерживается, serviceWorker активен, broadcastInvalidate подключён ко всем мутациям.
- Sticky-футер корректен, ошибок в консоли и dev.log нет.

Stage Summary:
- Ссылка и QR-код для скачивания/установки приложения: QR-код (emerald) ведёт на URL приложения, ссылка с кнопкой «Копировать», инструкция по установке на Android через Chrome.
- Синхронизация браузер↔приложение в реальном времени: данные общие (единый бэкенд), BroadcastChannel + refetch-on-focus мгновенно обновляют оба контекста при любом изменении (добавил занятие в браузере → появилось в PWA-приложении и наоборот).
- Каналы оповещений MAX и ВКонтакте: в Настройках блок «Куда отправлять оповещения» с тумблерами для Браузер/MAX/ВКонтакте, полями для токенов и ID, кнопкой «Отправить тестовое оповещение». Серверный диспетчер отправляет во все включённые каналы с дедупликацией (NotificationLog).

---
Task ID: 6
Agent: main (Z.ai Code)
Task: Сделать скачивание приложения в формате APK + кнопку удаления всех учеников (для загрузки новых).

Work Log:
- API DELETE /api/students/all: удаляет всех учеников + их занятия + предоплаты (через deleteMany в правильном порядке), возвращает counts. cascade-безопасно.
- API GET /api/download/apk: генерирует TWA-проект ZIP (jszip) с twa-manifest.json (packageId ru.tutor.assistant, host, иконки, themeColor #059669, shortcuts, enableNotifications), package.json (@bubblewrap/cli), build.sh + build.bat (создают debug-keystore через keytool, npm install, npx bubblewrap build), README.md (вариант 1 — облако pwabuilder.com без установки; вариант 2 — локальная сборка через build.sh/build.bat), .gitignore. Content-Disposition: tutor-assistant-apk.zip.
- hooks.ts: useDeleteAllStudents (вызывает DELETE /api/students/all, invalidate + broadcastInvalidate).
- UI students-section.tsx: кнопка «Удалить всех» (UserX иконка, rose-цвет, disabled при пустом списке) между «Из Word» и «Новый ученик»; диалог подтверждения с предупреждением и счётчиком «Удалено будет: N учеников», кнопка «Да, удалить всех» → тост «Удалено: N учеников, M занятий».
- UI notification-settings.tsx: новый блок «Скачать APK-файл» с кнопкой «Скачать APK» (emerald) + инструкции: Вариант 1 (pwabuilder.com облако), Вариант 2 (распаковать ZIP + build.sh), установка на телефон.
- Lint чист, dev-сервер работает.

Self-verification (Agent Browser + API):
- DELETE /api/students/all: {"ok":true,"deleted":{"students":6,"lessons":63,"monthlyPayments":5}}.
- GET /api/download/apk: 200, application/zip, 3641 bytes, 6 файлов в архиве (twa-manifest.json, package.json, build.sh, build.bat, README.md, .gitignore).
- Кнопка «Удалить всех» в секции Ученики → диалог подтверждения → «Да, удалить всех» → «Всего: 0», «Учеников пока нет», тост «Удалено: 6 учеников, 63 занятий».
- Кнопка «Скачать APK» в Настройках → fetch возвращает 200 application/zip с Content-Disposition attachment; инструкции (pwabuilder.com + build.sh) видны.
- Sticky-футер корректен, ошибок в консоли нет.

Stage Summary:
- Скачивание APK: кнопка «Скачать APK» отдаёт ZIP с готовым TWA-проектом (Bubblewrap) — после распаковки и запуска build.sh/build.bat получается подписанный app-release-signed.apk; либо облачная сборка через pwabuilder.com (без установки инструментов). Прозрачные инструкции на русском.
- Кнопка «Удалить всех» в секции Ученики с подтверждением — очищает всех учеников/занятия/предоплаты одним кликом, чтобы загрузить новых (например, из Word).

---
Task ID: 7
Agent: main (Z.ai Code)
Task: Заменить напоминание за 24ч на 30мин; исправить ошибку загрузки .docx; сделать готовый APK-файл для скачивания.

Work Log:
- Исправлена ошибка загрузки .docx: маршруты /api/upload/docx-schedule и /api/upload/docx-students отсутствовали (404 Server action not found). Воссозданы оба route handlers (multipart formData → mammoth extractDocxText → LLM parseScheduleText/parseStudentsText). Проверено: тестовый .docx → 2 ученика распознаны.
- Также исправлена иконка icon-512.png: была JPEG с расширением .png → конвертирована в настоящий PNG через sharp (aapt отказывался собирать APK с фейковым PNG).
- Напоминание 24ч → 30мин: ReminderTier "24h" → "30min"; reminderTierFor переписан (15мин/30мин/1ч пороги); tierLabel "Предварительное (за 30 мин)"; buildTutorReminder для 30min; SETTING_KEYS.reminder24h → reminder30min; DEFAULT_SETTINGS; Settings.reminder24h → reminder30min; getSettings/saveSettings; notifications/feed type lesson_24h → lesson_30min + titleMap; settings-section ToggleRow "За 30 минут".
- Готовый APK: установлен Android SDK (build-tools 34 + platform 34) + portable JDK 21 (Temurin). Создан lib/apk-builder.ts — собирает реальный подписанный .apk на сервере: генерирует Android-проект (MainActivity открывает origin URL из strings.xml), aapt compile resources → javac → d8 dex → aapt package → zipalign → apksigner sign (debug keystore). Кэш по origin (первая сборка ~3.5с, последующие <10мс).
- /api/download/apk переписан: отдаёт application/vnd.android.package-archive с Content-Disposition tutor-assistant.apk.
- UI notification-settings: кнопка «Скачать APK» с spinner «Сборка...» во время сборки, инструкция по установке .apk на телефон.
- Lint чист, dev-сервер работает.

Self-verification:
- /api/upload/docx-students: 200, 2 ученика распознаны (Иванов Иван 5 класс, Петрова Мария 8 класс).
- /api/settings: reminder30min=true, reminder1h=true, reminder15min=true, reminder24h NOT FOUND.
- UI Настройки: «За 30 минут» (нет «За 24 часа»).
- /api/download/apk: HTTP 200, 217574 bytes, file = "Android package (APK), with AndroidManifest.xml, with APK Signing Block". aapt dump: package ru.tutor.assistant, label Репетитор, иконка, launchable activity. Второй запрос 8мс (кэш).
- apksigner verify: v1+v2+v3 ✓.
- Ошибок в консоли нет, sticky-футер корректен.

Stage Summary:
- Ошибка загрузки .docx исправлена (воссозданы отсутствующие route handlers).
- Напоминание «за 24 часа» заменено на «за 30 минут» во всей системе (tier, настройки, оповещения, лейблы).
- Кнопка «Скачать APK» теперь отдаёт готовый подписанный .apk (217 КБ), собранный сервером на лету с подстановкой URL приложения. Скачивается одним кликом, устанавливается на Android как обычное приложение.

---
Task ID: 8
Agent: main (Z.ai Code)
Task: 4 задачи: (1) фикс установки APK, (2) MAX по телефону + ВК фикс, (3) автогенерация расписания по числам месяца, (4) цена за урок в карточке ученика.

Work Log:
- Схема: Student.pricePerLesson (Int?), Lesson.recurring (String?, "weekly"). prisma db:push.
- Типы: StudentWithStats.pricePerLesson, LessonWithStudent.recurring; Settings.maxPhone + maxChatId (вернул).
- LLM parseScheduleText: добавлено поле recurring ("mon".."sun") — ИИ распознаёт «понедельник/пн/monday» без даты как повторяющееся.
- LLM expandRecurring(): превращает recurring-занятия в конкретные даты — все дни этого дня недели в текущем месяце. Поддержка алиасов (пн→mon, понедельник→mon, и т.д.).
- /api/parse-schedule и /api/upload/docx-schedule: применяют expandRecurring, возвращают rawCount + expandedCount.
- API lessons POST: принимает recurring; если price не указан — наследует из student.pricePerLesson.
- API students GET/POST/PATCH: pricePerLesson.
- Сид: pricePerLesson для всех учеников (1500/2000/1200/1800).
- UI student-form-dialog: поле «Цена за урок, ₽».
- UI students-section: «💰 1 500 ₽ за урок» в блоке контактов.
- UI lesson-form-dialog: чекбокс «Повторять каждую неделю» + автоподстановка цены при выборе ученика.
- MAX: добавлено поле «Ваш номер телефона в MAX» (вместо Chat ID). Создан /api/max/webhook (POST) — автоматически захватывает chat_id когда репетитор пишет боту в MAX, сохраняет в settings.maxChatId. sendToMax использует maxChatId; если пусто — понятная ошибка «напишите боту с номера X». UI: инструкция из 4 шагов + статус «✓ Чат привязан / ⏳ Чат ещё не привязан».
- ВК: добавлены пошаговые инструкции (создать сообщество → токен с правом messages → включить сообщения → Peer ID).
- APK фикс: /api/download/apk теперь использует X-Forwarded-Host/X-Forwarded-Proto для определения публичного origin (через gateway) — APK открывает URL, доступный с телефона. Кэш по origin.
- Lint чист, dev-сервер работает.

Self-verification:
- /api/parse-schedule с «Понедельник/Среда/Пятница»: raw=3 → expanded=13 (все даты сентября 2026 по дням недели).
- /api/students: все ученики имеют pricePerLesson (1500/2000/1200/1800).
- Создание занятия без цены → автоматически 1500 (от ученика).
- /api/max/webhook POST с {message:{recipient:{chat_id:"TEST_CHAT_123"}}} → maxChatId сохранён = TEST_CHAT_123.
- /api/notifications/test: понятные ошибки «Не указан токен бота MAX» / «Не указан access_token ВКонтакте или peer_id».
- /api/download/apk с X-Forwarded-Host: my.tutor.app → APK 217КБ, валидный, URL https://my.tutor.app вшит в strings.xml.
- UI: «1 500 ₽ за урок» на карточках; поле «Номер телефона в MAX» + инструкция webhook; чекбокс «Повторять каждую неделю» в форме занятия.
- Ошибок в консоли нет, sticky-футер корректен.

Stage Summary:
- APK: теперь открывает публичный URL (через X-Forwarded-Host), доступный с телефона — установка должна работать.
- MAX: отправка по номеру телефона — репетитор указывает телефон, пишет боту в MAX, webhook автоматически захватывает chat_id, после чего оповещения идут в чат. Понятные ошибки если токен/chat_id не настроены.
- ВК: пошаговые инструкции для получения токена и peer_id.
- Расписание: при загрузке из Word или текста повторяющиеся занятия (по дням недели) автоматически разворачиваются во все даты текущего месяца.
- Карточка ученика: поле «цена за урок» — используется для автоподстановки в новые занятия и автоподсчёта.

---
Task ID: 9
Agent: main (Z.ai Code)
Task: Загрузить реальных учеников из загруженного расписания 2026-2027.docx, сгенерировать занятия с 1 сентября до конца сентября, отметить проведённые/оплаченные до сегодня, добавить предоплаты и баланс Уткиной за август.

Work Log:
- Извлечён текст из /home/z/my-project/upload/расписание 2026-2027.docx через mammoth: таблица с 7 учениками и занятиями по дням недели (Пн-Пт) с временем и ценой.
- Распарсено расписание вручную:
  • Полина Пчелинцева (1900₽) — Пн 15:45, Чт 16:00
  • Тимофей Курганов (1900₽) — Пн 17:00, Вт 18:30
  • Анна Уткина (2000₽) — Пн 18:15, Чт 18:30
  • Максим Фёдоров (1900₽) — Вт 15:20, Пт 15:20
  • Алиса Усова (2000₽) — Вт 17:00, Чт 17:00
  • Вероника Захарова (1700₽) — Ср 17:30
  • Блинова (2000₽) — Чт 19:00
- Создан /api/seed-schedule: удаляет старые данные, создаёт 7 учеников с pricePerLesson, генерирует занятия на все подходящие дни недели сентября 2026 (1–18 сентября = conducted+paid, 19–30 сентября = planned+unpaid), создаёт 3 предоплаты.
- Предоплаты:
  • Пчелинцева: 2026-09, 10 занятий, 19000₽ (с 14 сентября)
  • Уткина: 2026-09, 9 занятий, 18000₽ (с 17 сентября)
  • Уткина: 2026-08, 2 занятия, 4000₽ (баланс за август — 2 урока не проведено)
- Запущен: 7 учеников, 52 занятия (33 проведено/оплачено, 19 запланировано), 3 предоплаты.

Self-verification:
- Ученики: все 7 с pricePerLesson, Уткина имеет prepaymentBalanceTotal=4000 (баланс августа).
- Занятия 14 сентября (Пн): Полина 15:45, Тимофей 17:00, Анна 18:15 — все conducted+paid.
- Занятия 22 сентября (Вт): Максим 15:20, Алиса 17:00, Тимофей 18:30 — все planned+unpaid.
- Месячный отчёт: 52 занятий, 33 проведено, оплата по занятиям 63500₽, предоплаты 37000₽, всего получено 100500₽, остаток с прошлых месяцев 4000₽, долгов нет.
- Предоплаты с отсчётом: Уткина — проведено 5, осталось 4; Пчелинцева — проведено 5, осталось 5.
- «Остались деньги с прошлых месяцев: Анна Уткина — с Август 2026 — 4000₽ (2 из 2 занятий не проведено)».
- Ошибок в консоли нет.

Stage Summary:
- Реальные ученики из загруженного документа загружены в систему с ценами за урок.
- Расписание сгенерировано на весь сентябрь 2026 по дням недели: 1–18 сентября — проведено и оплачено, 19–30 сентября — запланировано.
- Предоплаты Пчелинцевой (19000₽/10 занятий) и Уткиной (18000₽/9 занятий) за сентябрь добавлены.
- Баланс Уткиной за август (4000₽ за 2 урока) отображается в карточке ученика и в месячном отчёте.

---
Task ID: 10
Agent: main (Z.ai Code)
Task: Исправить расписание (среда/четверг перепутаны), убрать дисциплину из карточки, предоплата Полины считается с 14 сентября.

Work Log:
- Извлечена HTML-таблица из docx через mammoth.convertToHtml — обнаружена ошибка: Полина Пчелинцева и Блинова были в столбце «Четверг», а должны быть в «Среда» (cell index 4 = Ср, не Чт).
- Исправлен seed-schedule: Полина weekday 4→3 (Ср 16:00), Блинова weekday 4→3 (Ср 19:00).
- computeMonthlyPaymentInfo: добавлен учёт paidAt — если дата оплаты указана, conductedThisMonth считается только с paidAt (не с начала месяца). Предоплата покрывает занятия с даты оплаты, а не ретроактивно.
- lesson-item.tsx: убрана строка {lesson.subject} из карточки занятия (дисциплина больше не показывается).
- Перезапущен seed-schedule: 7 учеников, 54 занятия (33 проведено/оплачено, 21 запланировано).

Self-verification:
- Среда 16 сентября: Полина 16:00, Вероника 17:30, Блинова 19:00 ✓
- Четверг 17 сентября: Алиса 17:00, Анна 18:30 ✓
- Предоплата Полины (с 14.09): проведено 2 (14 и 16 сен), осталось 8 из 10 ✓
- Предоплата Анны (с 17.09): проведено 1 (17 сен), осталось 8 из 9 ✓
- Карточка занятия: имя, время, статус, формат, цена — без предмета ✓
- Ошибок в консоли нет.

Stage Summary:
- Расписание исправлено: Полина и Блинова теперь в среду (не в четверг).
- Дисциплина убрана из карточки занятия.
- Предоплата Полины Пчелинцевой (10 уроков, 19000₽) теперь корректно отсчитывается с 14 сентября: 2 проведено, 8 осталось.

---
Task ID: 11
Agent: main (Z.ai Code)
Task: Сделать рабочий APK (совместимый с Android 14) + автопродление расписания каждый месяц.

Work Log:
- APK фикс: добавлен <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="33"/> в AndroidManifest. Раньше targetSdkVersion по умолчанию был 34, что вызывало "несовместимо" на некоторых устройствах. minSdk 24 = Android 7.0+, targetSdk 33 = Android 13 (полностью совместим с Android 14). d8 --min-api повышен до 24.
- Убрано permission POST_NOTIFICATIONS (оно требует runtime-разрешение на Android 13+ и могло блокировать установку).
- lib/schedule-autorenew.ts: функция autorenewSchedule() — находит последний урок, если он в текущем месяце (или раньше), берёт все recurring="weekly" занятия последнего месяца как шаблон, и для каждого уникального (studentId, weekday, timeStart) создаёт занятия на все совпадающие дни недели следующего месяца (пн-пт). Идемпотентно: пропускает существующие (student|date|time).
- /api/schedule/autorenew: POST endpoint, вызывает autorenewSchedule().
- /api/dashboard GET: вызывает autorenewSchedule() при каждой загрузке дашборда (идемпотентно, ошибки глотаются).
- Lint чист, dev-сервер работает.

Self-verification:
- APK: 217574 bytes, file=Android package (APK), sdkVersion:'24', targetSdkVersion:'33', label='Репетитор', подпись v2+v3 ✓. Совместим с Android 7.0–14+.
- Автопродление: после загрузки дашборда создано 51 занятие на октябрь 2026 (было 54 в сентябре → стало 105 всего). Октябрьские занятия: Пн 5 окт — Полина 15:45, Тимофей 17:00, Анна 18:15; Ср 7 окт — Полина 16:00, Вероника 17:30, Блинова 19:00. Все "запланировано/не оплачено".
- Идемпотентность: второй вызов дашборда не создал дубли (105 → 105).
- UI: расписание показывает неделю 28.09–04.10, клик на 28.09 → видны октябрьские занятия.
- Ошибок в консоли нет.

Stage Summary:
- APK теперь совместим с Android 14: minSdk 24 (Android 7+), targetSdk 33 (Android 13), подписан v2+v3. Должен устанавливаться без ошибки "несовместимая версия".
- Расписание автоматически продлевается на следующий месяц при каждом заходе на дашборд: берёт повторяющиеся (weekly) занятия текущего месяца и создаёт их на все те же дни недели следующего месяца. Идемпотентно — не создаёт дубли.

---
Task ID: 12
Agent: main (Z.ai Code)
Task: Исправить расписание Блиновой (первое занятие 23 сентября), итоги, и починить APK.

Work Log:
- Блинова: удалены 3 занятия до 23 сентября (2, 9, 16 сентября были ошибочно проведены/оплачены). Теперь первое занятие Блиновой — 23 сентября 19:00, все "запланировано".
- seed-schedule: добавлено поле startDate для учеников. Блинова имеет startDate="2026-09-23" — занятия до этой даты не создаются. Цикл генерации пропускает даты раньше startDate.
- APK фикс подписи: добавлены --v1-signing-enabled true + --min-sdk-version 24 в apksigner. Раньше v1 (JAR signing) не включался, что могло вызывать отказ установки на некоторых устройствах. Теперь jarsigner -verify проходит, файлы META-INF/MANIFEST.MF, ANDROIDD.SF, ANDROIDD.RSA присутствуют. v1+v2+v3 подписи.
- Пересиживание: 7 учеников, 51 занятие (30 проведено/оплачено, 21 запланировано).

Self-verification:
- Блинова: 2026-09-23 19:00 (первое), 09-30, 10-07, 10-14, 10-21, 10-28 — все planned. Занятий до 23 сентября нет.
- Среда 16 сентября: Полина 16:00, Вероника 17:30 (Блиновой нет).
- Среда 23 сентября: Полина 16:00, Вероника 17:30, Блинова 19:00 (первое занятие).
- Месячный отчёт: 51 занятий, 30 проведено, 57500₽ оплата, 94500₽ всего, 4000₽ остаток, 0₽ долг.
- APK: 217574 bytes, jarsigner -verify ✓, v1+v2+v3 подписи, sdkVersion 24, targetSdkVersion 33.
- Ошибок в консоли нет.

Stage Summary:
- Расписание Блиновой исправлено: первое занятие 23 сентября (до этого занятий нет).
- Итоги пересчитаны: 51 занятий, 30 проведено, 94500₽ получено.
- APK: включена v1 (JAR) подпись + --min-sdk-version 24 для совместимости со старыми Android. Теперь подписан v1+v2+v3, jarsigner подтверждает.

---
Task ID: 13
Agent: main (Z.ai Code)
Task: Сделать оповещения в MAX и ВК по прямой ссылке без чатбота.

Work Log:
- Константы/типы: добавлены maxDirectLink и vkDirectLink в SETTING_KEYS, DEFAULT_SETTINGS, Settings. Старые bot-поля (maxBotToken, maxChatId, vkAccessToken, vkPeerId) оставлены как legacy для обратной совместимости.
- notifications-channels.ts: переписан dispatchMax/dispatchVk — теперь работают в двух режимах:
  • Direct-link mode (по умолчанию): если указана прямая ссылка (maxDirectLink/vkDirectLink), возвращает {ok:true, shareUrl, text} — без вызова API. Текст копируется в буфер, ссылка открывается.
  • Legacy bot API mode: если есть токен+chatId/peerId, отправляет через bot API (старый путь).
- /api/notifications/feed: добавлен блок shares — собирает {key, channel, title, body, shareUrl, text} для каждого оповещения в direct-link режиме, возвращает клиенту.
- use-notifications.ts: поллинг теперь запускается всегда (не зависит от enabled/permission), чтобы shares собирались даже без браузерных уведомлений. Добавлены state shares, функции openShare (копирует текст в буфер + открывает ссылку), dismissShare, clearShares.
- notification-bell.tsx: в dropdown добавлена секция «⚡ Отправить в мессенджер» с кнопками «MAX → открыть» / «ВК → открыть» для каждого pending share. Badge включает shares в счётчик.
- notification-settings.tsx: секции MAX и ВК переписаны — вместо токенов/телефонов/webhook одно поле «Прямая ссылка на чат» + инструкция «как это работает» (⚡ Без ботов, без токенов, без webhook).
- Lint чист, dev-сервер работает.

Self-verification:
- Настройки: MAX показывает поле «Прямая ссылка на ваш чат в MAX» с инструкцией. ВК — «Прямая ссылка на ваш диалог ВКонтакте».
- API /api/notifications/test: max ok=true, shareUrl=https://max.ru/im?uid=12345, text=«🧪 Тестовое оповещение...».
- API /api/notifications/feed: возвращает shares (2 элемента: Налоговая + Ежедневный отчёт, оба с shareUrl).
- UI: колокольчик показывает секцию «⚡ ОТПРАВИТЬ В МЕССЕНДЖЕР» с кнопками «MAX → открыть». Клик копирует текст в буфер и открывает ссылку, share исчезает.
- Ошибок в консоли нет.

Stage Summary:
- Оповещения в MAX и ВК теперь работают по прямым ссылкам без ботов, токенов и webhook. Пользователь указывает прямую ссылку на чат в настройках, и при срабатывании оповещения ассистент копирует текст в буфер и открывает чат — остаётся только вставить и отправить.
- Колокольчик показывает pending shares с кнопками «MAX → открыть» / «ВК → открыть».
- Старый bot API режим сохранён как legacy (если указаны токены).

---
Task ID: 14
Agent: main (Z.ai Code)
Task: Время уроков в расписании крупным зелёным шрифтом + переключатель размера шрифта во всём приложении.

Work Log:
- lesson-item.tsx: время уроков вынесено на отдельную строку, text-lg font-bold text-emerald-600 (dark: emerald-400), иконка Clock h-4 w-4 text-emerald-600. Раньше было text-xs text-muted-foreground в одной строке с именем.
- today-section.tsx (NextLessonCard): время увеличено до text-2xl font-bold text-white (на градиентной карточке следующего занятия).
- lib/use-font-size.ts: хук useFontSize — 5 размеров (Мелкий 0.875, Меньше 0.94, Обычный 1, Крупнее 1.12, Крупный 1.25), сохранение в localStorage (ta:fontSize), применение через CSS-переменную --font-scale на <html>.
- globals.css: html { font-size: calc(16px * var(--font-scale, 1)); } — масштабирует весь интерфейс.
- components/font-size-control.tsx: A-/A+ кнопки + dropdown с пресетами (Мелкий/Меньше/Обычный/Крупнее/Крупный) + Сбросить.
- page.tsx: FontSizeControl добавлен в шапку перед колокольчиком.
- Lint чист, dev-сервер работает.

Self-verification:
- Время уроков в расписании: 16:00–17:00 — fontSize 15.75px (было ~12px), fontWeight 700, color emerald (lab зелёный). text-lg font-bold text-emerald-600.
- NextLessonCard: время text-2xl font-bold.
- Переключатель A+/A- в шапке: при клике A+ размер растёт 14px→16px→18px→20px (scale 0.875→1→1.12→1.25).
- Dropdown с пресетами: Мелкий/Меньше/Обычный/Крупнее/Крупный — клик меняет размер.
- Сохранение: после reload размер сохраняется (localStorage ta:fontSize=4 → 20px).
- Время уроков при крупном шрифте: 22.5px зелёный bold.
- Мобильный вид 390×844: sticky-футер корректен, шрифт работает.
- Ошибок в консоли нет.

Stage Summary:
- Время проведения уроков в расписании теперь крупное (text-lg) и зелёное (emerald-600), bold — хорошо видно.
- Во всём приложении работает переключатель размера шрифта: кнопки A-/A+ в шапке + dropdown с 5 пресетами. Размер сохраняется после перезагрузки. Масштабирует весь интерфейс через CSS-переменную --font-scale.
