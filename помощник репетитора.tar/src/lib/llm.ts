// LLM helpers powered by z-ai-web-dev-sdk (server-side only).
// Used for: (1) parsing free-text schedules into structured lessons,
// (2) generating soft, polite payment-reminder messages for students.

import ZAI from "z-ai-web-dev-sdk";
import {
  LESSON_FORMATS,
  LESSON_STATUSES,
  PAYMENT_STATUSES,
  type LessonFormat,
  type LessonStatus,
  type PaymentStatus,
} from "@/lib/constants";
import type { LessonWithStudent } from "@/lib/types";
import { formatMoney } from "@/lib/tz";

export type ParsedLesson = {
  date: string | null; // YYYY-MM-DD
  timeStart: string | null; // HH:MM
  durationMinutes: number | null;
  studentName: string | null;
  subject: string | null;
  format: LessonFormat | null;
  link: string | null;
  price: number | null;
  lessonStatus: LessonStatus | null;
  paymentStatus: PaymentStatus | null;
  recurring: string | null; // "mon".."sun" if weekly recurring, else null
  comment: string | null;
};

const SYSTEM_PARSE = `Ты — помощник, который структурирует расписание репетитора из свободного текста.
Возвращай СТРОГО валидный JSON (без markdown, без пояснений) — массив объектов со следующими полями:
- date: строка YYYY-MM-DD или null
- timeStart: строка HH:MM (24-часовой формат) или null
- durationMinutes: целое число минут (по умолчанию 60) или null
- studentName: имя ученика или null
- subject: предмет или null
- format: "online" | "offline" | null
- link: строка URL или null
- price: целое число или null
- lessonStatus: "planned" | "conducted" | "cancelled" | "rescheduled" | "no_show" | null (по умолчанию "planned")
- paymentStatus: "paid" | "unpaid" | "partial" | "awaiting_confirmation" | "refund" | "free_trial" | null (по умолчанию "unpaid")
- recurring: "mon" | "tue" | "wed" | "thu" | "fri" | "sat" | "sun" — ЕСЛИ занятие повторяется каждую неделю в этот день недели. null если это разовое занятие с конкретной датой.
- comment: строка или null

Правила:
- Если указан день недели (понедельник/вторник/пн/вт и т.д.) БЕЗ конкретной даты — это повторяющееся занятие: ставь recurring = код дня, date = null.
- Если указана конкретная дата — ставь date, recurring = null.
- Если год не указан, используй текущий или ближайший будущий.
- Если длительность не указана, ставь 60.
- Если формат не указан, ставь null.
- Не выдумывай данные: если чего-то нет, ставь null.
- Возвращай ТОЛЬКО JSON-массив.`;

export async function parseScheduleText(
  text: string,
  referenceDate: string
): Promise<ParsedLesson[]> {
  const zai = await ZAI.create();
  const completion = await zai.chat.completions.create({
    messages: [
      { role: "assistant", content: SYSTEM_PARSE },
      {
        role: "user",
        content: `Текущая дата (опорная): ${referenceDate}.\n\nРасписание текстом:\n"""\n${text}\n"""\n\nПреобразуй в JSON-массив.`,
      },
    ],
    thinking: { type: "disabled" },
  });
  const content = completion.choices[0]?.message?.content ?? "[]";
  // Extract JSON array robustly
  const match = content.match(/\[[\s\S]*\]/);
  const jsonStr = match ? match[0] : "[]";
  try {
    const parsed = JSON.parse(jsonStr) as ParsedLesson[];
    // Sanitize enums
    return parsed.map((p) => ({
      ...p,
      format: p.format && LESSON_FORMATS.includes(p.format) ? p.format : null,
      lessonStatus:
        p.lessonStatus && LESSON_STATUSES.includes(p.lessonStatus)
          ? p.lessonStatus
          : p.lessonStatus
            ? null
            : "planned",
      paymentStatus:
        p.paymentStatus && PAYMENT_STATUSES.includes(p.paymentStatus)
          ? p.paymentStatus
          : p.paymentStatus
            ? null
            : "unpaid",
      recurring: p.recurring ?? null,
    }));
  } catch {
    return [];
  }
}

const WEEKDAY_CODES = ["sun", "mon", "tue", "wed", "thu", "fri", "sat"] as const;
const WEEKDAY_ALIASES: Record<string, string> = {
  monday: "mon", "пн": "mon", "понедельник": "mon", "пнд": "mon",
  tuesday: "tue", "вт": "tue", "вторник": "tue",
  wednesday: "wed", "ср": "wed", "среда": "wed", "среду": "wed",
  thursday: "thu", "чт": "thu", "четверг": "thu",
  friday: "fri", "пт": "fri", "пятница": "fri", "пятницу": "fri",
  saturday: "sat", "сб": "sat", "суббота": "sat", "субботу": "sat",
  sunday: "sun", "вс": "sun", "воскресенье": "sun", "воскресение": "sun",
};

/**
 * Expand recurring lessons into concrete dated instances for the month
 * containing `referenceDate`. Each recurring lesson (with recurring = weekday
 * code) becomes one lesson per matching weekday in that month, with date set
 * and recurring cleared.
 */
export function expandRecurring(
  lessons: ParsedLesson[],
  referenceDate: string
): ParsedLesson[] {
  const [y, m] = referenceDate.slice(0, 7).split("-").map(Number);
  const result: ParsedLesson[] = [];

  for (const l of lessons) {
    if (!l.recurring) {
      result.push(l);
      continue;
    }
    const code = WEEKDAY_ALIASES[String(l.recurring).toLowerCase()] ?? String(l.recurring).toLowerCase();
    const targetWeekday = WEEKDAY_CODES.indexOf(code as (typeof WEEKDAY_CODES)[number]);
    if (targetWeekday < 0) {
      result.push(l);
      continue;
    }
    const daysInMonth = new Date(Date.UTC(y, m, 0)).getUTCDate();
    for (let day = 1; day <= daysInMonth; day++) {
      const d = new Date(Date.UTC(y, m - 1, day));
      if (d.getUTCDay() === targetWeekday) {
        const dateStr = `${y}-${String(m).padStart(2, "0")}-${String(day).padStart(2, "0")}`;
        result.push({
          ...l,
          date: dateStr,
          recurring: null,
          comment: l.comment ?? `Повторяется каждую неделю`,
        });
      }
    }
  }
  return result;
}

const SYSTEM_REMINDER = `Ты — вежливый помощник репетитора. Пишешь мягкие, не обвинительные напоминания ученикам об оплате.
Тон: дружелюбный, тёплый, короткий. Без давления. Без угроз. Без ошибок в именах и датах.
Возвращай только текст сообщения (без подписи с твоей стороны, без markdown).`;

export async function generateStudentPaymentReminder(
  lesson: LessonWithStudent,
  tutorName: string
): Promise<string> {
  const amount = Math.max(0, lesson.price - lesson.paidAmount);
  const firstName = lesson.student.name.split(" ")[0];
  const zai = await ZAI.create();
  const completion = await zai.chat.completions.create({
    messages: [
      { role: "assistant", content: SYSTEM_REMINDER },
      {
        role: "user",
        content: `Напиши короткое вежливое напоминание об оплате для ученика ${firstName}.
Детали: занятие ${lesson.date} в ${lesson.timeStart}, предмет «${lesson.subject}». Сумма к оплате: ${formatMoney(amount)}.
Подпишись как: ${tutorName || "Ваш репетитор"}.
Не более 4 предложений.`,
      },
    ],
    thinking: { type: "disabled" },
  });
  return (completion.choices[0]?.message?.content ?? "").trim();
}

const SYSTEM_SUMMARY = `Ты — личный ассистент репетитора. Пишешь краткий, по делу, дружелюбно-деловой итог недели на русском. Без воды, 2-4 предложения.`;

export async function generateWeeklySummary(
  weeklyText: string
): Promise<string> {
  const zai = await ZAI.create();
  const completion = await zai.chat.completions.create({
    messages: [
      { role: "assistant", content: SYSTEM_SUMMARY },
      {
        role: "user",
        content: `Сформируй краткий итог недели для репетитора на основе данных:\n\n${weeklyText}\n\n2-4 предложения. Без markdown.`,
      },
    ],
    thinking: { type: "disabled" },
  });
  return (completion.choices[0]?.message?.content ?? "").trim();
}

export type ParsedStudent = {
  name: string | null;
  phone: string | null;
  email: string | null;
  grade: string | null;
  comment: string | null;
};

const SYSTEM_PARSE_STUDENTS = `Ты — помощник, который структурирует список учеников репетитора из свободного текста или таблицы.
Возвращай СТРОГО валидный JSON (без markdown, без пояснений) — массив объектов со следующими полями:
- name: имя и фамилия ученика (строка) или null
- phone: телефон (строка) или null
- email: email (строка) или null
- grade: класс или курс (например "5 класс", "10 класс", "студент") или null
- comment: заметка/предмет (строка) или null

Правила:
- Не выдумывай данные: если чего-то нет, ставь null.
- Возвращай ТОЛЬКО JSON-массив.`;

export async function parseStudentsText(text: string): Promise<ParsedStudent[]> {
  const zai = await ZAI.create();
  const completion = await zai.chat.completions.create({
    messages: [
      { role: "assistant", content: SYSTEM_PARSE_STUDENTS },
      {
        role: "user",
        content: `Преобразуй в JSON-массив список учеников:\n"""\n${text}\n"""`,
      },
    ],
    thinking: { type: "disabled" },
  });
  const content = completion.choices[0]?.message?.content ?? "[]";
  const match = content.match(/\[[\s\S]*\]/);
  const jsonStr = match ? match[0] : "[]";
  try {
    return JSON.parse(jsonStr) as ParsedStudent[];
  } catch {
    return [];
  }
}

