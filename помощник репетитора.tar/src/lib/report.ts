// Server-side helpers: settings access + report generation
import { db } from "@/lib/db";
import {
  DEFAULT_SETTINGS,
  MONTHS_RU_NOM,
  SETTING_KEYS,
  WEEKDAYS_RU,
} from "@/lib/constants";
import {
  addDays,
  endOfMonth,
  formatMoney,
  formatShortDate,
  monthLabel,
  monthOf,
  monthWeeks,
  monthsOfYear,
  nextMonth,
  nowInTZ,
  pad2,
  prevMonth,
  startOfMonth,
  startOfWeek,
  weekdayMondayBased,
} from "@/lib/tz";
import type {
  DailyReport,
  LessonWithStudent,
  MonthlyPayment,
  MonthlyPaymentInfo,
  MonthlyReport,
  PrepaymentBalanceItem,
  Settings,
  TaxReminderStatus,
  WeeklyReport,
  YearlyReport,
} from "@/lib/types";

export async function getSettings(): Promise<Settings> {
  const rows = await db.setting.findMany();
  const map: Record<string, string> = { ...DEFAULT_SETTINGS };
  for (const r of rows) map[r.id] = r.value;
  return {
    timezone: map[SETTING_KEYS.timezone],
    dailyReportTime: map[SETTING_KEYS.dailyReportTime],
    weeklyReportDay: map[SETTING_KEYS.weeklyReportDay],
    weeklyReportTime: map[SETTING_KEYS.weeklyReportTime],
    monthlyReportTime: map[SETTING_KEYS.monthlyReportTime],
    reminder30min: map[SETTING_KEYS.reminder30min] === "true",
    reminder1h: map[SETTING_KEYS.reminder1h] === "true",
    reminder15min: map[SETTING_KEYS.reminder15min] === "true",
    autoReminderToStudent: map[SETTING_KEYS.autoReminderToStudent] === "true",
    taxReminderTime: map[SETTING_KEYS.taxReminderTime],
    taxReminderLastDone: map[SETTING_KEYS.taxReminderLastDone] ?? "",
    taxReminderEnabled: map[SETTING_KEYS.taxReminderEnabled] === "true",
    browserNotifEnabled: map[SETTING_KEYS.browserNotifEnabled] === "true",
    maxEnabled: map[SETTING_KEYS.maxEnabled] === "true",
    maxDirectLink: map[SETTING_KEYS.maxDirectLink] ?? "",
    maxBotToken: map[SETTING_KEYS.maxBotToken] ?? "",
    maxPhone: map[SETTING_KEYS.maxPhone] ?? "",
    maxChatId: map[SETTING_KEYS.maxChatId] ?? "",
    vkEnabled: map[SETTING_KEYS.vkEnabled] === "true",
    vkDirectLink: map[SETTING_KEYS.vkDirectLink] ?? "",
    vkAccessToken: map[SETTING_KEYS.vkAccessToken] ?? "",
    vkPeerId: map[SETTING_KEYS.vkPeerId] ?? "",
    tutorName: map[SETTING_KEYS.tutorName] ?? "",
  };
}

export async function saveSettings(patch: Partial<Settings>): Promise<void> {
  const keyMap: Record<keyof Settings, string> = {
    timezone: SETTING_KEYS.timezone,
    dailyReportTime: SETTING_KEYS.dailyReportTime,
    weeklyReportDay: SETTING_KEYS.weeklyReportDay,
    weeklyReportTime: SETTING_KEYS.weeklyReportTime,
    monthlyReportTime: SETTING_KEYS.monthlyReportTime,
    reminder30min: SETTING_KEYS.reminder30min,
    reminder1h: SETTING_KEYS.reminder1h,
    reminder15min: SETTING_KEYS.reminder15min,
    autoReminderToStudent: SETTING_KEYS.autoReminderToStudent,
    taxReminderTime: SETTING_KEYS.taxReminderTime,
    taxReminderLastDone: SETTING_KEYS.taxReminderLastDone,
    taxReminderEnabled: SETTING_KEYS.taxReminderEnabled,
    browserNotifEnabled: SETTING_KEYS.browserNotifEnabled,
    maxEnabled: SETTING_KEYS.maxEnabled,
    maxDirectLink: SETTING_KEYS.maxDirectLink,
    maxBotToken: SETTING_KEYS.maxBotToken,
    maxPhone: SETTING_KEYS.maxPhone,
    maxChatId: SETTING_KEYS.maxChatId,
    vkEnabled: SETTING_KEYS.vkEnabled,
    vkDirectLink: SETTING_KEYS.vkDirectLink,
    vkAccessToken: SETTING_KEYS.vkAccessToken,
    vkPeerId: SETTING_KEYS.vkPeerId,
    tutorName: SETTING_KEYS.tutorName,
  };
  const ops = Object.entries(patch).map(([k, v]) =>
    db.setting.upsert({
      where: { id: keyMap[k as keyof Settings] },
      update: { value: String(v) },
      create: { id: keyMap[k as keyof Settings], value: String(v) },
    })
  );
  await Promise.all(ops);
}

function toLessonWithStudent(l: any): LessonWithStudent {
  return {
    id: l.id,
    date: l.date,
    timeStart: l.timeStart,
    durationMinutes: l.durationMinutes,
    studentId: l.studentId,
    student: {
      id: l.student.id,
      name: l.student.name,
      color: l.student.color,
      phone: l.student.phone,
    },
    subject: l.subject,
    format: l.format,
    link: l.link,
    price: l.price,
    paidAmount: l.paidAmount,
    lessonStatus: l.lessonStatus,
    paymentStatus: l.paymentStatus,
    comment: l.comment,
    createdAt: l.createdAt.toISOString(),
    updatedAt: l.updatedAt.toISOString(),
  };
}

export async function getLessonsForDate(date: string): Promise<LessonWithStudent[]> {
  const rows = await db.lesson.findMany({
    where: { date },
    include: { student: true },
    orderBy: { timeStart: "asc" },
  });
  return rows.map(toLessonWithStudent);
}

export async function getLessonsForRange(
  start: string,
  end: string
): Promise<LessonWithStudent[]> {
  const rows = await db.lesson.findMany({
    where: { date: { gte: start, lte: end } },
    include: { student: true },
    orderBy: [{ date: "asc" }, { timeStart: "asc" }],
  });
  return rows.map(toLessonWithStudent);
}

const LESSON_STATUS_LABELS_SHORT: Record<string, string> = {
  planned: "запланировано",
  conducted: "проведено",
  cancelled: "отменено",
  rescheduled: "перенесено",
  no_show: "неявка",
};

const PAYMENT_STATUS_LABELS_SHORT: Record<string, string> = {
  paid: "оплачено",
  unpaid: "не оплачено",
  partial: "частично",
  awaiting_confirmation: "ожидает подтверждения",
  refund: "возврат",
  free_trial: "бесплатно",
};

/** Whether a lesson counts as "owing money" (debt). */
export function isOwing(l: LessonWithStudent): boolean {
  return (
    l.lessonStatus === "conducted" &&
    (l.paymentStatus === "unpaid" || l.paymentStatus === "partial")
  );
}

/** Outstanding debt amount for a lesson. */
export function debtAmount(l: LessonWithStudent): number {
  if (!isOwing(l)) return 0;
  return Math.max(0, l.price - l.paidAmount);
}

/** Expected payment for a lesson (excludes free/refund/cancelled). */
export function expectedAmount(l: LessonWithStudent): number {
  if (l.paymentStatus === "free_trial" || l.paymentStatus === "refund") return 0;
  if (l.lessonStatus === "cancelled") return 0;
  return l.price;
}

/** Received amount for a lesson. */
export function receivedAmount(l: LessonWithStudent): number {
  if (l.paymentStatus === "paid") return l.price;
  if (l.paymentStatus === "partial") return l.paidAmount;
  return 0;
}

export async function buildDailyReport(date: string): Promise<DailyReport> {
  const lessons = await getLessonsForDate(date);
  const tomorrow = addDays(date, 1);
  const tomorrowLessons = await getLessonsForDate(tomorrow);

  const conducted = lessons.filter((l) => l.lessonStatus === "conducted").length;
  const cancelled = lessons.filter((l) => l.lessonStatus === "cancelled").length;
  const rescheduled = lessons.filter((l) => l.lessonStatus === "rescheduled").length;
  const planned = lessons.filter((l) => l.lessonStatus === "planned").length;
  const noShow = lessons.filter((l) => l.lessonStatus === "no_show").length;

  const paid = lessons.filter((l) => l.paymentStatus === "paid").length;
  const unpaid = lessons.filter((l) => isOwing(l)).length;

  const expectedTotal = lessons.reduce((s, l) => s + expectedAmount(l), 0);
  const receivedTotal = lessons.reduce((s, l) => s + receivedAmount(l), 0);
  const debtTotal = lessons.reduce((s, l) => s + debtAmount(l), 0);

  const debtors = lessons
    .filter((l) => isOwing(l))
    .map((l) => ({
      studentName: l.student.name,
      date: l.date,
      amount: debtAmount(l),
      lessonId: l.id,
    }));

  const tomorrowList = tomorrowLessons
    .filter((l) => l.lessonStatus === "planned" || l.lessonStatus === "rescheduled")
    .map((l) => ({
      time: l.timeStart,
      studentName: l.student.name,
      subject: l.subject,
      format: l.format,
    }));

  // Build text report
  let text = `Ежедневный отчёт за ${formatShortDate(date)}\n\n`;
  if (lessons.length === 0) {
    text += `Занятий не было.`;
  } else {
    text += `Всего занятий: ${lessons.length}\n`;
    text += `Проведено: ${conducted}\n`;
    text += `Отменено: ${cancelled}\n`;
    text += `Перенесено: ${rescheduled}\n`;
    text += `Оплачено: ${paid}\n`;
    text += `Не оплачено: ${unpaid}\n\n`;
    text += `Сумма к оплате: ${formatMoney(expectedTotal)}\n`;
    text += `Сумма оплачено: ${formatMoney(receivedTotal)}\n\n`;
    text += `Занятия:\n`;
    lessons.forEach((l, i) => {
      text += `${i + 1}. ${l.timeStart} — ${l.student.name} — ${l.subject} — ${LESSON_STATUS_LABELS_SHORT[l.lessonStatus] ?? l.lessonStatus} — ${PAYMENT_STATUS_LABELS_SHORT[l.paymentStatus] ?? l.paymentStatus} — ${formatMoney(l.price)}\n`;
    });
    if (debtors.length > 0) {
      text += `\nНе оплатили:\n`;
      debtors.forEach((d) => {
        text += `- ${d.studentName} — ${formatShortDate(d.date)} — ${formatMoney(d.amount)}\n`;
      });
    } else {
      text += `\nНеоплаченных занятий нет.\n`;
    }
    if (tomorrowList.length > 0) {
      text += `\nЗавтра:\n`;
      tomorrowList.forEach((t) => {
        text += `- ${t.time} — ${t.studentName} — ${t.subject}\n`;
      });
    } else {
      text += `\nЗавтра занятий нет.\n`;
    }
  }

  return {
    date,
    total: lessons.length,
    conducted,
    cancelled,
    rescheduled,
    planned,
    noShow,
    paid,
    unpaid,
    expectedTotal,
    receivedTotal,
    debtTotal,
    lessons,
    debtors,
    tomorrow: tomorrowList,
    text,
  };
}

export async function buildWeeklyReport(referenceDate: string): Promise<WeeklyReport> {
  const startDate = startOfWeek(referenceDate); // Monday
  const endDate = addDays(startDate, 6); // Sunday
  const lessons = await getLessonsForRange(startDate, endDate);

  const conducted = lessons.filter((l) => l.lessonStatus === "conducted");
  const cancelled = lessons.filter((l) => l.lessonStatus === "cancelled").length;
  const rescheduled = lessons.filter((l) => l.lessonStatus === "rescheduled").length;
  const planned = lessons.filter((l) => l.lessonStatus === "planned").length;
  const noShow = lessons.filter((l) => l.lessonStatus === "no_show").length;

  const paidCount = lessons.filter((l) => l.paymentStatus === "paid").length;
  const unpaidCount = lessons.filter((l) => isOwing(l)).length;

  const receivedTotal = lessons.reduce((s, l) => s + receivedAmount(l), 0);
  const expectedTotal = lessons.reduce((s, l) => s + expectedAmount(l), 0);
  const debtTotal = lessons.reduce((s, l) => s + debtAmount(l), 0);

  // By day (Mon-Sun)
  const byDay = WEEKDAYS_RU.map((day, idx) => {
    const dayLessons = lessons.filter((l) => weekdayMondayBased(l.date) === idx);
    return {
      day,
      count: dayLessons.length,
      conducted: dayLessons.filter((l) => l.lessonStatus === "conducted").length,
    };
  });

  // Debtors grouped by student
  const debtorMap = new Map<string, { count: number; amount: number }>();
  for (const l of lessons) {
    if (!isOwing(l)) continue;
    const cur = debtorMap.get(l.student.name) ?? { count: 0, amount: 0 };
    cur.count += 1;
    cur.amount += debtAmount(l);
    debtorMap.set(l.student.name, cur);
  }
  const debtors = Array.from(debtorMap.entries()).map(([studentName, v]) => ({
    studentName,
    lessonsCount: v.count,
    amount: v.amount,
  }));

  // By student stats
  const studentMap = new Map<
    string,
    { color: string; total: number; conducted: number; revenue: number; debt: number }
  >();
  for (const l of lessons) {
    const cur = studentMap.get(l.student.name) ?? {
      color: l.student.color,
      total: 0,
      conducted: 0,
      revenue: 0,
      debt: 0,
    };
    cur.total += 1;
    if (l.lessonStatus === "conducted") cur.conducted += 1;
    cur.revenue += receivedAmount(l);
    cur.debt += debtAmount(l);
    studentMap.set(l.student.name, cur);
  }
  const byStudent = Array.from(studentMap.entries())
    .map(([studentName, v]) => ({ studentName, ...v }))
    .sort((a, b) => b.total - a.total);

  // Build text report
  let text = `Еженедельный отчёт за период с ${formatShortDate(startDate)} по ${formatShortDate(endDate)}\n\n`;
  text += `Всего занятий: ${lessons.length}\n`;
  text += `Проведено: ${conducted.length}\n`;
  text += `Отменено: ${cancelled}\n`;
  text += `Перенесено: ${rescheduled}\n`;
  text += `Оплачено: ${paidCount}\n`;
  text += `Не оплачено: ${unpaidCount}\n\n`;
  text += `Сумма оплачена: ${formatMoney(receivedTotal)}\n`;
  text += `Сумма к оплате: ${formatMoney(expectedTotal - receivedTotal)}\n`;
  text += `Общий долг: ${formatMoney(debtTotal)}\n\n`;
  text += `По дням:\n`;
  byDay.forEach((d) => {
    text += `${d.day}: ${d.count} занятий (проведено ${d.conducted})\n`;
  });
  if (debtors.length > 0) {
    text += `\nНе оплатили:\n`;
    debtors.forEach((d) => {
      text += `- ${d.studentName} — ${d.lessonsCount} занятие(ий) — ${formatMoney(d.amount)}\n`;
    });
  } else {
    text += `\nНеоплаченных занятий нет.\n`;
  }
  // Summary
  let summary = `\nИтог:\nЗа неделю проведено ${conducted.length} занятий.`;
  if (debtors.length > 0) {
    summary += ` Есть ${unpaidCount} неоплаченных занятий на сумму ${formatMoney(debtTotal)}. Рекомендуется отправить напоминание об оплате.`;
  } else {
    summary += ` Все занятия оплачены.`;
  }

  text += summary;

  return {
    startDate,
    endDate,
    total: lessons.length,
    conducted: conducted.length,
    cancelled,
    rescheduled,
    planned,
    noShow,
    paid: paidCount,
    unpaid: unpaidCount,
    receivedTotal,
    expectedTotal,
    debtTotal,
    byDay,
    debtors,
    byStudent,
    text,
  };
}

// ---------------------------------------------------------------------------
// Monthly prepayments
// ---------------------------------------------------------------------------

/** Load all monthly prepayments for a given YYYY-MM (with student). */
export async function getMonthlyPaymentsForMonth(
  month: string
): Promise<MonthlyPayment[]> {
  const rows = await db.monthlyPayment.findMany({
    where: { month },
    include: { student: true },
  });
  rows.sort((a, b) => a.student.name.localeCompare(b.student.name, "ru"));
  return rows.map((m) => ({
    id: m.id,
    studentId: m.studentId,
    student: {
      id: m.student.id,
      name: m.student.name,
      color: m.student.color,
    },
    month: m.month,
    lessonsCount: m.lessonsCount,
    amount: m.amount,
    paid: m.paid,
    paidAt: m.paidAt ? m.paidAt.toISOString() : null,
    comment: m.comment,
    createdAt: m.createdAt.toISOString(),
    updatedAt: m.updatedAt.toISOString(),
  }));
}

/** Get a single student's prepayment for a month (if any). */
export async function getStudentMonthlyPayment(
  studentId: string,
  month: string
) {
  return db.monthlyPayment.findUnique({
    where: { studentId_month: { studentId, month } },
  });
}

/** Compute prepayment info (with conducted/planned counts) for a student-month.
 *  If paidAt is set, only lessons from paidAt onward count against the prepayment. */
export async function computeMonthlyPaymentInfo(
  studentId: string,
  month: string
): Promise<MonthlyPaymentInfo | null> {
  const mp = await getStudentMonthlyPayment(studentId, month);
  if (!mp) return null;
  const start = startOfMonth(month);
  const end = endOfMonth(month);
  // If paidAt is set, only count lessons from that date onward (the prepayment
  // covers lessons from the payment date, not retroactively).
  const fromDate = mp.paidAt
    ? mp.paidAt.toISOString().slice(0, 10)
    : start;
  const whereDate: any = { gte: fromDate, lte: end };
  const monthLessons = await db.lesson.findMany({
    where: { studentId, date: whereDate },
  });
  const conductedThisMonth = monthLessons.filter(
    (l) => l.lessonStatus === "conducted"
  ).length;
  const plannedThisMonth = monthLessons.filter(
    (l) => l.lessonStatus === "planned" || l.lessonStatus === "rescheduled"
  ).length;
  return {
    id: mp.id,
    month: mp.month,
    lessonsCount: mp.lessonsCount,
    amount: mp.amount,
    paid: mp.paid,
    paidAt: mp.paidAt ? mp.paidAt.toISOString() : null,
    comment: mp.comment,
    conductedThisMonth,
    remaining: Math.max(0, mp.lessonsCount - conductedThisMonth),
    plannedThisMonth,
  };
}

/**
 * Compute the carried-over prepayment balance for a student from all PAST
 * months (month < upToMonth). For each past month that had a prepayment:
 *   unusedLessons = max(0, lessonsCount - conductedThisMonth)
 *   perLessonPrice = amount / lessonsCount
 *   unusedMoney = unusedLessons * perLessonPrice
 * Only months that are strictly before upToMonth are counted (the current
 * month's prepayment is shown separately, not as a balance).
 */
export async function getStudentPrepaymentBalance(
  studentId: string,
  upToMonth: string
): Promise<{ items: PrepaymentBalanceItem[]; total: number }> {
  const allPrepays = await db.monthlyPayment.findMany({
    where: { studentId, month: { lt: upToMonth } },
    orderBy: { month: "asc" },
  });
  const items: PrepaymentBalanceItem[] = [];
  let total = 0;
  for (const mp of allPrepays) {
    const start = startOfMonth(mp.month);
    const end = endOfMonth(mp.month);
    const monthLessons = await db.lesson.findMany({
      where: { studentId, date: { gte: start, lte: end } },
    });
    const conducted = monthLessons.filter(
      (l) => l.lessonStatus === "conducted"
    ).length;
    const unusedLessons = Math.max(0, mp.lessonsCount - conducted);
    const perLessonPrice =
      mp.lessonsCount > 0 ? mp.amount / mp.lessonsCount : 0;
    const amount = Math.round(unusedLessons * perLessonPrice);
    if (amount > 0) {
      items.push({
        month: mp.month,
        monthLabel: monthLabel(mp.month),
        lessonsCount: mp.lessonsCount,
        conducted,
        unusedLessons,
        perLessonPrice: Math.round(perLessonPrice),
        amount,
      });
      total += amount;
    }
  }
  return { items, total };
}

/** Upsert (create or update) a monthly prepayment for a student-month. */
export async function upsertMonthlyPayment(args: {
  studentId: string;
  month: string;
  lessonsCount: number;
  amount: number;
  paid?: boolean;
  comment?: string | null;
}): Promise<MonthlyPayment> {
  const existing = await getStudentMonthlyPayment(args.studentId, args.month);
  let row;
  if (existing) {
    row = await db.monthlyPayment.update({
      where: { id: existing.id },
      data: {
        lessonsCount: args.lessonsCount,
        amount: args.amount,
        paid: args.paid ?? true,
        paidAt: args.paid === false ? null : new Date(),
        comment: args.comment ?? null,
      },
      include: { student: true },
    });
  } else {
    row = await db.monthlyPayment.create({
      data: {
        studentId: args.studentId,
        month: args.month,
        lessonsCount: args.lessonsCount,
        amount: args.amount,
        paid: args.paid ?? true,
        paidAt: args.paid === false ? null : new Date(),
        comment: args.comment ?? null,
      },
      include: { student: true },
    });
  }
  return {
    id: row.id,
    studentId: row.studentId,
    student: {
      id: row.student.id,
      name: row.student.name,
      color: row.student.color,
    },
    month: row.month,
    lessonsCount: row.lessonsCount,
    amount: row.amount,
    paid: row.paid,
    paidAt: row.paidAt ? row.paidAt.toISOString() : null,
    comment: row.comment,
    createdAt: row.createdAt.toISOString(),
    updatedAt: row.updatedAt.toISOString(),
  };
}

export async function deleteMonthlyPayment(id: string): Promise<void> {
  await db.monthlyPayment.delete({ where: { id } }).catch(() => {});
}

// ---------------------------------------------------------------------------
// Monthly report
// ---------------------------------------------------------------------------

export async function buildMonthlyReport(
  referenceDate: string
): Promise<MonthlyReport> {
  const month = monthOf(referenceDate); // YYYY-MM
  const startDate = startOfMonth(month);
  const endDate = endOfMonth(month);
  const lessons = await getLessonsForRange(startDate, endDate);
  const prepayments = await getMonthlyPaymentsForMonth(month);

  const conducted = lessons.filter((l) => l.lessonStatus === "conducted");
  const cancelled = lessons.filter((l) => l.lessonStatus === "cancelled").length;
  const rescheduled = lessons.filter((l) => l.lessonStatus === "rescheduled").length;
  const planned = lessons.filter((l) => l.lessonStatus === "planned").length;
  const noShow = lessons.filter((l) => l.lessonStatus === "no_show").length;

  const paidCount = lessons.filter((l) => l.paymentStatus === "paid").length;
  const unpaidCount = lessons.filter((l) => isOwing(l)).length;

  const receivedTotal = lessons.reduce((s, l) => s + receivedAmount(l), 0);
  const expectedTotal = lessons.reduce((s, l) => s + expectedAmount(l), 0);
  const debtTotal = lessons.reduce((s, l) => s + debtAmount(l), 0);
  const prepaymentTotal = prepayments
    .filter((p) => p.paid)
    .reduce((s, p) => s + p.amount, 0);
  const grandReceived = receivedTotal + prepaymentTotal;

  // By week (calendar weeks overlapping the month)
  const weeks = monthWeeks(month);
  const byWeek = weeks.map((w) => {
    const wLessons = lessons.filter(
      (l) => l.date >= w.start && l.date <= w.end
    );
    return {
      label: `${w.label} (${formatShortDate(w.start)}–${formatShortDate(w.end)})`,
      count: wLessons.length,
      conducted: wLessons.filter((l) => l.lessonStatus === "conducted").length,
    };
  });

  // Debtors grouped by student
  const debtorMap = new Map<string, { count: number; amount: number }>();
  for (const l of lessons) {
    if (!isOwing(l)) continue;
    const cur = debtorMap.get(l.student.name) ?? { count: 0, amount: 0 };
    cur.count += 1;
    cur.amount += debtAmount(l);
    debtorMap.set(l.student.name, cur);
  }
  const debtors = Array.from(debtorMap.entries()).map(([studentName, v]) => ({
    studentName,
    lessonsCount: v.count,
    amount: v.amount,
  }));

  // By student with prepayment info
  const studentMap = new Map<
    string,
    {
      id: string;
      color: string;
      total: number;
      conducted: number;
      revenue: number;
      debt: number;
    }
  >();
  for (const l of lessons) {
    const cur = studentMap.get(l.student.name) ?? {
      id: l.student.id,
      color: l.student.color,
      total: 0,
      conducted: 0,
      revenue: 0,
      debt: 0,
    };
    cur.total += 1;
    if (l.lessonStatus === "conducted") cur.conducted += 1;
    cur.revenue += receivedAmount(l);
    cur.debt += debtAmount(l);
    studentMap.set(l.student.name, cur);
  }
  // attach prepayments + carryover balance from previous months
  const prepayByStudent = new Map<string, MonthlyPaymentInfo>();
  const carryoverByStudent = new Map<string, number>();
  for (const p of prepayments) {
    const info = await computeMonthlyPaymentInfo(p.studentId, month);
    if (info) prepayByStudent.set(p.studentId, info);
  }
  // compute carryover for ALL students that have lessons this month
  for (const [studentName, v] of studentMap.entries()) {
    const bal = await getStudentPrepaymentBalance(v.id, month);
    carryoverByStudent.set(v.id, bal.total);
  }
  const carryoverBalanceTotal = Array.from(carryoverByStudent.values()).reduce(
    (s, x) => s + x,
    0
  );
  const byStudent = await Promise.all(
    Array.from(studentMap.entries()).map(async ([studentName, v]) => ({
      studentName,
      color: v.color,
      total: v.total,
      conducted: v.conducted,
      revenue: v.revenue,
      debt: v.debt,
      prepaid: prepayByStudent.get(v.id) ?? null,
      carryoverBalance: carryoverByStudent.get(v.id) ?? 0,
    }))
  ).then((arr) => arr.sort((a, b) => b.total - a.total));

  // Text report
  let text = `Ежемесячный отчёт за ${monthLabel(month)}\n\n`;
  text += `Всего занятий: ${lessons.length}\n`;
  text += `Проведено: ${conducted.length}\n`;
  text += `Отменено: ${cancelled}\n`;
  text += `Перенесено: ${rescheduled}\n`;
  text += `Оплачено: ${paidCount}\n`;
  text += `Не оплачено: ${unpaidCount}\n\n`;
  text += `Оплата по занятиям: ${formatMoney(receivedTotal)}\n`;
  text += `Предоплаты за месяц: ${formatMoney(prepaymentTotal)}\n`;
  text += `Всего получено: ${formatMoney(grandReceived)}\n`;
  if (carryoverBalanceTotal > 0) {
    text += `Остаток с прошлых месяцев (неизрасходованные предоплаты): ${formatMoney(carryoverBalanceTotal)}\n`;
  }
  text += `Общий долг (по занятиям): ${formatMoney(debtTotal)}\n\n`;
  text += `По неделям:\n`;
  byWeek.forEach((w) => {
    text += `${w.label}: ${w.count} занятий (проведено ${w.conducted})\n`;
  });
  if (prepayments.length > 0) {
    text += `\nПредоплаты за месяц:\n`;
    prepayments.forEach((p) => {
      const info = prepayByStudent.get(p.studentId);
      const conductedN = info?.conductedThisMonth ?? 0;
      const remaining = info?.remaining ?? 0;
      text += `- ${p.student.name} — ${p.lessonsCount} занятий — ${formatMoney(
        p.amount
      )} — ${p.paid ? "оплачено" : "не оплачено"} — проведено ${conductedN}, осталось ${remaining}\n`;
    });
  }
  // Carryover balances from previous months
  const carryoverItems = byStudent.filter((s) => s.carryoverBalance > 0);
  if (carryoverItems.length > 0) {
    text += `\nОстались деньги с прошлых месяцев:\n`;
    for (const s of carryoverItems) {
      const items = await getStudentPrepaymentBalance(
        studentMap.get(s.studentName)!.id,
        month
      );
      for (const it of items.items) {
        text += `- ${s.studentName} — с ${it.monthLabel} — ${formatMoney(
          it.amount
        )} (${it.unusedLessons} из ${it.lessonsCount} занятий не проведено)\n`;
      }
    }
  }
  if (debtors.length > 0) {
    text += `\nДолжники (по занятиям):\n`;
    debtors.forEach((d) => {
      text += `- ${d.studentName} — ${d.lessonsCount} занятие(ий) — ${formatMoney(
        d.amount
      )}\n`;
    });
  } else {
    text += `\nДолжников по занятиям нет.\n`;
  }
  let summary = `\nИтог:\nЗа ${monthLabel(month)} проведено ${conducted.length} из ${lessons.length} занятий. Получено ${formatMoney(
    grandReceived
  )}`;
  if (debtTotal > 0) {
    summary += `. Остаток долга по занятиям: ${formatMoney(debtTotal)}.`;
  } else {
    summary += `. Долгов нет.`;
  }
  if (prepayments.length > 0) {
    summary += ` Предоплат за месяц: ${prepayments.length}.`;
  }
  if (carryoverBalanceTotal > 0) {
    summary += ` Остаток с прошлых месяцев: ${formatMoney(carryoverBalanceTotal)}.`;
  }
  text += summary;

  return {
    month,
    monthLabel: monthLabel(month),
    startDate,
    endDate,
    total: lessons.length,
    conducted: conducted.length,
    cancelled,
    rescheduled,
    planned,
    noShow,
    paid: paidCount,
    unpaid: unpaidCount,
    receivedTotal,
    expectedTotal,
    debtTotal,
    prepaymentTotal,
    grandReceived,
    carryoverBalanceTotal,
    byWeek,
    debtors,
    byStudent,
    prepayments,
    text,
  };
}

// ---------------------------------------------------------------------------
// Yearly report
// ---------------------------------------------------------------------------

export async function buildYearlyReport(year: number): Promise<YearlyReport> {
  const start = `${year}-01-01`;
  const end = `${year}-12-31`;
  const lessons = await getLessonsForRange(start, end);
  const prepayments = await db.monthlyPayment.findMany({
    where: { month: { gte: `${year}-01`, lte: `${year}-12` } },
  });

  const conducted = lessons.filter((l) => l.lessonStatus === "conducted");
  const cancelled = lessons.filter((l) => l.lessonStatus === "cancelled").length;
  const rescheduled = lessons.filter((l) => l.lessonStatus === "rescheduled").length;
  const planned = lessons.filter((l) => l.lessonStatus === "planned").length;
  const noShow = lessons.filter((l) => l.lessonStatus === "no_show").length;
  const paidCount = lessons.filter((l) => l.paymentStatus === "paid").length;
  const unpaidCount = lessons.filter((l) => isOwing(l)).length;

  const receivedTotal = lessons.reduce((s, l) => s + receivedAmount(l), 0);
  const debtTotal = lessons.reduce((s, l) => s + debtAmount(l), 0);
  const prepaymentTotal = prepayments
    .filter((p) => p.paid)
    .reduce((s, p) => s + p.amount, 0);
  const grandReceived = receivedTotal + prepaymentTotal;

  // By month
  const byMonth = monthsOfYear(year).map((m) => {
    const mLessons = lessons.filter((l) => monthOf(l.date) === m);
    return {
      month: m,
      label: MONTHS_RU_NOM[Number(m.slice(5, 7)) - 1],
      count: mLessons.length,
      conducted: mLessons.filter((l) => l.lessonStatus === "conducted").length,
      revenue:
        mLessons.reduce((s, l) => s + receivedAmount(l), 0) +
        prepayments
          .filter((p) => p.month === m && p.paid)
          .reduce((s, p) => s + p.amount, 0),
    };
  });

  // By student
  const studentMap = new Map<
    string,
    { color: string; total: number; conducted: number; revenue: number; debt: number }
  >();
  for (const l of lessons) {
    const cur = studentMap.get(l.student.name) ?? {
      color: l.student.color,
      total: 0,
      conducted: 0,
      revenue: 0,
      debt: 0,
    };
    cur.total += 1;
    if (l.lessonStatus === "conducted") cur.conducted += 1;
    cur.revenue += receivedAmount(l);
    cur.debt += debtAmount(l);
    studentMap.set(l.student.name, cur);
  }
  const byStudent = Array.from(studentMap.entries())
    .map(([studentName, v]) => ({ studentName, ...v }))
    .sort((a, b) => b.total - a.total);

  // Text
  let text = `Ежегодный отчёт за ${year} год\n\n`;
  text += `Всего занятий: ${lessons.length}\n`;
  text += `Проведено: ${conducted.length}\n`;
  text += `Отменено: ${cancelled}\n`;
  text += `Перенесено: ${rescheduled}\n`;
  text += `Оплачено: ${paidCount}\n`;
  text += `Не оплачено: ${unpaidCount}\n\n`;
  text += `Оплата по занятиям: ${formatMoney(receivedTotal)}\n`;
  text += `Предоплаты за год: ${formatMoney(prepaymentTotal)}\n`;
  text += `Всего получено за год: ${formatMoney(grandReceived)}\n`;
  text += `Общий долг: ${formatMoney(debtTotal)}\n\n`;
  text += `По месяцам:\n`;
  byMonth.forEach((m) => {
    text += `${m.label}: ${m.count} занятий (проведено ${m.conducted}, доход ${formatMoney(
      m.revenue
    )})\n`;
  });
  text += `\nПо ученикам:\n`;
  byStudent.forEach((s) => {
    text += `- ${s.studentName} — ${s.total} занятий (проведено ${s.conducted}, доход ${formatMoney(
      s.revenue
    )}${s.debt > 0 ? `, долг ${formatMoney(s.debt)}` : ""})\n`;
  });
  text += `\nИтог:\nЗа ${year} год проведено ${conducted.length} занятий, получено ${formatMoney(
    grandReceived
  )}.${
    debtTotal > 0
      ? ` Остался долг ${formatMoney(debtTotal)}.`
      : " Долгов нет."
  }`;

  return {
    year,
    total: lessons.length,
    conducted: conducted.length,
    cancelled,
    rescheduled,
    planned,
    noShow,
    paid: paidCount,
    unpaid: unpaidCount,
    receivedTotal,
    prepaymentTotal,
    grandReceived,
    debtTotal,
    byMonth,
    byStudent,
    text,
  };
}

// ---------------------------------------------------------------------------
// Tax reminder
// ---------------------------------------------------------------------------

/** Get the current tax-reminder status (due = should show now). */
export async function getTaxReminderStatus(): Promise<TaxReminderStatus> {
  const settings = await getSettings();
  const tz = settings.timezone;
  const now = nowInTZ(tz);
  const today = now.date;
  const lastDone = settings.taxReminderLastDone || null;
  const todayDone = lastDone === today;

  let due = false;
  if (settings.taxReminderEnabled && !todayDone) {
    // due if current time >= reminder time
    const [rh, rm] = settings.taxReminderTime.split(":").map(Number);
    const nowMin = now.hour * 60 + now.minute;
    const remMin = (rh ?? 0) * 60 + (rm ?? 0);
    due = nowMin >= remMin;
  }

  return {
    enabled: settings.taxReminderEnabled,
    time: settings.taxReminderTime,
    lastDone,
    todayDone,
    due,
  };
}

/** Mark the tax reminder done for today. */
export async function markTaxReminderDone(): Promise<void> {
  const settings = await getSettings();
  const tz = settings.timezone;
  const today = nowInTZ(tz).date;
  await saveSettings({ taxReminderLastDone: today });
}

/** Clear today's "done" mark (undo). */
export async function undoTaxReminderDone(): Promise<void> {
  await saveSettings({ taxReminderLastDone: "" });
}


// ---------------------------------------------------------------------------
// Student report (custom period)
// ---------------------------------------------------------------------------

export async function buildStudentReport(
  studentId: string,
  startDate: string,
  endDate: string
): Promise<import("@/lib/types").StudentReport> {
  const student = await db.student.findUnique({
    where: { id: studentId },
  });
  if (!student) {
    throw new Error("Ученик не найден");
  }

  const lessons = await db.lesson.findMany({
    where: { studentId, date: { gte: startDate, lte: endDate } },
    include: { student: true },
    orderBy: [{ date: "asc" }, { timeStart: "asc" }],
  });
  const typedLessons = lessons.map(toLessonWithStudent);

  // Prepayments within the period (by month overlap)
  const startMonth = startDate.slice(0, 7);
  const endMonth = endDate.slice(0, 7);
  const prepaymentsRaw = await db.monthlyPayment.findMany({
    where: {
      studentId,
      month: { gte: startMonth, lte: endMonth },
    },
    include: { student: true },
  });
  const prepayments = prepaymentsRaw.map((m) => ({
    id: m.id,
    studentId: m.studentId,
    student: {
      id: m.student.id,
      name: m.student.name,
      color: m.student.color,
    },
    month: m.month,
    lessonsCount: m.lessonsCount,
    amount: m.amount,
    paid: m.paid,
    paidAt: m.paidAt ? m.paidAt.toISOString() : null,
    comment: m.comment,
    createdAt: m.createdAt.toISOString(),
    updatedAt: m.updatedAt.toISOString(),
  }));

  // Carryover balance from months BEFORE startDate
  const carryover = await getStudentPrepaymentBalance(studentId, startMonth);

  const conducted = typedLessons.filter((l) => l.lessonStatus === "conducted");
  const cancelled = typedLessons.filter((l) => l.lessonStatus === "cancelled").length;
  const rescheduled = typedLessons.filter((l) => l.lessonStatus === "rescheduled").length;
  const planned = typedLessons.filter((l) => l.lessonStatus === "planned").length;
  const noShow = typedLessons.filter((l) => l.lessonStatus === "no_show").length;
  const paidCount = typedLessons.filter((l) => l.paymentStatus === "paid").length;
  const unpaidCount = typedLessons.filter((l) => isOwing(l)).length;

  const expectedTotal = typedLessons.reduce((s, l) => s + expectedAmount(l), 0);
  const receivedTotal = typedLessons.reduce((s, l) => s + receivedAmount(l), 0);
  const debtTotal = typedLessons.reduce((s, l) => s + debtAmount(l), 0);
  const prepaymentTotal = prepayments
    .filter((p) => p.paid)
    .reduce((s, p) => s + p.amount, 0);
  const grandReceived = receivedTotal + prepaymentTotal;

  // Build text report
  const fmtDate = (d: string) => formatShortDate(d);
  let text = `Отчёт по ученику: ${student.name}\n`;
  text += `Период: ${fmtDate(startDate)} — ${fmtDate(endDate)}\n\n`;
  if (student.grade) text += `Класс: ${student.grade}\n`;
  if (student.phone) text += `Телефон: ${student.phone}\n`;
  if (student.pricePerLesson) text += `Цена за урок: ${formatMoney(student.pricePerLesson)}\n`;
  text += `\nВсего занятий: ${typedLessons.length}\n`;
  text += `Проведено: ${conducted.length}\n`;
  text += `Отменено: ${cancelled}\n`;
  text += `Перенесено: ${rescheduled}\n`;
  text += `Запланировано: ${planned}\n`;
  text += `Неявки: ${noShow}\n\n`;
  text += `Оплачено: ${paidCount}\n`;
  text += `Не оплачено: ${unpaidCount}\n\n`;
  text += `Сумма к оплате: ${formatMoney(expectedTotal)}\n`;
  text += `Получено по занятиям: ${formatMoney(receivedTotal)}\n`;
  if (prepaymentTotal > 0) {
    text += `Предоплаты за период: ${formatMoney(prepaymentTotal)}\n`;
  }
  text += `Всего получено: ${formatMoney(grandReceived)}\n`;
  text += `Долг: ${formatMoney(debtTotal)}\n`;
  if (carryover.total > 0) {
    text += `Остаток с прошлых месяцев: ${formatMoney(carryover.total)}\n`;
  }

  if (typedLessons.length > 0) {
    text += `\nЗанятия:\n`;
    typedLessons.forEach((l, i) => {
      const statusMap: Record<string, string> = {
        planned: "запланировано",
        conducted: "проведено",
        cancelled: "отменено",
        rescheduled: "перенесено",
        no_show: "неявка",
      };
      const payMap: Record<string, string> = {
        paid: "оплачено",
        unpaid: "не оплачено",
        partial: "частично",
        awaiting_confirmation: "ожидает подтверждения",
        refund: "возврат",
        free_trial: "бесплатно",
      };
      text += `${i + 1}. ${fmtDate(l.date)} ${l.timeStart} — ${statusMap[l.lessonStatus] ?? l.lessonStatus} — ${payMap[l.paymentStatus] ?? l.paymentStatus} — ${formatMoney(l.price)}\n`;
    });
  }

  if (prepayments.length > 0) {
    text += `\nПредоплаты за период:\n`;
    prepayments.forEach((p) => {
      text += `- ${monthLabel(p.month)} — ${p.lessonsCount} занятий — ${formatMoney(p.amount)} — ${p.paid ? "оплачено" : "не оплачено"}\n`;
    });
  }

  if (carryover.total > 0) {
    text += `\nОстались деньги с прошлых месяцев:\n`;
    for (const it of carryover.items) {
      text += `- с ${it.monthLabel} — ${formatMoney(it.amount)} (${it.unusedLessons} из ${it.lessonsCount} занятий не проведено)\n`;
    }
  }

  let summary = `\nИтог:\nЗа период с ${fmtDate(startDate)} по ${fmtDate(endDate)} проведено ${conducted.length} из ${typedLessons.length} занятий.`;
  summary += ` Получено ${formatMoney(grandReceived)}.`;
  if (debtTotal > 0) {
    summary += ` Долг: ${formatMoney(debtTotal)}.`;
  } else {
    summary += ` Долгов нет.`;
  }
  text += summary;

  return {
    student: {
      id: student.id,
      name: student.name,
      color: student.color,
      phone: student.phone,
      email: student.email,
      grade: student.grade,
      pricePerLesson: student.pricePerLesson,
      comment: student.comment,
    },
    startDate,
    endDate,
    total: typedLessons.length,
    conducted: conducted.length,
    cancelled,
    rescheduled,
    planned,
    noShow,
    paid: paidCount,
    unpaid: unpaidCount,
    expectedTotal,
    receivedTotal,
    debtTotal,
    prepaymentTotal,
    grandReceived,
    lessons: typedLessons,
    prepayments,
    carryoverBalanceTotal: carryover.total,
    text,
  };
}
