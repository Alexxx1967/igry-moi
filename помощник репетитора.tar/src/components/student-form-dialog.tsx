"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { cn } from "@/lib/utils";
import { STUDENT_COLORS, colorClasses } from "@/lib/constants";
import { toast } from "sonner";
import type { StudentWithStats } from "@/lib/types";
import {
  useCreateStudent,
  useUpdateStudent,
} from "@/lib/hooks";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  student?: StudentWithStats | null;
};

export function StudentFormDialog({ open, onOpenChange, student }: Props) {
  const isEdit = !!student;
  const createMut = useCreateStudent();
  const updateMut = useUpdateStudent();

  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [email, setEmail] = useState("");
  const [grade, setGrade] = useState("");
  const [pricePerLesson, setPricePerLesson] = useState("");
  const [comment, setComment] = useState("");
  const [color, setColor] = useState<string>("emerald");

  useEffect(() => {
    if (!open) return;
    if (student) {
      setName(student.name);
      setPhone(student.phone ?? "");
      setEmail(student.email ?? "");
      setGrade(student.grade ?? "");
      setPricePerLesson(student.pricePerLesson != null ? String(student.pricePerLesson) : "");
      setComment(student.comment ?? "");
      setColor(student.color);
    } else {
      setName("");
      setPhone("");
      setEmail("");
      setGrade("");
      setPricePerLesson("");
      setComment("");
      setColor("emerald");
    }
  }, [open, student]);

  function handleSubmit() {
    if (!name.trim()) {
      toast.error("Укажите имя ученика");
      return;
    }
    const body = {
      name: name.trim(),
      phone: phone.trim() || null,
      email: email.trim() || null,
      grade: grade.trim() || null,
      pricePerLesson: pricePerLesson ? Number(pricePerLesson) : null,
      comment: comment.trim() || null,
      color,
    };
    const action = isEdit
      ? updateMut.mutateAsync({ id: student!.id, body })
      : createMut.mutateAsync(body);
    action
      .then(() => {
        toast.success(isEdit ? "Ученик обновлён" : "Ученик добавлен");
        onOpenChange(false);
      })
      .catch((e: Error) => toast.error(e.message));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Редактировать ученика" : "Новый ученик"}</DialogTitle>
          <DialogDescription>
            Контактные данные и заметки об ученике.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          <div className="grid gap-1.5">
            <Label htmlFor="sf-name">Имя и фамилия *</Label>
            <Input
              id="sf-name"
              placeholder="Анна Иванова"
              value={name}
              onChange={(e) => setName(e.target.value)}
            />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="sf-phone">Телефон</Label>
              <Input
                id="sf-phone"
                placeholder="+7 ..."
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="sf-email">Email</Label>
              <Input
                id="sf-email"
                type="email"
                placeholder="anna@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </div>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="sf-grade">Класс / курс</Label>
              <Input
                id="sf-grade"
                placeholder="Напр. 5 класс, 11 класс, студент"
                value={grade}
                onChange={(e) => setGrade(e.target.value)}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="sf-price">Цена за урок, ₽</Label>
              <Input
                id="sf-price"
                type="number"
                min={0}
                placeholder="Напр. 1500"
                value={pricePerLesson}
                onChange={(e) => setPricePerLesson(e.target.value)}
              />
            </div>
          </div>
          <div className="grid gap-1.5">
            <Label>Цвет метки</Label>
            <div className="flex flex-wrap gap-2">
              {STUDENT_COLORS.map((c) => {
                const cls = colorClasses(c);
                return (
                  <button
                    key={c}
                    type="button"
                    onClick={() => setColor(c)}
                    className={cn(
                      "h-8 w-8 rounded-full border-2 transition",
                      cls.dot,
                      color === c
                        ? "border-foreground scale-110"
                        : "border-transparent"
                    )}
                    aria-label={c}
                  />
                );
              })}
            </div>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="sf-comment">Комментарий</Label>
            <Textarea
              id="sf-comment"
              rows={2}
              placeholder="Уровень, цели, особенности..."
              value={comment}
              onChange={(e) => setComment(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Отмена
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!name.trim() || createMut.isPending || updateMut.isPending}
          >
            {isEdit ? "Сохранить" : "Добавить"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
