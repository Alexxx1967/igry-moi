import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  computeMonthlyPaymentInfo,
  getSettings,
  getStudentPrepaymentBalance,
} from "@/lib/report";
import { monthOf, todayInTZ } from "@/lib/tz";

// GET students with aggregated stats + current-month prepayment info + carryover balance
export async function GET() {
  const settings = await getSettings();
  const today = todayInTZ(settings.timezone);
  const currentMonth = monthOf(today);

  const students = await db.student.findMany({
    include: {
      lessons: {
        select: {
          date: true,
          lessonStatus: true,
          paymentStatus: true,
          price: true,
          paidAmount: true,
        },
      },
    },
    orderBy: { name: "asc" },
  });

  const result = await Promise.all(
    students.map(async (s) => {
      let conducted = 0;
      let unpaid = 0;
      let debt = 0;
      for (const l of s.lessons) {
        if (l.lessonStatus === "conducted") conducted += 1;
        if (
          l.lessonStatus === "conducted" &&
          (l.paymentStatus === "unpaid" || l.paymentStatus === "partial")
        ) {
          unpaid += 1;
          debt += Math.max(0, l.price - l.paidAmount);
        }
      }
      const monthPrepaid = await computeMonthlyPaymentInfo(
        s.id,
        currentMonth
      );
      const balance = await getStudentPrepaymentBalance(s.id, currentMonth);
      return {
        id: s.id,
        name: s.name,
        phone: s.phone,
        email: s.email,
        grade: s.grade,
        pricePerLesson: s.pricePerLesson,
        comment: s.comment,
        color: s.color,
        createdAt: s.createdAt.toISOString(),
        totalLessons: s.lessons.length,
        conductedLessons: conducted,
        unpaidLessons: unpaid,
        debt,
        monthPrepaid,
        prepaymentBalance: balance.items,
        prepaymentBalanceTotal: balance.total,
      };
    })
  );

  return NextResponse.json(result);
}

export async function POST(req: NextRequest) {
  const body = await req.json();
  const { name, phone, email, grade, pricePerLesson, comment, color } = body;
  if (!name || !String(name).trim()) {
    return NextResponse.json({ error: "Укажите имя ученика" }, { status: 400 });
  }
  const created = await db.student.create({
    data: {
      name: String(name).trim(),
      phone: phone || null,
      email: email || null,
      grade: grade || null,
      pricePerLesson: pricePerLesson ? Number(pricePerLesson) : null,
      comment: comment || null,
      color: color || "emerald",
    },
  });
  return NextResponse.json(created, { status: 201 });
}
