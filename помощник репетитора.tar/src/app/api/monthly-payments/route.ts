import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import {
  getMonthlyPaymentsForMonth,
  upsertMonthlyPayment,
} from "@/lib/report";

// GET /api/monthly-payments?month=YYYY-MM
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const month = searchParams.get("month");
  if (!month) {
    return NextResponse.json({ error: "Укажите month (YYYY-MM)" }, { status: 400 });
  }
  const rows = await getMonthlyPaymentsForMonth(month);
  return NextResponse.json(rows);
}

// POST /api/monthly-payments { studentId, month, lessonsCount, amount, paid?, comment? }
export async function POST(req: NextRequest) {
  const body = await req.json();
  const { studentId, month, lessonsCount, amount, paid, comment } = body;
  if (!studentId || !month) {
    return NextResponse.json(
      { error: "Укажите studentId и month (YYYY-MM)" },
      { status: 400 }
    );
  }
  // validate student exists
  const student = await db.student.findUnique({ where: { id: studentId } });
  if (!student) {
    return NextResponse.json({ error: "Ученик не найден" }, { status: 404 });
  }
  const row = await upsertMonthlyPayment({
    studentId,
    month,
    lessonsCount: Number(lessonsCount) || 0,
    amount: Number(amount) || 0,
    paid: paid !== undefined ? !!paid : true,
    comment: comment || null,
  });
  return NextResponse.json(row, { status: 201 });
}
