import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { SETTING_KEYS } from "@/lib/constants";

// POST /api/max/webhook — webhook for MAX bot events. When the tutor sends any
// message to the bot, MAX delivers a callback here. We extract the chat_id and
// store it in settings so sendToMax can use it later.
//
// Setup: in @MasterBot (MAX) set the webhook URL to:
//   https://<your-app-origin>/api/max/webhook
export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    // MAX bot API callback shape: { message: { recipient: { chat_id }, ... } }
    // or { callback_id, message: { recipient: { chat_id }, ... } }
    const chatId =
      body?.message?.recipient?.chat_id ??
      body?.message?.chat_id ??
      body?.chat_id ??
      body?.recipient?.chat_id;
    if (chatId) {
      await db.setting.upsert({
        where: { id: SETTING_KEYS.maxChatId },
        update: { value: String(chatId) },
        create: { id: SETTING_KEYS.maxChatId, value: String(chatId) },
      });
    }
    return NextResponse.json({ ok: true });
  } catch {
    return NextResponse.json({ ok: true });
  }
}

// GET — used to verify the webhook URL when registering it in MAX.
export async function GET() {
  return NextResponse.json({ ok: true, service: "max-webhook" });
}
