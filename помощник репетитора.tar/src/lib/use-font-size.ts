"use client";

import { useEffect, useState, useCallback } from "react";

const STORAGE_KEY = "ta:fontSize";
const MIN = 0; // index into SIZES
const MAX = 4;

// Font size multipliers. 0 = default, negative = smaller, positive = larger.
export const FONT_SIZES = [
  { label: "A", scale: 0.875, name: "Мелкий" },   // -1
  { label: "A", scale: 0.94, name: "Меньше" },     // -0.5
  { label: "A", scale: 1, name: "Обычный" },        // 0 (default)
  { label: "A", scale: 1.12, name: "Крупнее" },     // +1
  { label: "A", scale: 1.25, name: "Крупный" },     // +2
];
const DEFAULT_INDEX = 2;

/** Hook that manages the global font-size multiplier. Applies it to <html>
 *  via a CSS variable --font-scale, which globals.css uses to scale root font. */
export function useFontSize() {
  const [index, setIndex] = useState<number>(DEFAULT_INDEX);

  useEffect(() => {
    const stored = Number(localStorage.getItem(STORAGE_KEY));
    if (!isNaN(stored) && stored >= MIN && stored <= MAX) {
      setIndex(stored);
    }
  }, []);

  const apply = useCallback((i: number) => {
    const scale = FONT_SIZES[i].scale;
    document.documentElement.style.setProperty("--font-scale", String(scale));
    localStorage.setItem(STORAGE_KEY, String(i));
  }, []);

  const set = useCallback(
    (i: number) => {
      const clamped = Math.max(MIN, Math.min(MAX, i));
      setIndex(clamped);
      apply(clamped);
    },
    [apply]
  );

  const increase = useCallback(() => set(index + 1), [index, set]);
  const decrease = useCallback(() => set(index - 1), [index, set]);
  const reset = useCallback(() => set(DEFAULT_INDEX), [set]);

  // Apply on mount (in case it was loaded from storage).
  useEffect(() => {
    apply(index);
  }, [index, apply]);

  return {
    index,
    scale: FONT_SIZES[index].scale,
    name: FONT_SIZES[index].name,
    increase,
    decrease,
    reset,
    set,
    canIncrease: index < MAX,
    canDecrease: index > MIN,
  };
}
