"use client";

import { useEffect } from "react";

/** Registers the service worker on mount (client-only). */
export function ServiceWorkerRegister() {
  useEffect(() => {
    if (
      typeof window !== "undefined" &&
      "serviceWorker" in navigator &&
      process.env.NODE_ENV !== "development" ? true : true
    ) {
      navigator.serviceWorker
        .register("/sw.js", { scope: "/" })
        .then(() => {
          // console.log("SW registered");
        })
        .catch(() => {
          /* ignore registration errors */
        });
    }
  }, []);
  return null;
}
