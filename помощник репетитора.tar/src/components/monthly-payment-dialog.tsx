"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Switch } from "@/components/ui/switch";
import { toast } from "sonner";
import { Loader2, CalendarCheck, Trash2 } from "lucide-react";
import { StudentAvatar } from "@/components/status-badges";
import {
  useUpsertMonthlyPayment,
  useDeleteMonthlyPayment,
} from "@/lib/hooks";
import type { StudentWithStats } from "@/lib/types";
import { formatMoney, monthLabel } from "@/lib/tz";
import {
  Dialog as DDialog,
  DialogContent as DDialogContent,
  DialogDescription as DDialogDescription,
  DialogFooter as DDialogFooter,
  DialogHeader as DDialogHeader,
  DialogTitle as DDialogTitle,
} from "@/components/ui/dialog";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  student: StudentWithStats | null;
  month: string; // YYYY-MM
};

export function MonthlyPaymentDialog({
  open,
  onOpenChange,
  student,
  month,
}: Props) {
  const upsertMut = useUpsertMonthlyPayment();
  const deleteMut = useDeleteMonthlyPayment();
  const [lessonsCount, setLessonsCount] = useState(8);
  const [amount, setAmount] = useState(0);
  const [paid, setPaid] = useState(true);
  const [comment, setComment] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);

  useEffect(() => {
    if (!open || !student) return;
    const info = student.monthPrepaid;
    if (info) {
      setLessonsCount(info.lessonsCount);
      setAmount(info.amount);
      setPaid(info.paid);
      setComment(info.comment ?? "");
    } else {
      // sensible defaults based on this month's lessons
      const planned = info?.plannedThisMonth ?? 0;
      setLessonsCount(planned > 0 ? planned : 8);
      setAmount(0);
      setPaid(true);
      setComment("Предоплата за месяц");
    }
    setConfirmDelete(false);
  }, [open, student]);

  const info = student?.monthPrepaid ?? null;

  if (!student) return null;

  function handleSubmit() {
    if (lessonsCount <= 0) {
      toast.error("Укажите количество занятий (больше 0)");
      return;
    }
    upsertMut.mutate(
      {
        studentId: student!.id,
        month,
        lessonsCount: Number(lessonsCount),
        amount: Number(amount) || 0,
        paid,
        comment: comment.trim() || null,
      },
      {
        onSuccess: () => {
          toast.success(
            info
              ? "Предоплата обновлена"
              : `Предоплата за ${monthLabel(month)} отмечена`
          );
          onOpenChange(false);
        },
        onError: (e) => toast.error(e.message),
      }
    );
  }

  function handleDelete() {
    if (!info) return;
    deleteMut.mutate(info.id, {
      onSuccess: () => {
        toast.success("Предоплата удалена");
        onOpenChange(false);
      },
      onError: (e) => toast.error(e.message),
    });
  }

  const isEdit = !!info;
  const remaining = info ? info.remaining : 0;
  const conducted = info ? info.conductedThisMonth : 0;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[480px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <CalendarCheck className="h-5 w-5 text-emerald-600" />
            Оплата за месяц
          </DialogTitle>
          <DialogDescription>
            {monthLabel(month)} · предоплата за N занятий
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-3 rounded-lg border bg-muted/30 p-3">
          <StudentAvatar
            name={student.name}
            color={student.color}
            size="lg"
          />
          <div className="min-w-0 flex-1">
            <p className="truncate font-medium">{student.name}</p>
            <p className="text-sm text-muted-foreground">{monthLabel(month)}</p>
          </div>
        </div>

        {info && (
          <div className="grid grid-cols-3 gap-2 text-center text-sm">
            <div className="rounded-lg bg-muted/50 p-2">
              <p className="text-xs text-muted-foreground">Оплачено</p>
              <p className="font-semibold">{info.lessonsCount} зан.</p>
            </div>
            <div className="rounded-lg bg-muted/50 p-2">
              <p className="text-xs text-muted-foreground">Проведено</p>
              <p className="font-semibold">{conducted}</p>
            </div>
            <div
              className={
                remaining > 0
                  ? "rounded-lg bg-emerald-50 p-2 dark:bg-emerald-500/10"
                  : "rounded-lg bg-amber-50 p-2 dark:bg-amber-500/10"
              }
            >
              <p className="text-xs text-muted-foreground">Осталось</p>
              <p
                className={
                  remaining > 0
                    ? "font-semibold text-emerald-700 dark:text-emerald-300"
                    : "font-semibold text-amber-700 dark:text-amber-300"
                }
              >
                {remaining}
              </p>
            </div>
          </div>
        )}

        <div className="grid grid-cols-2 gap-3">
          <div className="grid gap-1.5">
            <Label htmlFor="mp-count">Количество занятий</Label>
            <Input
              id="mp-count"
              type="number"
              min={1}
              value={lessonsCount}
              onChange={(e) => setLessonsCount(Number(e.target.value))}
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="mp-amount">Сумма, ₽</Label>
            <Input
              id="mp-amount"
              type="number"
              min={0}
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
            />
          </div>
        </div>

        <div className="flex items-center justify-between rounded-lg border p-3">
          <div>
            <p className="text-sm font-medium">Оплачено</p>
            <p className="text-xs text-muted-foreground">
              Отметить, что деньги получены
            </p>
          </div>
          <Switch checked={paid} onCheckedChange={setPaid} />
        </div>

        <div className="grid gap-1.5">
          <Label htmlFor="mp-comment">Комментарий</Label>
          <Textarea
            id="mp-comment"
            rows={2}
            placeholder="Напр. предоплата за 8 занятий"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
          />
        </div>

        <DialogFooter className="flex-col gap-2 sm:flex-row sm:justify-between">
          <div>
            {isEdit &&
              (confirmDelete ? (
                <DDialog open={confirmDelete} onOpenChange={setConfirmDelete}>
                  <DDialogContent className="sm:max-w-[380px]">
                    <DDialogHeader>
                      <DDialogTitle>Удалить предоплату?</DDialogTitle>
                      <DDialogDescription>
                        Предоплата {student.name} за {monthLabel(month)} будет
                        удалена.
                      </DDialogDescription>
                    </DDialogHeader>
                    <DDialogFooter>
                      <Button
                        variant="outline"
                        onClick={() => setConfirmDelete(false)}
                      >
                        Отмена
                      </Button>
                      <Button
                        variant="destructive"
                        disabled={deleteMut.isPending}
                        onClick={handleDelete}
                      >
                        Удалить
                      </Button>
                    </DDialogFooter>
                  </DDialogContent>
                </DDialog>
              ) : (
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-rose-600 hover:text-rose-700"
                  onClick={() => setConfirmDelete(true)}
                >
                  <Trash2 className="mr-1 h-4 w-4" /> Удалить
                </Button>
              ))}
          </div>
          <div className="flex gap-2">
            <Button variant="outline" onClick={() => onOpenChange(false)}>
              Отмена
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={upsertMut.isPending}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {upsertMut.isPending ? (
                <Loader2 className="mr-1 h-4 w-4 animate-spin" />
              ) : null}
              {isEdit ? "Сохранить" : "Отметить оплаченным"}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
