"use client";

import { useEffect, useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  ChevronLeft,
  ChevronRight,
  Plus,
  CalendarDays,
  Wand2,
} from "lucide-react";
import { useLessons, useSettings } from "@/lib/hooks";
import {
  addDays,
  formatDayMonth,
  formatLongDate,
  formatShortDate,
  startOfWeek,
  weekdayName,
  weekdayShort,
  todayInTZ,
} from "@/lib/tz";
import { LessonItem } from "@/components/lesson-item";
import { LessonFormDialog } from "@/components/lesson-form-dialog";
import { ParseScheduleDialog } from "@/components/parse-schedule-dialog";
import { StudentDot } from "@/components/status-badges";

type Props = {
  addLessonSignal: number;
};

export function ScheduleSection({ addLessonSignal }: Props) {
  const { data: settings } = useSettings();
  const tz = settings?.timezone ?? "Europe/Moscow";
  const today = todayInTZ(tz);

  const [weekStart, setWeekStart] = useState(() => startOfWeek(today));
  const [selectedDate, setSelectedDate] = useState<string>(today);
  const [addOpen, setAddOpen] = useState(false);
  const [parseOpen, setParseOpen] = useState(false);

  // Open add dialog when parent signals
  useEffect(() => {
    if (addLessonSignal > 0) setAddOpen(true);
  }, [addLessonSignal]);

  const weekDays = useMemo(
    () => Array.from({ length: 7 }, (_, i) => addDays(weekStart, i)),
    [weekStart]
  );

  const from = weekDays[0];
  const to = weekDays[6];
  const { data: lessons = [], isLoading } = useLessons({ from, to });

  const lessonsByDate = useMemo(() => {
    const map = new Map<string, typeof lessons>();
    for (const l of lessons) {
      const arr = map.get(l.date) ?? [];
      arr.push(l);
      map.set(l.date, arr);
    }
    return map;
  }, [lessons]);

  const selectedLessons = (lessonsByDate.get(selectedDate) ?? []).slice().sort(
    (a, b) => a.timeStart.localeCompare(b.timeStart)
  );

  return (
    <div className="grid gap-5">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Расписание</h1>
          <p className="text-sm text-muted-foreground">
            Неделя: {formatShortDate(from)} — {formatShortDate(to)} · {tz}
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Button variant="outline" size="sm" onClick={() => setParseOpen(true)}>
            <Wand2 className="mr-1 h-4 w-4 text-emerald-600" /> Распознать текст
          </Button>
          <Button
            size="sm"
            onClick={() => {
              setSelectedDate(today);
              setAddOpen(true);
            }}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            <Plus className="mr-1 h-4 w-4" /> Занятие
          </Button>
        </div>
      </div>

      <div className="flex items-center justify-between">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setWeekStart(addDays(weekStart, -7))}
        >
          <ChevronLeft className="h-4 w-4" /> Назад
        </Button>
        <Button
          variant="outline"
          size="sm"
          onClick={() => {
            setWeekStart(startOfWeek(today));
            setSelectedDate(today);
          }}
        >
          Сегодня
        </Button>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => setWeekStart(addDays(weekStart, 7))}
        >
          Вперёд <ChevronRight className="h-4 w-4" />
        </Button>
      </div>

      {/* Week grid */}
      <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 lg:grid-cols-7">
        {weekDays.map((date) => {
          const dayLessons = lessonsByDate.get(date) ?? [];
          const isToday = date === today;
          const isSelected = date === selectedDate;
          return (
            <button
              key={date}
              onClick={() => setSelectedDate(date)}
              className={cn(
                "flex flex-col items-start rounded-xl border p-3 text-left transition",
                isSelected
                  ? "border-emerald-500 bg-emerald-50 dark:border-emerald-500/50 dark:bg-emerald-500/10"
                  : "hover:border-emerald-300 hover:bg-muted/40 dark:hover:border-emerald-500/30",
                isToday && !isSelected && "ring-1 ring-emerald-400"
              )}
            >
              <span className="text-xs font-medium uppercase text-muted-foreground">
                {weekdayShort(date)}
              </span>
              <span
                className={cn(
                  "text-lg font-semibold",
                  isToday && "text-emerald-600 dark:text-emerald-400"
                )}
              >
                {formatDayMonth(date).split(" ")[0]}
              </span>
              <span className="mt-0.5 text-xs text-muted-foreground">
                {dayLessons.length > 0
                  ? `${dayLessons.length} ${pluralLessons(dayLessons.length)}`
                  : "—"}
              </span>
              {dayLessons.length > 0 && (
                <div className="mt-2 flex flex-wrap gap-1">
                  {dayLessons.slice(0, 5).map((l) => (
                    <StudentDot key={l.id} color={l.student.color} />
                  ))}
                  {dayLessons.length > 5 && (
                    <span className="text-[10px] text-muted-foreground">
                      +{dayLessons.length - 5}
                    </span>
                  )}
                </div>
              )}
            </button>
          );
        })}
      </div>

      {/* Selected day detail */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="text-base">
            {weekdayName(selectedDate)}, {formatLongDate(selectedDate)}
          </CardTitle>
          <Button
            variant="ghost"
            size="sm"
            onClick={() => setAddOpen(true)}
          >
            <Plus className="mr-1 h-4 w-4" /> Добавить на этот день
          </Button>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="grid gap-2">
              {Array.from({ length: 3 }).map((_, i) => (
                <Skeleton key={i} className="h-20 w-full" />
              ))}
            </div>
          ) : selectedLessons.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 py-10 text-center">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-muted-foreground">
                <CalendarDays className="h-5 w-5" />
              </div>
              <p className="text-sm font-medium">Занятий нет</p>
              <p className="text-xs text-muted-foreground">
                Добавьте занятие или распознайте расписание из текста.
              </p>
            </div>
          ) : (
            <div className="grid max-h-[40rem] gap-2 overflow-y-auto pr-1">
              {selectedLessons.map((l) => (
                <LessonItem key={l.id} lesson={l} />
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <LessonFormDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        defaultDate={selectedDate}
      />
      <ParseScheduleDialog open={parseOpen} onOpenChange={setParseOpen} />
    </div>
  );
}

function pluralLessons(n: number) {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return "занятие";
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return "занятия";
  return "занятий";
}
