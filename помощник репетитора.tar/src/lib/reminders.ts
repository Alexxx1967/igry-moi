// Reminder logic: determines which reminder tier a lesson falls into,
// and builds reminder message texts.

import type { LessonWithStudent, Settings } from "@/lib/types";
import {
  LESSON_FORMAT_LABELS,
  PAYMENT_STATUS_LABELS,
  type LessonFormat,
  type PaymentStatus,
} from "@/lib/constants";
import { endTime, formatMoney, minutesUntilLesson, relativeFromMinutes } from "@/lib/tz";

export type ReminderTier = "30min" | "1h" | "15min" | "now" | "past" | "none";

/**
 * Determine the active reminder tier for a lesson given minutes-until-start.
 * Standard schedule: 30min, 1h, 15min.
 */
export function reminderTierFor(
  minutesUntil: number,
  settings: Settings
): ReminderTier {
  if (minutesUntil < -5) return "past";
  if (minutesUntil < 15) return "now";
  if (settings.reminder15min && minutesUntil <= 15) return "15min";
  // 30-min preliminary reminder
  if (settings.reminder30min && minutesUntil <= 30 && minutesUntil > 15)
    return "30min";
  if (settings.reminder1h && minutesUntil <= 60 && minutesUntil > 30) return "1h";
  if (minutesUntil > 60) return "none";
  return "none";
}

export function tierLabel(tier: ReminderTier): string {
  switch (tier) {
    case "30min":
      return "Предварительное (за 30 мин)";
    case "1h":
      return "Основное (за 1 ч)";
    case "15min":
      return "Срочное (за 15 мин)";
    case "now":
      return "Скоро начнётся";
    case "past":
      return "Началось/прошло";
    default:
      return "—";
  }
}

/** Build a reminder message for the tutor, length adapts to tier. */
export function buildTutorReminder(
  lesson: LessonWithStudent,
  tier: ReminderTier,
  timeZone: string
): string {
  const paymentLabel = PAYMENT_STATUS_LABELS[lesson.paymentStatus as PaymentStatus];
  const formatLabel = LESSON_FORMAT_LABELS[lesson.format as LessonFormat] ?? lesson.format;
  const minutesUntil = minutesUntilLesson(lesson.date, lesson.timeStart, timeZone);

  if (tier === "now" || tier === "15min") {
    return `Скоро занятие: ${lesson.student.name}, ${lesson.timeStart}, ${lesson.subject}.`;
  }
  if (tier === "30min") {
    return `Через 30 минут занятие: ${lesson.student.name}, ${lesson.timeStart}, ${lesson.subject}, ${lesson.durationMinutes} мин, ${formatLabel}. Оплата: ${paymentLabel}.`;
  }
  if (tier === "1h") {
    return `Через 1 час занятие: ${lesson.student.name}, ${lesson.timeStart}, ${lesson.subject}, ${lesson.durationMinutes} мин, ${formatLabel}. Оплата: ${paymentLabel}.`;
  }
  // default
  const linkPart = lesson.link ? ` Ссылка: ${lesson.link}.` : "";
  return `Напоминание: ${lesson.date} в ${lesson.timeStart} занятие с ${lesson.student.name}. ${lesson.subject}, ${lesson.durationMinutes} мин, ${formatLabel}.${linkPart} Статус оплаты: ${paymentLabel}.`;
}

/** Relative countdown text for UI badges. */
export function countdownText(
  lesson: LessonWithStudent,
  timeZone: string
): string {
  const m = minutesUntilLesson(lesson.date, lesson.timeStart, timeZone);
  return relativeFromMinutes(m);
}

/** Full lesson summary line used in lists. */
export function lessonSummary(lesson: LessonWithStudent): string {
  return `${lesson.timeStart}–${endTime(lesson.timeStart, lesson.durationMinutes)} · ${lesson.subject} · ${LESSON_FORMAT_LABELS[lesson.format as LessonFormat] ?? lesson.format}`;
}

/** Soft payment reminder text for a student. */
export function buildStudentPaymentReminder(
  lesson: LessonWithStudent,
  tutorName: string
): string {
  const name = lesson.student.name.split(" ")[0];
  const tutor = tutorName ? tutorName : "Я";
  const amount = Math.max(0, lesson.price - lesson.paidAmount);
  const amountStr = amount > 0 ? ` (${formatMoney(amount)})` : "";
  return `Здравствуйте, ${name}! Спасибо за занятие ${lesson.date} в ${lesson.timeStart}. Напоминаю, что оплата за занятие пока не отмечена${amountStr}. Если вы уже оплатили, пожалуйста, сообщите, чтобы я отметил(а) оплату.\n\nС уважением,\n${tutor === "Я" ? "Ваш репетитор" : tutor}`;
}
