"use client";

import { useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Wallet,
  CheckCircle2,
  AlertTriangle,
  Clock3,
  Sparkles,
  Copy,
  Check,
} from "lucide-react";
import { useLessons, useSettings, useUpdatePayment } from "@/lib/hooks";
import {
  formatMoney,
  formatShortDate,
  addDays,
  todayInTZ,
} from "@/lib/tz";
import {
  LessonStatusBadge,
  PaymentStatusBadge,
  StudentAvatar,
} from "@/components/status-badges";
import { PaymentReminderDialog } from "@/components/payment-reminder-dialog";
import { toast } from "sonner";
import type { LessonWithStudent } from "@/lib/types";

type Tab = "debt" | "unpaid" | "awaiting" | "all";

export function PaymentsSection() {
  const { data: settings } = useSettings();
  const tz = settings?.timezone ?? "Europe/Moscow";
  const today = todayInTZ(tz);
  const from = addDays(today, -30);
  const to = addDays(today, 30);
  const { data: lessons = [], isLoading } = useLessons({ from, to });
  const updatePayMut = useUpdatePayment();
  const [tab, setTab] = useState<Tab>("debt");
  const [reminderLesson, setReminderLesson] = useState<LessonWithStudent | null>(null);

  const filtered = useMemo(() => {
    let list = lessons;
    if (tab === "debt") {
      list = lessons.filter(
        (l) =>
          l.lessonStatus === "conducted" &&
          (l.paymentStatus === "unpaid" || l.paymentStatus === "partial")
      );
    } else if (tab === "unpaid") {
      list = lessons.filter((l) => l.paymentStatus === "unpaid");
    } else if (tab === "awaiting") {
      list = lessons.filter((l) => l.paymentStatus === "awaiting_confirmation");
    } else {
      list = lessons.filter(
        (l) =>
          l.paymentStatus !== "paid" && l.paymentStatus !== "free_trial"
      );
    }
    return list.slice().sort((a, b) => {
      if (a.date !== b.date) return b.date.localeCompare(a.date);
      return b.timeStart.localeCompare(a.timeStart);
    });
  }, [lessons, tab]);

  const debtTotal = useMemo(
    () =>
      lessons
        .filter(
          (l) =>
            l.lessonStatus === "conducted" &&
            (l.paymentStatus === "unpaid" || l.paymentStatus === "partial")
        )
        .reduce((s, l) => s + Math.max(0, l.price - l.paidAmount), 0),
    [lessons]
  );

  const debtorsCount = useMemo(
    () =>
      new Set(
        lessons
          .filter(
            (l) =>
              l.lessonStatus === "conducted" &&
              (l.paymentStatus === "unpaid" || l.paymentStatus === "partial")
          )
          .map((l) => l.studentId)
      ).size,
    [lessons]
  );

  const received = useMemo(
    () =>
      lessons
        .filter(
          (l) => l.lessonStatus === "conducted" && l.paymentStatus === "paid"
        )
        .reduce((s, l) => s + l.price, 0),
    [lessons]
  );

  function markPaid(l: LessonWithStudent) {
    updatePayMut.mutate(
      { id: l.id, body: { paymentStatus: "paid" } },
      {
        onSuccess: () =>
          toast.success(
            `Оплата от ${l.student.name} отмечена. Занятие от ${formatShortDate(
              l.date
            )} оплачено.`
          ),
        onError: (e) => toast.error(e.message),
      }
    );
  }

  return (
    <div className="grid gap-5">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Оплаты</h1>
        <p className="text-sm text-muted-foreground">
          Учёт оплат и должников за последние 30 дней до и после сегодня.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <SummaryCard
          icon={<AlertTriangle className="h-5 w-5" />}
          label="Общий долг"
          value={formatMoney(debtTotal)}
          sub={`${debtorsCount} ${pluralDebtors(debtorsCount)}`}
          tone="rose"
        />
        <SummaryCard
          icon={<Clock3 className="h-5 w-5" />}
          label="Ожидает подтверждения"
          value={String(
            lessons.filter((l) => l.paymentStatus === "awaiting_confirmation").length
          )}
          sub="занятий"
          tone="violet"
        />
        <SummaryCard
          icon={<CheckCircle2 className="h-5 w-5" />}
          label="Получено (проведено+оплачено)"
          value={formatMoney(received)}
          sub="за период"
          tone="emerald"
        />
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as Tab)}>
        <TabsList className="flex-wrap">
          <TabsTrigger value="debt">Должники</TabsTrigger>
          <TabsTrigger value="unpaid">Не оплачено</TabsTrigger>
          <TabsTrigger value="awaiting">Ожидает подтверждения</TabsTrigger>
          <TabsTrigger value="all">Все неоплаченные</TabsTrigger>
        </TabsList>
      </Tabs>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">
            {tab === "debt"
              ? "Проведено, но не оплачено"
              : tab === "unpaid"
                ? "Неоплаченные занятия"
                : tab === "awaiting"
                  ? "Ожидают подтверждения оплаты"
                  : "Все занятия без полной оплаты"}
          </CardTitle>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="grid gap-2">
              {Array.from({ length: 4 }).map((_, i) => (
                <Skeleton key={i} className="h-16 w-full" />
              ))}
            </div>
          ) : filtered.length === 0 ? (
            <div className="flex flex-col items-center justify-center gap-2 py-10 text-center">
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-emerald-50 text-emerald-600 dark:bg-emerald-500/10">
                <CheckCircle2 className="h-5 w-5" />
              </div>
              <p className="text-sm font-medium">Всё оплачено</p>
              <p className="text-xs text-muted-foreground">
                Нет занятий по этой категории.
              </p>
            </div>
          ) : (
            <div className="grid max-h-[42rem] gap-2 overflow-y-auto pr-1">
              {filtered.map((l) => {
                const debt = Math.max(0, l.price - l.paidAmount);
                const isOwing =
                  l.lessonStatus === "conducted" &&
                  (l.paymentStatus === "unpaid" ||
                    l.paymentStatus === "partial");
                return (
                  <div
                    key={l.id}
                    className={cn(
                      "flex items-center gap-3 rounded-xl border bg-card p-3",
                      isOwing &&
                        "border-rose-200 bg-rose-50/40 dark:border-rose-500/30 dark:bg-rose-500/5"
                    )}
                  >
                    <StudentAvatar
                      name={l.student.name}
                      color={l.student.color}
                      size="sm"
                    />
                    <div className="min-w-0 flex-1">
                      <div className="flex flex-wrap items-center gap-x-2">
                        <span className="font-medium">{l.student.name}</span>
                        <span className="text-xs text-muted-foreground">
                          {formatShortDate(l.date)} · {l.timeStart}
                        </span>
                      </div>
                      <div className="text-sm text-muted-foreground">
                        {l.subject}
                      </div>
                      <div className="mt-1 flex flex-wrap items-center gap-1.5">
                        <LessonStatusBadge status={l.lessonStatus} />
                        <PaymentStatusBadge status={l.paymentStatus} />
                        <span className="text-xs text-muted-foreground">
                          {formatMoney(l.price)}
                          {l.paidAmount > 0 && l.paymentStatus === "partial" && (
                            <span className="ml-1 text-amber-600">
                              (оплачено {formatMoney(l.paidAmount)})
                            </span>
                          )}
                        </span>
                      </div>
                    </div>
                    <div className="flex flex-col items-end gap-1.5">
                      {isOwing && (
                        <span className="text-sm font-semibold text-rose-600">
                          {formatMoney(debt)}
                        </span>
                      )}
                      <div className="flex items-center gap-1">
                        {isOwing && (
                          <Button
                            size="sm"
                            variant="outline"
                            className="h-7 border-emerald-300 text-emerald-700 hover:bg-emerald-50 dark:border-emerald-500/40 dark:text-emerald-300"
                            onClick={() => markPaid(l)}
                            disabled={updatePayMut.isPending}
                          >
                            <Check className="mr-1 h-3.5 w-3.5" /> Оплачено
                          </Button>
                        )}
                        {isOwing && (
                          <Button
                            size="sm"
                            variant="ghost"
                            className="h-7"
                            onClick={() => setReminderLesson(l)}
                          >
                            <Sparkles className="mr-1 h-3.5 w-3.5 text-emerald-600" />
                            Напомнить
                          </Button>
                        )}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </CardContent>
      </Card>

      <PaymentReminderDialog
        open={!!reminderLesson}
        onOpenChange={(v) => !v && setReminderLesson(null)}
        lesson={reminderLesson}
      />
    </div>
  );
}

function SummaryCard({
  icon,
  label,
  value,
  sub,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string;
  sub: string;
  tone: "rose" | "emerald" | "violet";
}) {
  const tones = {
    rose: "text-rose-600 bg-rose-50 dark:bg-rose-500/10 dark:text-rose-300",
    emerald:
      "text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 dark:text-emerald-300",
    violet:
      "text-violet-600 bg-violet-50 dark:bg-violet-500/10 dark:text-violet-300",
  };
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center gap-3">
          <span
            className={cn(
              "flex h-10 w-10 items-center justify-center rounded-xl",
              tones[tone]
            )}
          >
            {icon}
          </span>
          <div>
            <p className="text-xs text-muted-foreground">{label}</p>
            <p className="text-xl font-semibold tracking-tight">{value}</p>
            <p className="text-xs text-muted-foreground">{sub}</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}

function pluralDebtors(n: number) {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return "должник";
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return "должника";
  return "должников";
}
