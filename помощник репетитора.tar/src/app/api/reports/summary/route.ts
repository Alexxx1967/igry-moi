import { NextRequest, NextResponse } from "next/server";
import { generateWeeklySummary } from "@/lib/llm";
import { buildWeeklyReport, getSettings } from "@/lib/report";
import { todayInTZ } from "@/lib/tz";

// POST /api/reports/summary  -> AI-generated weekly summary text
export async function POST(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const settings = await getSettings();
  const date = searchParams.get("date") ?? todayInTZ(settings.timezone);
  const report = await buildWeeklyReport(date);
  const summary = await generateWeeklySummary(report.text);
  return NextResponse.json({ summary });
}
