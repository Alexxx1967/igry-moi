import { NextResponse } from "next/server";
import { markTaxReminderDone } from "@/lib/report";

// POST /api/tax-reminder/done — mark today's tax reminder as done
export async function POST() {
  await markTaxReminderDone();
  return NextResponse.json({ ok: true });
}
