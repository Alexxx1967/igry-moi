"use client";

import { useRef, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { Loader2, Wand2, CheckCircle2, Upload, FileText } from "lucide-react";
import { api } from "@/lib/api-client";
import {
  useStudents,
  useCreateLesson,
  useSeed,
  useUploadDocxSchedule,
} from "@/lib/hooks";
import type { ParsedLesson } from "@/lib/llm";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
};

export function ParseScheduleDialog({ open, onOpenChange }: Props) {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [parsed, setParsed] = useState<ParsedLesson[] | null>(null);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [importing, setImporting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);
  const { data: students = [] } = useStudents();
  const createMut = useCreateLesson();
  const seedMut = useSeed();
  const uploadMut = useUploadDocxSchedule();

  function reset() {
    setText("");
    setParsed(null);
    setSelected(new Set());
  }

  async function handleFile(file: File) {
    if (!file.name.toLowerCase().endsWith(".docx")) {
      toast.error("Поддерживаются только .docx файлы");
      return;
    }
    setLoading(true);
    setParsed(null);
    try {
      const res = await uploadMut.mutateAsync(file);
      if (!res.lessons || res.lessons.length === 0) {
        toast.error("Не удалось распознать занятия в документе");
      } else {
        setParsed(res.lessons);
        setSelected(new Set(res.lessons.map((_, i) => i)));
        toast.success(`Распознано занятий: ${res.lessons.length}`);
      }
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  async function handleParse() {
    if (!text.trim()) {
      toast.error("Вставьте текст расписания");
      return;
    }
    setLoading(true);
    setParsed(null);
    try {
      const res = await api.post<{ lessons: ParsedLesson[] }>(
        "/api/parse-schedule",
        { text }
      );
      if (!res.lessons || res.lessons.length === 0) {
        toast.error("Не удалось распознать занятия. Попробуйте уточнить текст.");
      } else {
        setParsed(res.lessons);
        setSelected(new Set(res.lessons.map((_, i) => i)));
        toast.success(`Распознано занятий: ${res.lessons.length}`);
      }
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  function toggle(i: number) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });
  }

  async function handleImport() {
    if (!parsed) return;
    const toImport = parsed.filter((_, i) => selected.has(i));
    if (toImport.length === 0) {
      toast.error("Выберите хотя бы одно занятие");
      return;
    }
    setImporting(true);
    let ok = 0;
    let fail = 0;
    for (const p of toImport) {
      // Resolve student
      let studentId: string | undefined = undefined;
      let studentName: string | undefined = undefined;
      if (p.studentName) {
        const existing = students.find(
          (s) => s.name.toLowerCase() === p.studentName!.toLowerCase()
        );
        if (existing) studentId = existing.id;
        else studentName = p.studentName;
      }
      if (!p.date || !p.timeStart || (!studentId && !studentName)) {
        fail += 1;
        continue;
      }
      try {
        await createMut.mutateAsync({
          date: p.date,
          timeStart: p.timeStart,
          durationMinutes: p.durationMinutes ?? 60,
          studentId,
          studentName,
          subject: p.subject ?? "Занятие",
          format: p.format ?? "online",
          link: p.link ?? null,
          price: p.price ?? 0,
          paidAmount: 0,
          lessonStatus: p.lessonStatus ?? "planned",
          paymentStatus: p.paymentStatus ?? "unpaid",
          comment: p.comment ?? null,
        });
        ok += 1;
      } catch {
        fail += 1;
      }
    }
    setImporting(false);
    if (ok > 0)
      toast.success(`Импортировано занятий: ${ok}${fail ? `, пропущено: ${fail}` : ""}`);
    else toast.error("Не удалось импортировать занятия");
    if (ok > 0) {
      onOpenChange(false);
      reset();
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        onOpenChange(v);
        if (!v) reset();
      }}
    >
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-[640px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Wand2 className="h-4 w-4 text-emerald-600" />
            Распознать расписание
          </DialogTitle>
          <DialogDescription>
            Вставьте расписание текстом или загрузите документ Word — ИИ
            распознает даты, время, учеников и предметы.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 py-1">
          {/* Word upload */}
          <input
            ref={fileRef}
            type="file"
            accept=".docx"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleFile(f);
            }}
          />
          <button
            type="button"
            onClick={() => fileRef.current?.click()}
            disabled={loading}
            className="flex items-center justify-center gap-2 rounded-lg border-2 border-dashed border-emerald-300 bg-emerald-50/40 p-3 text-sm transition hover:bg-emerald-50 dark:border-emerald-500/40 dark:bg-emerald-500/5"
          >
            {loading ? (
              <Loader2 className="h-4 w-4 animate-spin text-emerald-600" />
            ) : (
              <Upload className="h-4 w-4 text-emerald-600" />
            )}
            <span className="font-medium">Загрузить из Word (.docx)</span>
          </button>

          <div className="flex items-center gap-2 text-xs text-muted-foreground">
            <span className="h-px flex-1 bg-border" />
            или вставьте текст
            <span className="h-px flex-1 bg-border" />
          </div>

          <Label htmlFor="ps-text">Текст расписания</Label>
          <Textarea
            id="ps-text"
            rows={6}
            placeholder={`Например:\nЗавтра в 15:00 Анна Иванова, английский, 60 минут, онлайн, 1500₽\nПятница 17:00 Олег Козлов физика 90 мин офлайн 2000\n...`}
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className="text-xs text-muted-foreground">
              ИИ разберёт даты, время, имена и суммы. Проверьте результат перед импортом.
            </p>
            <Button
              size="sm"
              onClick={handleParse}
              disabled={loading || !text.trim()}
            >
              {loading ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Анализ...
                </>
              ) : (
                <>
                  <Wand2 className="mr-2 h-4 w-4" /> Распознать
                </>
              )}
            </Button>
          </div>

          {parsed && parsed.length > 0 && (
            <div className="mt-2 rounded-lg border">
              <div className="flex items-center justify-between border-b px-3 py-2">
                <span className="text-sm font-medium">
                  Распознано: {parsed.length}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    setSelected(
                      selected.size === parsed.length
                        ? new Set()
                        : new Set(parsed.map((_, i) => i))
                    )
                  }
                >
                  {selected.size === parsed.length
                    ? "Снять все"
                    : "Выбрать все"}
                </Button>
              </div>
              <div className="max-h-72 overflow-y-auto">
                {parsed.map((p, i) => {
                  const checked = selected.has(i);
                  const complete = !!(p.date && p.timeStart && p.studentName && p.subject);
                  return (
                    <label
                      key={i}
                      className="flex cursor-pointer items-start gap-3 border-b px-3 py-2 last:border-0 hover:bg-muted/40"
                    >
                      <Checkbox
                        checked={checked}
                        onCheckedChange={() => toggle(i)}
                        className="mt-1"
                      />
                      <div className="grid flex-1 gap-1 text-sm">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-medium">
                            {p.date ?? "—"} {p.timeStart ?? ""}
                          </span>
                          {p.durationMinutes && (
                            <span className="text-muted-foreground">
                              · {p.durationMinutes} мин
                            </span>
                          )}
                          {complete ? (
                            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                          ) : (
                            <span className="text-xs text-amber-600">
                              неполные данные
                            </span>
                          )}
                        </div>
                        <div className="text-muted-foreground">
                          {p.studentName ?? "—"} · {p.subject ?? "—"} ·{" "}
                          {p.format ?? "—"}
                          {p.price ? ` · ${p.price}₽` : ""}
                        </div>
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Закрыть
          </Button>
          {parsed && parsed.length > 0 && (
            <Button
              onClick={handleImport}
              disabled={importing || selected.size === 0}
            >
              {importing
                ? "Импорт..."
                : `Импортировать ${selected.size}`}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
