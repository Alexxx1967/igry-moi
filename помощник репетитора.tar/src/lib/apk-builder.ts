// Server-side APK builder. Generates a real, signed .apk Android package
// that launches the tutor-assistant PWA at the given origin URL.
//
// The APK is a minimal launcher: MainActivity opens the origin URL in the
// browser, which then offers the PWA install (or runs as a TWA). The APK is
// built with the Android SDK (build-tools 34, platform 34) and signed with a
// debug keystore generated on first run.
//
// Results are cached per origin so subsequent requests are instant.
//
// SDK + JDK live in a permanent directory (/home/z/android-env) so they
// survive server restarts. If missing, we try /tmp as fallback, and if that's
// also missing we throw a clear error.

import { execFileSync } from "child_process";
import fs from "fs";
import path from "path";

// Permanent location (survives restarts). Fallback to /tmp for backward compat.
function findEnv(): { sdkRoot: string; javaHome: string } {
  const permanentSdk = "/home/z/android-env/sdk";
  const permanentJdk = "/home/z/android-env/jdk";
  const tmpSdk = "/tmp/android-sdk";
  const tmpJdk = "/tmp/jdk-21.0.5+11";

  const sdkRoot =
    fs.existsSync(path.join(permanentSdk, "build-tools", "34.0.0", "aapt"))
      ? permanentSdk
      : fs.existsSync(path.join(tmpSdk, "build-tools", "34.0.0", "aapt"))
        ? tmpSdk
        : "";
  const javaHome =
    fs.existsSync(path.join(permanentJdk, "bin", "javac"))
      ? permanentJdk
      : fs.existsSync(path.join(tmpJdk, "bin", "javac"))
        ? tmpJdk
        : "";

  return { sdkRoot, javaHome };
}

const { sdkRoot: SDK_ROOT, javaHome: JAVA_HOME } = findEnv();
const BT = SDK_ROOT ? path.join(SDK_ROOT, "build-tools", "34.0.0") : "";
const PLATFORM = SDK_ROOT
  ? path.join(SDK_ROOT, "platforms", "android-34", "android.jar")
  : "";
const WORK = "/tmp/apk-work";

/** Build (or return cached) signed APK for the given origin URL. */
export function buildApkForOrigin(origin: string): Buffer {
  // Verify SDK + JDK are available.
  if (!SDK_ROOT || !JAVA_HOME || !fs.existsSync(BT) || !fs.existsSync(PLATFORM)) {
    throw new Error(
      "Android SDK не установлен на сервере. Обратитесь к администратору для установки build-tools и JDK."
    );
  }

  const safe = origin.replace(/[^a-z0-9]/gi, "_").slice(0, 40);
  const outDir = path.join(WORK, safe);
  const apkPath = path.join(outDir, "app-release.apk");

  if (fs.existsSync(apkPath)) {
    return fs.readFileSync(apkPath);
  }

  fs.mkdirSync(outDir, { recursive: true });
  const genDir = path.join(outDir, "gen");
  const objDir = path.join(outDir, "obj");
  const apkDir = path.join(outDir, "apk");
  fs.mkdirSync(genDir, { recursive: true });
  fs.mkdirSync(objDir, { recursive: true });
  fs.mkdirSync(apkDir, { recursive: true });

  // Project files
  const manifest = `<?xml version="1.0" encoding="utf-8"?>
<manifest xmlns:android="http://schemas.android.com/apk/res/android"
    package="ru.tutor.assistant" android:versionCode="1" android:versionName="1.0.0">

    <uses-sdk android:minSdkVersion="24" android:targetSdkVersion="33" />

    <uses-permission android:name="android.permission.INTERNET" />
    <uses-permission android:name="android.permission.ACCESS_NETWORK_STATE" />

    <application android:allowBackup="true" android:icon="@mipmap/ic_launcher"
        android:label="@string/app_name" android:theme="@style/Theme.App"
        android:usesCleartextTraffic="true">
        <activity android:name=".MainActivity" android:exported="true"
            android:configChanges="orientation|screenSize|keyboardHidden"
            android:launchMode="singleTop">
            <intent-filter>
                <action android:name="android.intent.action.MAIN" />
                <category android:name="android.intent.category.LAUNCHER" />
            </intent-filter>
        </activity>
    </application>
</manifest>`;

  const strings = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <string name="app_name">Репетитор</string>
    <string name="app_url">${origin.replace(/&/g, "&amp;").replace(/</g, "&lt;")}</string>
</resources>`;

  const styles = `<?xml version="1.0" encoding="utf-8"?>
<resources>
    <style name="Theme.App" parent="android:Theme.Material.Light.NoActionBar">
        <item name="android:colorPrimary">#059669</item>
        <item name="android:colorPrimaryDark">#047857</item>
        <item name="android:windowBackground">#ffffff</item>
    </style>
</resources>`;

  const java = `package ru.tutor.assistant;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try {
            String url = getString(R.string.app_url);
            Uri uri = Uri.parse(url);
            Intent intent = new Intent(Intent.ACTION_VIEW, uri);
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(intent);
        } catch (Exception e) {
            // ignore
        }
        finish();
    }
}`;

  const resDir = path.join(outDir, "res");
  const javaDir = path.join(outDir, "java", "ru", "tutor", "assistant");
  fs.mkdirSync(path.join(resDir, "values"), { recursive: true });
  fs.mkdirSync(path.join(resDir, "mipmap-xxxhdpi"), { recursive: true });
  fs.mkdirSync(javaDir, { recursive: true });
  fs.writeFileSync(path.join(outDir, "AndroidManifest.xml"), manifest);
  fs.writeFileSync(path.join(resDir, "values", "strings.xml"), strings);
  fs.writeFileSync(path.join(resDir, "values", "styles.xml"), styles);
  fs.writeFileSync(path.join(javaDir, "MainActivity.java"), java);
  // Icon
  const iconSrc = path.join(process.cwd(), "public", "icon-512.png");
  if (fs.existsSync(iconSrc)) {
    fs.copyFileSync(iconSrc, path.join(resDir, "mipmap-xxxhdpi", "ic_launcher.png"));
  }

  const env = {
    ...process.env,
    ANDROID_SDK_ROOT: SDK_ROOT,
    ANDROID_HOME: SDK_ROOT,
    JAVA_HOME,
    PATH: `${JAVA_HOME}/bin:${process.env.PATH ?? ""}`,
  };

  // 1) Compile resources -> R.java
  execFileSync(
    path.join(BT, "aapt"),
    [
      "package", "-f", "-m", "-J", genDir,
      "-M", path.join(outDir, "AndroidManifest.xml"),
      "-S", resDir, "-I", PLATFORM,
    ],
    { stdio: "pipe", env }
  );

  // 2) Compile Java -> .class (collect all .java files recursively under genDir)
  const srcs: string[] = [];
  function collectJava(d: string) {
    for (const e of fs.readdirSync(d)) {
      const p = path.join(d, e);
      if (fs.statSync(p).isDirectory()) collectJava(p);
      else if (e.endsWith(".java")) srcs.push(p);
    }
  }
  collectJava(genDir);
  srcs.push(path.join(javaDir, "MainActivity.java"));
  execFileSync(
    path.join(JAVA_HOME, "bin", "javac"),
    [
      "-source", "8", "-target", "8", "-d", objDir,
      "-classpath", PLATFORM, "-bootclasspath", PLATFORM,
      ...srcs,
    ],
    { stdio: "pipe", env }
  );

  // 3) Dex
  const classFiles: string[] = [];
  function walk(d: string) {
    for (const e of fs.readdirSync(d)) {
      const p = path.join(d, e);
      if (fs.statSync(p).isDirectory()) walk(p);
      else if (e.endsWith(".class")) classFiles.push(p);
    }
  }
  walk(objDir);
  execFileSync(
    path.join(BT, "d8"),
    ["--lib", PLATFORM, "--min-api", "24", "--output", apkDir, ...classFiles],
    { stdio: "pipe", env }
  );

  // 4) Build unsigned APK
  const unsignedApk = path.join(outDir, "app-unsigned.apk");
  execFileSync(
    path.join(BT, "aapt"),
    [
      "package", "-f",
      "-M", path.join(outDir, "AndroidManifest.xml"),
      "-S", resDir, "-I", PLATFORM,
      "-F", unsignedApk, apkDir,
    ],
    { stdio: "pipe", env }
  );

  // 5) Zipalign
  const alignedApk = path.join(outDir, "app-aligned.apk");
  execFileSync(
    path.join(BT, "zipalign"),
    ["-f", "4", unsignedApk, alignedApk],
    { stdio: "pipe", env }
  );

  // 6) Sign with debug keystore (generated once per work dir)
  const keystore = path.join(WORK, "debug.keystore");
  if (!fs.existsSync(keystore)) {
    execFileSync(
      path.join(JAVA_HOME, "bin", "keytool"),
      [
        "-genkey", "-v", "-keystore", keystore,
        "-alias", "androiddebugkey", "-storepass", "android", "-keypass", "android",
        "-keyalg", "RSA", "-keysize", "2048", "-validity", "10000",
        "-dname", "CN=TutorAssistant, OU=App, O=Tutor, L=Moscow, S=Moscow, C=RU",
      ],
      { stdio: "pipe", env }
    );
  }
  execFileSync(
    path.join(BT, "apksigner"),
    [
      "sign",
      "--ks", keystore,
      "--ks-key-alias", "androiddebugkey",
      "--ks-pass", "pass:android",
      "--key-pass", "pass:android",
      "--min-sdk-version", "24",
      "--v1-signing-enabled", "true",
      "--v2-signing-enabled", "true",
      "--v3-signing-enabled", "true",
      "--out", apkPath,
      alignedApk,
    ],
    { stdio: "pipe", env }
  );

  return fs.readFileSync(apkPath);
}
