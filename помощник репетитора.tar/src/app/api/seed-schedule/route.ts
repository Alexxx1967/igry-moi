import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSettings, saveSettings } from "@/lib/report";

// POST /api/seed-schedule — loads the real tutor's students & schedule
// (parsed from the uploaded расписание 2026-2027.docx), generates lessons
// for September 2026 (1–18 Sep = conducted & paid; 19–30 Sep = planned),
// and records prepayments + carryover balance.
export async function POST() {
  const settings = await getSettings();
  const tz = settings.timezone;
  // Today in the tutor's timezone (Europe/Moscow → 2026-09-18).
  const today = new Intl.DateTimeFormat("en-CA", {
    timeZone: tz,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).format(new Date());

  // Wipe existing data.
  await db.monthlyPayment.deleteMany();
  await db.lesson.deleteMany();
  await db.student.deleteMany();

  // 1) Create students with pricePerLesson.
  const studentDefs = [
    { name: "Полина Пчелинцева", pricePerLesson: 1900, color: "emerald", grade: "" },
    { name: "Тимофей Курганов", pricePerLesson: 1900, color: "amber", grade: "" },
    { name: "Анна Уткина", pricePerLesson: 2000, color: "violet", grade: "" },
    { name: "Максим Фёдоров", pricePerLesson: 1900, color: "rose", grade: "" },
    { name: "Алиса Усова", pricePerLesson: 2000, color: "cyan", grade: "" },
    { name: "Вероника Захарова", pricePerLesson: 1700, color: "orange", grade: "" },
    { name: "Блинова", pricePerLesson: 2000, color: "teal", grade: "" },
  ];
  const studentIds: Record<string, string> = {};
  for (const s of studentDefs) {
    const created = await db.student.create({ data: s });
    studentIds[s.name] = created.id;
  }

  // 2) Schedule: student → list of {weekday (1=Mon..5=Fri), timeStart "HH:MM"}
  // Parsed from the uploaded docx table. Optional startDate = first lesson date
  // (for students who join mid-month, e.g. Блинова starts 2026-09-23).
  type Slot = { weekday: number; time: string };
  const schedule: Record<string, { slots: Slot[]; startDate?: string }> = {
    "Полина Пчелинцева": {
      slots: [
        { weekday: 1, time: "15:45" }, // Пн
        { weekday: 3, time: "16:00" }, // Ср
      ],
    },
    "Тимофей Курганов": {
      slots: [
        { weekday: 1, time: "17:00" }, // Пн
        { weekday: 2, time: "18:30" }, // Вт
      ],
    },
    "Анна Уткина": {
      slots: [
        { weekday: 1, time: "18:15" }, // Пн
        { weekday: 4, time: "18:30" }, // Чт
      ],
    },
    "Максим Фёдоров": {
      slots: [
        { weekday: 2, time: "15:20" }, // Вт
        { weekday: 5, time: "15:20" }, // Пт
      ],
    },
    "Алиса Усова": {
      slots: [
        { weekday: 2, time: "17:00" }, // Вт
        { weekday: 4, time: "17:00" }, // Чт
      ],
    },
    "Вероника Захарова": {
      slots: [{ weekday: 3, time: "17:30" }], // Ср
    },
    "Блинова": {
      slots: [{ weekday: 3, time: "19:00" }], // Ср
      startDate: "2026-09-23", // первое занятие 23 сентября
    },
  };

  // 3) Generate lessons for every matching weekday in September 2026.
  const lessons: Array<{
    date: string;
    timeStart: string;
    studentId: string;
    subject: string;
    format: string;
    price: number;
    paidAmount: number;
    lessonStatus: string;
    paymentStatus: string;
    recurring: string | null;
  }> = [];

  const year = 2026;
  const month = 9; // September
  const daysInMonth = new Date(Date.UTC(year, month, 0)).getUTCDate();
  for (let day = 1; day <= daysInMonth; day++) {
    const d = new Date(Date.UTC(year, month - 1, day));
    const weekday = ((d.getUTCDay() + 6) % 7) + 1; // 1=Mon..7=Sun
    if (weekday > 5) continue; // skip weekends
    const dateStr = `${year}-09-${String(day).padStart(2, "0")}`;
    const isPast = dateStr <= today; // conducted & paid
    for (const [studentName, info] of Object.entries(schedule)) {
      // Skip lessons before the student's start date (if set).
      if (info.startDate && dateStr < info.startDate) continue;
      for (const slot of info.slots) {
        if (slot.weekday !== weekday) continue;
        const price = studentDefs.find((s) => s.name === studentName)!.pricePerLesson;
        lessons.push({
          date: dateStr,
          timeStart: slot.time,
          studentId: studentIds[studentName],
          subject: "Занятие",
          format: "online",
          price,
          paidAmount: isPast ? price : 0,
          lessonStatus: isPast ? "conducted" : "planned",
          paymentStatus: isPast ? "paid" : "unpaid",
          recurring: "weekly",
        });
      }
    }
  }
  await db.lesson.createMany({ data: lessons });

  // 4) Prepayments.
  // Пчелинцева: с 14 сентября — предоплата за 10 уроков, 19000₽ (сентябрь).
  await db.monthlyPayment.create({
    data: {
      studentId: studentIds["Полина Пчелинцева"],
      month: "2026-09",
      lessonsCount: 10,
      amount: 19000,
      paid: true,
      paidAt: new Date("2026-09-14"),
      comment: "Предоплата за 10 уроков с 14 сентября",
    },
  });
  // Уткина: с 17 сентября — предоплата за 9 уроков, 18000₽ (сентябрь).
  await db.monthlyPayment.create({
    data: {
      studentId: studentIds["Анна Уткина"],
      month: "2026-09",
      lessonsCount: 9,
      amount: 18000,
      paid: true,
      paidAt: new Date("2026-09-17"),
      comment: "Предоплата за 9 уроков с 17 сентября",
    },
  });
  // Уткина: баланс августа — 4000₽ за 2 урока (неиспользованная предоплата).
  await db.monthlyPayment.create({
    data: {
      studentId: studentIds["Анна Уткина"],
      month: "2026-08",
      lessonsCount: 2,
      amount: 4000,
      paid: true,
      paidAt: new Date("2026-08-31"),
      comment: "Остаток за август — 2 урока не проведено",
    },
  });

  await saveSettings({});

  return NextResponse.json({
    ok: true,
    students: studentDefs.length,
    lessons: lessons.length,
    prepayments: 3,
    today,
    details: {
      conductedPaid: lessons.filter((l) => l.lessonStatus === "conducted").length,
      planned: lessons.filter((l) => l.lessonStatus === "planned").length,
    },
  });
}
