import { NextRequest, NextResponse } from "next/server";
import { buildMonthlyReport, getSettings } from "@/lib/report";
import { todayInTZ } from "@/lib/tz";

// GET /api/reports/monthly?date=YYYY-MM-DD (covers the month containing that date)
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const settings = await getSettings();
  const date = searchParams.get("date") ?? todayInTZ(settings.timezone);
  const report = await buildMonthlyReport(date);
  return NextResponse.json(report);
}
