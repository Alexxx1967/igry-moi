"use client";

import { cn } from "@/lib/utils";
import {
  LESSON_STATUS_LABELS,
  PAYMENT_STATUS_LABELS,
  LESSON_FORMAT_LABELS,
  colorClasses,
  type LessonFormat,
  type LessonStatus,
  type PaymentStatus,
} from "@/lib/constants";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";

export function LessonStatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    planned:
      "bg-sky-100 text-sky-700 border-sky-200 dark:bg-sky-500/15 dark:text-sky-300 dark:border-sky-500/30",
    conducted:
      "bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300 dark:border-emerald-500/30",
    cancelled:
      "bg-zinc-200 text-zinc-600 border-zinc-300 dark:bg-zinc-500/15 dark:text-zinc-300 dark:border-zinc-500/30",
    rescheduled:
      "bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/30",
    no_show:
      "bg-rose-100 text-rose-700 border-rose-200 dark:bg-rose-500/15 dark:text-rose-300 dark:border-rose-500/30",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium",
        map[status] ?? map.planned
      )}
    >
      {LESSON_STATUS_LABELS[status as LessonStatus] ?? status}
    </span>
  );
}

export function PaymentStatusBadge({ status }: { status: string }) {
  const map: Record<string, string> = {
    paid:
      "bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300 dark:border-emerald-500/30",
    unpaid:
      "bg-rose-100 text-rose-700 border-rose-200 dark:bg-rose-500/15 dark:text-rose-300 dark:border-rose-500/30",
    partial:
      "bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/30",
    awaiting_confirmation:
      "bg-violet-100 text-violet-700 border-violet-200 dark:bg-violet-500/15 dark:text-violet-300 dark:border-violet-500/30",
    refund:
      "bg-zinc-200 text-zinc-600 border-zinc-300 dark:bg-zinc-500/15 dark:text-zinc-300 dark:border-zinc-500/30",
    free_trial:
      "bg-teal-100 text-teal-700 border-teal-200 dark:bg-teal-500/15 dark:text-teal-300 dark:border-teal-500/30",
  };
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium",
        map[status] ?? map.unpaid
      )}
    >
      {PAYMENT_STATUS_LABELS[status as PaymentStatus] ?? status}
    </span>
  );
}

export function FormatBadge({ format }: { format: string }) {
  const online =
    format === "online"
      ? "bg-cyan-100 text-cyan-700 border-cyan-200 dark:bg-cyan-500/15 dark:text-cyan-300 dark:border-cyan-500/30"
      : "bg-orange-100 text-orange-700 border-orange-200 dark:bg-orange-500/15 dark:text-orange-300 dark:border-orange-500/30";
  return (
    <span
      className={cn(
        "inline-flex items-center rounded-full border px-2 py-0.5 text-xs font-medium",
        online
      )}
    >
      {LESSON_FORMAT_LABELS[format as LessonFormat] ?? format}
    </span>
  );
}

export function StudentAvatar({
  name,
  color,
  size = "default",
}: {
  name: string;
  color: string;
  size?: "sm" | "default" | "lg";
}) {
  const initials = name
    .split(" ")
    .map((p) => p[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
  const cls = colorClasses(color);
  const sizeCls =
    size === "sm" ? "h-7 w-7 text-xs" : size === "lg" ? "h-12 w-12 text-base" : "h-9 w-9 text-sm";
  return (
    <Avatar className={cn(sizeCls, "border", cls.badge)}>
      <AvatarFallback className={cn("font-semibold", cls.text)}>
        {initials}
      </AvatarFallback>
    </Avatar>
  );
}

export function StudentDot({ color }: { color: string }) {
  const cls = colorClasses(color);
  return <span className={cn("inline-block h-2.5 w-2.5 rounded-full", cls.dot)} />;
}
