"use client";

import { useEffect, useRef, useState } from "react";

type NotificationItem = {
  key: string;
  type: string;
  title: string;
  body: string;
  url?: string;
  tag?: string;
};

type ShareItem = {
  key: string;
  channel: "max" | "vk";
  title: string;
  body: string;
  shareUrl: string;
  text: string;
};

const SENT_KEYS_STORAGE = "ta:notifSent";
const SETTINGS_STORAGE = "ta:notifEnabled";

function readSent(): Record<string, number> {
  try {
    return JSON.parse(localStorage.getItem(SENT_KEYS_STORAGE) || "{}");
  } catch {
    return {};
  }
}

function writeSent(map: Record<string, number>) {
  try {
    // Keep only keys from the last 7 days to avoid unbounded growth.
    const cutoff = Date.now() - 7 * 24 * 60 * 60 * 1000;
    const cleaned: Record<string, number> = {};
    for (const [k, t] of Object.entries(map)) {
      if (t >= cutoff) cleaned[k] = t;
    }
    localStorage.setItem(SENT_KEYS_STORAGE, JSON.stringify(cleaned));
  } catch {
    /* ignore */
  }
}

function isNotificationsSupported() {
  return typeof window !== "undefined" && "Notification" in window && "serviceWorker" in navigator;
}

/**
 * Central hook that powers browser push-style notifications:
 *  - tracks permission state
 *  - requests permission on demand
 *  - polls /api/notifications/feed every 60s
 *  - fires a browser notification (via the service worker when available)
 *    for each new item, deduped by `key` (stored in localStorage)
 *  - exposes the list of recently-fired notifications for the UI bell.
 */
export function useNotifications() {
  const supported = isNotificationsSupported();
  const [permission, setPermission] = useState<NotificationPermission | "unsupported">(
    supported ? Notification.permission : "unsupported"
  );
  const [enabled, setEnabled] = useState<boolean>(false);
  const [recent, setRecent] = useState<NotificationItem[]>([]);
  const [shares, setShares] = useState<ShareItem[]>([]);
  const [unread, setUnread] = useState<number>(0);
  const sentRef = useRef<Record<string, number>>({});

  // Load persisted settings on mount.
  useEffect(() => {
    sentRef.current = readSent();
    const stored = localStorage.getItem(SETTINGS_STORAGE);
    setEnabled(stored === "true");
  }, []);

  // Keep enabled state in sync with permission: if permission is denied,
  // we cannot fire notifications.
  useEffect(() => {
    if (!supported) return;
    setPermission(Notification.permission);
    if (Notification.permission === "denied") {
      setEnabled(false);
      localStorage.setItem(SETTINGS_STORAGE, "false");
    }
  }, [supported]);

  // Fire a single notification via the service worker (preferred) or the page.
  function fireNotification(item: NotificationItem) {
    const payload = {
      title: item.title,
      body: item.body,
      icon: "/icon-192.png",
      badge: "/icon-192.png",
      tag: item.tag,
      key: item.key,
      data: { url: item.url || "/", key: item.key },
    };
    try {
      if (navigator.serviceWorker.controller) {
        navigator.serviceWorker.controller.postMessage({
          type: "SHOW_NOTIFICATION",
          payload,
        });
      } else if (Notification.permission === "granted") {
        new Notification(payload.title, {
          body: payload.body,
          icon: payload.icon,
          badge: payload.badge,
          tag: payload.tag,
          data: payload.data,
        });
      }
    } catch {
      /* ignore */
    }
    // Mark as sent
    sentRef.current[item.key] = Date.now();
    writeSent(sentRef.current);
    setRecent((prev) => [item, ...prev].slice(0, 50));
    setUnread((u) => u + 1);
  }

  async function requestPermission() {
    if (!supported) return "unsupported" as const;
    const result = await Notification.requestPermission();
    setPermission(result);
    if (result === "granted") {
      setEnabled(true);
      localStorage.setItem(SETTINGS_STORAGE, "true");
      // Fire a test notification so the user sees it works.
      fireNotification({
        key: "welcome",
        type: "welcome",
        title: "✅ Оповещения включены",
        body: "Теперь вы будете получать напоминания о занятиях, отчётах и налоговой.",
        url: "/?section=today",
        tag: "welcome",
      });
    }
    return result;
  }

  async function toggleEnabled(on: boolean) {
    if (on && Notification.permission !== "granted") {
      await requestPermission();
    } else {
      setEnabled(on);
      localStorage.setItem(SETTINGS_STORAGE, String(on));
    }
  }

  // Polling loop — always runs (so MAX/VK direct-link shares are collected
  // even if browser notifications are disabled or blocked). Browser
  // notifications are only fired when enabled && permission === "granted".
  useEffect(() => {
    if (!supported) return;
    let cancelled = false;

    async function tick() {
      try {
        const res = await fetch("/api/notifications/feed");
        if (!res.ok) return;
        const data = (await res.json()) as {
          items: NotificationItem[];
          shares?: ShareItem[];
        };
        if (cancelled) return;
        const sent = sentRef.current;
        for (const item of data.items) {
          if (!sent[item.key]) {
            // Only fire a browser notification if enabled & permission granted.
            if (enabled && permission === "granted") {
              fireNotification(item);
            } else {
              // Still mark as sent + add to recent so the bell shows it.
              sentRef.current[item.key] = Date.now();
              setRecent((prev) => [item, ...prev].slice(0, 50));
              setUnread((u) => u + 1);
            }
          }
        }
        // Collect shares (direct-link mode) — deduped by key+channel.
        if (data.shares && data.shares.length > 0) {
          setShares((prev) => {
            const existing = new Set(prev.map((s) => `${s.key}|${s.channel}`));
            const fresh = data.shares!.filter(
              (s) => !existing.has(`${s.key}|${s.channel}`)
            );
            if (fresh.length === 0) return prev;
            return [...prev, ...fresh].slice(-50);
          });
        }
      } catch {
        /* ignore */
      }
    }

    tick();
    const interval = setInterval(tick, 60_000);
    return () => {
      cancelled = true;
      clearInterval(interval);
    };
  }, [supported, enabled, permission]);

  // Handle notification clicks arriving at the page (from the SW).
  useEffect(() => {
    if (!supported) return;
    const handler = (event: MessageEvent) => {
      if (event.data?.type === "NOTIFICATION_CLICK" && event.data.url) {
        const url = new URL(event.data.url, window.location.origin);
        const section = url.searchParams.get("section");
        if (section) {
          window.location.hash = "";
          // Use a custom event so the page shell can switch sections.
          window.dispatchEvent(
            new CustomEvent("ta:navigate", { detail: section })
          );
        }
      }
    };
    navigator.serviceWorker.addEventListener("message", handler);
    return () => navigator.serviceWorker.removeEventListener("message", handler);
  }, [supported]);

  function markAllRead() {
    setUnread(0);
  }
  function clearRecent() {
    setRecent([]);
    setUnread(0);
  }
  function dismissShare(key: string, channel: string) {
    setShares((prev) =>
      prev.filter((s) => !(s.key === key && s.channel === channel))
    );
  }
  function clearShares() {
    setShares([]);
  }
  /** Open the share URL and copy the text to the clipboard.
   *  On mobile (Web Share API available), uses navigator.share() so the text
   *  is pre-filled and the user picks MAX/VK from the system sheet.
   *  On desktop, copies to clipboard and opens the chat URL. */
  async function openShare(share: ShareItem) {
    // Try Web Share API first (mobile) — pre-fills the text and lets the user
    // pick MAX/VK from the native share sheet. This is the closest to
    // "automatic" sending without a bot.
    if (typeof navigator !== "undefined" && "share" in navigator) {
      try {
        await navigator.share({
          title: share.title,
          text: share.text,
          url: share.shareUrl,
        });
        dismissShare(share.key, share.channel);
        return;
      } catch {
        // User cancelled or share failed — fall through to clipboard + open.
      }
    }
    // Desktop fallback: copy text + open the chat URL.
    try {
      await navigator.clipboard.writeText(share.text);
    } catch {
      /* clipboard may be blocked — ignore */
    }
    window.open(share.shareUrl, "_blank");
    dismissShare(share.key, share.channel);
  }

  return {
    supported,
    permission,
    enabled,
    requestPermission,
    toggleEnabled,
    recent,
    unread,
    markAllRead,
    clearRecent,
    shares,
    openShare,
    dismissShare,
    clearShares,
  };
}
