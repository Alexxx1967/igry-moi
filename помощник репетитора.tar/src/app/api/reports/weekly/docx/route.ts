import { NextRequest, NextResponse } from "next/server";
import { buildWeeklyReport, getSettings } from "@/lib/report";
import { buildReportDocx, textToSections } from "@/lib/docx-helpers";
import { formatShortDate, todayInTZ } from "@/lib/tz";

// GET /api/reports/weekly/docx?date=YYYY-MM-DD
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const settings = await getSettings();
  const date = searchParams.get("date") ?? todayInTZ(settings.timezone);
  const report = await buildWeeklyReport(date);
  const sections = textToSections(report.text);
  const buffer = await buildReportDocx(
    "Еженедельный отчёт",
    `Период: ${formatShortDate(report.startDate)} — ${formatShortDate(
      report.endDate
    )} · ${settings.timezone}`,
    sections
  );
  return new NextResponse(buffer as unknown as BodyInit, {
    headers: {
      "Content-Type":
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "Content-Disposition": `attachment; filename="weekly-${report.startDate}.docx"`,
    },
  });
}
