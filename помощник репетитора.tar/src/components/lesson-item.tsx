"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
  DropdownMenuLabel,
} from "@/components/ui/dropdown-menu";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  MoreVertical,
  Pencil,
  Trash2,
  Check,
  Clock,
  ExternalLink,
  Copy,
  Sparkles,
  RotateCcw,
  X,
} from "lucide-react";
import {
  LessonStatusBadge,
  PaymentStatusBadge,
  FormatBadge,
  StudentAvatar,
} from "@/components/status-badges";
import {
  LESSON_STATUS_LABELS,
  LESSON_STATUSES,
  PAYMENT_STATUS_LABELS,
  PAYMENT_STATUSES,
  type LessonStatus,
  type PaymentStatus,
} from "@/lib/constants";
import type { LessonWithStudent } from "@/lib/types";
import {
  useDeleteLesson,
  useUpdateLesson,
  useUpdatePayment,
  useSettings,
} from "@/lib/hooks";
import { endTime, formatMoney, formatShortDate } from "@/lib/tz";
import { LessonFormDialog } from "@/components/lesson-form-dialog";
import { PaymentReminderDialog } from "@/components/payment-reminder-dialog";

type Props = {
  lesson: LessonWithStudent;
  showDate?: boolean;
  compact?: boolean;
};

export function LessonItem({ lesson, showDate = false, compact = false }: Props) {
  const [editOpen, setEditOpen] = useState(false);
  const [reminderOpen, setReminderOpen] = useState(false);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [statusOpen, setStatusOpen] = useState(false);
  const [paymentOpen, setPaymentOpen] = useState(false);
  const updateMut = useUpdateLesson();
  const deleteMut = useDeleteLesson();
  const updatePayMut = useUpdatePayment();
  const { data: settings } = useSettings();

  const isOwing =
    lesson.lessonStatus === "conducted" &&
    (lesson.paymentStatus === "unpaid" || lesson.paymentStatus === "partial");
  const debt = Math.max(0, lesson.price - lesson.paidAmount);

  function quickSetLessonStatus(status: LessonStatus) {
    updateMut.mutate(
      { id: lesson.id, body: { lessonStatus: status } },
      {
        onSuccess: () =>
          toast.success(`Статус: ${LESSON_STATUS_LABELS[status]}`),
        onError: (e) => toast.error(e.message),
      }
    );
  }

  function quickPayFull() {
    updatePayMut.mutate(
      { id: lesson.id, body: { paymentStatus: "paid" } },
      {
        onSuccess: () => {
          toast.success(
            `Оплата от ${lesson.student.name} отмечена. Занятие от ${formatShortDate(
              lesson.date
            )} оплачено.`
          );
        },
        onError: (e) => toast.error(e.message),
      }
    );
  }

  function quickSetPayment(ps: PaymentStatus) {
    updatePayMut.mutate(
      { id: lesson.id, body: { paymentStatus: ps } },
      {
        onSuccess: () =>
          toast.success(`Оплата: ${PAYMENT_STATUS_LABELS[ps]}`),
        onError: (e) => toast.error(e.message),
      }
    );
  }

  return (
    <>
      <div
        className={cn(
          "group flex items-start gap-3 rounded-xl border bg-card p-3 transition hover:shadow-sm",
          isOwing && "border-rose-200 bg-rose-50/40 dark:border-rose-500/30 dark:bg-rose-500/5"
        )}
      >
        <StudentAvatar
          name={lesson.student.name}
          color={lesson.student.color}
          size="sm"
        />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1">
            <span className="font-medium leading-tight">{lesson.student.name}</span>
            {showDate && (
              <span className="text-xs text-muted-foreground">
                {formatShortDate(lesson.date)}
              </span>
            )}
          </div>
          <div className="mt-1">
            <span className="inline-flex items-center gap-1.5 rounded-lg bg-emerald-600 px-3 py-1.5 text-xl font-bold text-white dark:bg-emerald-600">
              <Clock className="h-5 w-5" />
              {lesson.timeStart}–{endTime(lesson.timeStart, lesson.durationMinutes)}
            </span>
          </div>
          <div className="mt-1.5 flex flex-wrap items-center gap-1.5">
            <LessonStatusBadge status={lesson.lessonStatus} />
            <PaymentStatusBadge status={lesson.paymentStatus} />
            <FormatBadge format={lesson.format} />
            <span className="text-xs font-medium text-foreground/70">
              {formatMoney(lesson.price)}
            </span>
            {isOwing && (
              <span className="text-xs font-semibold text-rose-600">
                долг {formatMoney(debt)}
              </span>
            )}
          </div>
          {!compact && lesson.comment && (
            <p className="mt-1.5 text-xs text-muted-foreground">
              {lesson.comment}
            </p>
          )}
          {!compact && lesson.link && lesson.format === "online" && (
            <a
              href={lesson.link}
              target="_blank"
              rel="noreferrer"
              className="mt-1.5 inline-flex items-center gap-1 text-xs text-emerald-600 hover:underline"
            >
              <ExternalLink className="h-3 w-3" /> ссылка на занятие
            </a>
          )}
        </div>

        <div className="flex items-center gap-1">
          {isOwing && (
            <Button
              size="sm"
              variant="outline"
              className="h-7 border-emerald-300 text-emerald-700 hover:bg-emerald-50 dark:border-emerald-500/40 dark:text-emerald-300 dark:hover:bg-emerald-500/10"
              onClick={quickPayFull}
              disabled={updatePayMut.isPending}
            >
              <Check className="mr-1 h-3.5 w-3.5" /> Оплачено
            </Button>
          )}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon" className="h-8 w-8">
                <MoreVertical className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52">
              <DropdownMenuLabel>Действия</DropdownMenuLabel>
              <DropdownMenuItem onClick={() => setEditOpen(true)}>
                <Pencil className="mr-2 h-4 w-4" /> Редактировать
              </DropdownMenuItem>
              {lesson.link && (
                <DropdownMenuItem
                  onClick={() => {
                    navigator.clipboard.writeText(lesson.link!);
                    toast.success("Ссылка скопирована");
                  }}
                >
                  <Copy className="mr-2 h-4 w-4" /> Копировать ссылку
                </DropdownMenuItem>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuLabel>Статус занятия</DropdownMenuLabel>
              {LESSON_STATUSES.map((s) => (
                <DropdownMenuItem
                  key={s}
                  onClick={() => quickSetLessonStatus(s)}
                  className={cn(lesson.lessonStatus === s && "bg-muted")}
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      lesson.lessonStatus === s ? "opacity-100" : "opacity-0"
                    )}
                  />
                  {LESSON_STATUS_LABELS[s]}
                </DropdownMenuItem>
              ))}
              <DropdownMenuSeparator />
              <DropdownMenuLabel>Оплата</DropdownMenuLabel>
              {PAYMENT_STATUSES.map((p) => (
                <DropdownMenuItem
                  key={p}
                  onClick={() => quickSetPayment(p)}
                  className={cn(lesson.paymentStatus === p && "bg-muted")}
                >
                  <Check
                    className={cn(
                      "mr-2 h-4 w-4",
                      lesson.paymentStatus === p ? "opacity-100" : "opacity-0"
                    )}
                  />
                  {PAYMENT_STATUS_LABELS[p]}
                </DropdownMenuItem>
              ))}
              {isOwing && (
                <>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => setReminderOpen(true)}>
                    <Sparkles className="mr-2 h-4 w-4 text-emerald-600" />
                    Напоминание об оплате
                  </DropdownMenuItem>
                </>
              )}
              <DropdownMenuSeparator />
              <DropdownMenuItem
                onClick={() => setDeleteOpen(true)}
                className="text-rose-600 focus:text-rose-700"
              >
                <Trash2 className="mr-2 h-4 w-4" /> Удалить
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      <LessonFormDialog
        open={editOpen}
        onOpenChange={setEditOpen}
        lesson={lesson}
      />
      <PaymentReminderDialog
        open={reminderOpen}
        onOpenChange={setReminderOpen}
        lesson={lesson}
      />
      <DeleteLessonDialog
        open={deleteOpen}
        onOpenChange={setDeleteOpen}
        lesson={lesson}
        onConfirm={() => {
          deleteMut.mutate(lesson.id, {
            onSuccess: () => {
              toast.success("Занятие удалено");
              setDeleteOpen(false);
            },
            onError: (e) => toast.error(e.message),
          });
        }}
        pending={deleteMut.isPending}
      />
    </>
  );
}

function DeleteLessonDialog({
  open,
  onOpenChange,
  lesson,
  onConfirm,
  pending,
}: {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  lesson: LessonWithStudent;
  onConfirm: () => void;
  pending: boolean;
}) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[420px]">
        <DialogHeader>
          <DialogTitle>Удалить занятие?</DialogTitle>
          <DialogDescription>
            Занятие {lesson.student.name} от {formatShortDate(lesson.date)} в{" "}
            {lesson.timeStart} будет удалено безвозвратно.
          </DialogDescription>
        </DialogHeader>
        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Отмена
          </Button>
          <Button variant="destructive" onClick={onConfirm} disabled={pending}>
            Удалить
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
