import { NextRequest, NextResponse } from "next/server";
import { buildDailyReport, getSettings } from "@/lib/report";
import { buildReportDocx, textToSections } from "@/lib/docx-helpers";
import { formatShortDate, todayInTZ } from "@/lib/tz";

// GET /api/reports/daily/docx?date=YYYY-MM-DD
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const settings = await getSettings();
  const date = searchParams.get("date") ?? todayInTZ(settings.timezone);
  const report = await buildDailyReport(date);
  const sections = textToSections(report.text);
  const buffer = await buildReportDocx(
    "Ежедневный отчёт",
    `Дата: ${formatShortDate(date)} · ${settings.timezone}`,
    sections
  );
  return new NextResponse(buffer as unknown as BodyInit, {
    headers: {
      "Content-Type":
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "Content-Disposition": `attachment; filename="daily-${date}.docx"`,
    },
  });
}
