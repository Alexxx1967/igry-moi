"use client";

import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Badge } from "@/components/ui/badge";
import {
  CalendarDays,
  CheckCircle2,
  Wallet,
  AlertTriangle,
  Bell,
  Plus,
  Video,
  MapPin,
  ArrowRight,
  Landmark,
  Check,
  Undo2,
  Loader2,
} from "lucide-react";
import {
  useDashboard,
  useSettings,
  useMarkTaxDone,
  useUndoTaxDone,
} from "@/lib/hooks";
import {
  formatLongDate,
  weekdayName,
  formatMoney,
  endTime,
  relativeFromMinutes,
} from "@/lib/tz";
import { tierLabel } from "@/lib/reminders";
import { StudentAvatar } from "@/components/status-badges";
import { LessonItem } from "@/components/lesson-item";
import { useState } from "react";
import type { LessonWithStudent } from "@/lib/types";

type Props = {
  onNavigate: (section: string) => void;
  onAddLesson: () => void;
};

export function TodaySection({ onNavigate, onAddLesson }: Props) {
  const { data, isLoading } = useDashboard();
  const { data: settings } = useSettings();
  const [reminderOpen, setReminderOpen] = useState(false);
  const markTaxMut = useMarkTaxDone();
  const undoTaxMut = useUndoTaxDone();
  const tz = settings?.timezone ?? "Europe/Moscow";

  if (isLoading || !data) {
    return (
      <div className="grid gap-4">
        <Skeleton className="h-24 w-full" />
        <div className="grid gap-4 md:grid-cols-2">
          <Skeleton className="h-64 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      </div>
    );
  }

  const nextReminder = data.reminders[0];
  const stats = data.todayStats;

  return (
    <div className="grid gap-5">
      <div className="grid gap-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-sm text-muted-foreground">
              {weekdayName(data.now.date)}, {formatLongDate(data.now.date)}
            </p>
            <h1 className="text-2xl font-semibold tracking-tight">
              Сегодня{" "}
              {stats.total > 0
                ? `${stats.total} ${plural(stats.total, "занятие", "занятия", "занятий")}`
                : "занятий нет"}
            </h1>
            <p className="text-sm text-muted-foreground">
              Часовой пояс: {tz}. Текущее время: {data.now.time}
            </p>
          </div>
          <Button
            onClick={onAddLesson}
            className="bg-emerald-600 hover:bg-emerald-700"
          >
            <Plus className="mr-1 h-4 w-4" /> Добавить занятие
          </Button>
        </div>

        <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
          <StatCard
            icon={<CalendarDays className="h-4 w-4" />}
            label="Запланировано"
            value={stats.planned}
            tone="sky"
          />
          <StatCard
            icon={<CheckCircle2 className="h-4 w-4" />}
            label="Проведено"
            value={stats.conducted}
            tone="emerald"
          />
          <StatCard
            icon={<Wallet className="h-4 w-4" />}
            label="Долг всего"
            value={formatMoney(data.debtTotal)}
            tone={data.debtTotal > 0 ? "rose" : "emerald"}
          />
          <StatCard
            icon={<Bell className="h-4 w-4" />}
            label="Должников"
            value={data.debtors.length}
            tone={data.debtors.length > 0 ? "amber" : "emerald"}
          />
        </div>
      </div>

      {nextReminder && (
        <NextLessonCard
          lesson={nextReminder.lesson}
          minutes={nextReminder.minutes}
          tier={nextReminder.tier}
        />
      )}

      <div className="grid gap-5 lg:grid-cols-3">
        <Card className="lg:col-span-2">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
            <CardTitle className="text-base">Расписание на сегодня</CardTitle>
            <Button
              variant="ghost"
              size="sm"
              onClick={() => onNavigate("schedule")}
            >
              Всё расписание <ArrowRight className="ml-1 h-4 w-4" />
            </Button>
          </CardHeader>
          <CardContent>
            {data.today.length === 0 ? (
              <EmptyState
                icon={<CalendarDays className="h-6 w-6" />}
                title="Занятий сегодня нет"
                hint="Отдыхайте или добавьте занятие вручную."
              />
            ) : (
              <div className="grid max-h-[28rem] gap-2 overflow-y-auto pr-1">
                {data.today.map((l) => (
                  <LessonItem key={l.id} lesson={l} />
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <div className="grid gap-5">
          <Card>
            <CardHeader className="pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <Bell className="h-4 w-4 text-amber-500" /> Напоминания
              </CardTitle>
            </CardHeader>
            <CardContent>
              {data.reminders.length === 0 ? (
                <EmptyState
                  icon={<Bell className="h-5 w-5" />}
                  title="Нет ближайших напоминаний"
                  hint="Активных занятий в ближайшее время нет."
                />
              ) : (
                <div className="grid max-h-72 gap-2 overflow-y-auto pr-1">
                  {data.reminders.slice(0, 6).map((r) => (
                    <button
                      key={r.lesson.id}
                      onClick={() => onNavigate("schedule")}
                      className="flex items-center gap-2 rounded-lg border bg-card p-2 text-left transition hover:bg-muted/40"
                    >
                      <StudentAvatar
                        name={r.lesson.student.name}
                        color={r.lesson.student.color}
                        size="sm"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">
                          {r.lesson.student.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {r.lesson.timeStart} · {r.lesson.subject}
                        </p>
                      </div>
                      <div className="text-right">
                        <Badge
                          variant="outline"
                          className={cn(
                            "text-[10px]",
                            r.tier === "now" || r.tier === "15min"
                              ? "border-rose-300 bg-rose-50 text-rose-700 dark:border-rose-500/40 dark:bg-rose-500/10 dark:text-rose-300"
                              : r.tier === "1h"
                                ? "border-amber-300 bg-amber-50 text-amber-700 dark:border-amber-500/40 dark:bg-amber-500/10 dark:text-amber-300"
                                : "border-sky-300 bg-sky-50 text-sky-700 dark:border-sky-500/40 dark:bg-sky-500/10 dark:text-sky-300"
                          )}
                        >
                          {r.tier === "now" ? "скоро" : relativeFromMinutes(r.minutes)}
                        </Badge>
                        <p className="mt-0.5 text-[10px] text-muted-foreground">
                          {tierLabel(r.tier as never)}
                        </p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="flex items-center gap-2 text-base">
                <AlertTriangle className="h-4 w-4 text-rose-500" /> Должники
              </CardTitle>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => onNavigate("payments")}
              >
                Все <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </CardHeader>
            <CardContent>
              {data.debtors.length === 0 ? (
                <EmptyState
                  icon={<CheckCircle2 className="h-5 w-5" />}
                  title="Нет долгов"
                  hint="Все занятия оплачены."
                />
              ) : (
                <div className="grid max-h-60 gap-2 overflow-y-auto pr-1">
                  {data.debtors.slice(0, 6).map((d) => (
                    <button
                      key={d.id}
                      onClick={() => onNavigate("payments")}
                      className="flex items-center gap-2 rounded-lg border border-rose-200 bg-rose-50/40 p-2 text-left transition hover:bg-rose-50 dark:border-rose-500/30 dark:bg-rose-500/5 dark:hover:bg-rose-500/10"
                    >
                      <StudentAvatar
                        name={d.student.name}
                        color={d.student.color}
                        size="sm"
                      />
                      <div className="min-w-0 flex-1">
                        <p className="truncate text-sm font-medium">
                          {d.student.name}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          {d.date} · {d.subject}
                        </p>
                      </div>
                      <span className="text-sm font-semibold text-rose-600">
                        {formatMoney(d.debt)}
                      </span>
                    </button>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Tax reminder card */}
          {data.taxReminder?.enabled && (
            <Card
              className={
                data.taxReminder.todayDone
                  ? "border-emerald-200 dark:border-emerald-500/30"
                  : data.taxReminder.due
                    ? "border-amber-300 bg-amber-50/40 dark:border-amber-500/40 dark:bg-amber-500/5"
                    : ""
              }
            >
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
                <CardTitle className="flex items-center gap-2 text-base">
                  <Landmark
                    className={cn(
                      "h-4 w-4",
                      data.taxReminder.todayDone
                        ? "text-emerald-500"
                        : data.taxReminder.due
                          ? "text-amber-500"
                          : "text-muted-foreground"
                    )}
                  />
                  Налоговая
                </CardTitle>
                <span className="text-xs text-muted-foreground">
                  в {data.taxReminder.time}
                </span>
              </CardHeader>
              <CardContent>
                {data.taxReminder.todayDone ? (
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-sm text-emerald-700 dark:text-emerald-300">
                      <CheckCircle2 className="h-4 w-4" />
                      Сегодня данные поданы
                    </div>
                    <Button
                      variant="ghost"
                      size="sm"
                      className="h-7 text-xs"
                      disabled={undoTaxMut.isPending}
                      onClick={() => undoTaxMut.mutate()}
                    >
                      <Undo2 className="mr-1 h-3.5 w-3.5" /> Отменить
                    </Button>
                  </div>
                ) : data.taxReminder.due ? (
                  <div className="flex items-center justify-between gap-2">
                    <div className="flex items-center gap-2 text-sm text-amber-700 dark:text-amber-300">
                      <AlertTriangle className="h-4 w-4" />
                      Подайте данные в налоговую
                    </div>
                    <Button
                      size="sm"
                      className="h-7 bg-emerald-600 hover:bg-emerald-700"
                      disabled={markTaxMut.isPending}
                      onClick={() => markTaxMut.mutate()}
                    >
                      {markTaxMut.isPending ? (
                        <Loader2 className="mr-1 h-3.5 w-3.5 animate-spin" />
                      ) : (
                        <Check className="mr-1 h-3.5 w-3.5" />
                      )}
                      Подал(а)
                    </Button>
                  </div>
                ) : (
                  <p className="text-sm text-muted-foreground">
                    Напоминание появится в {data.taxReminder.time}.
                  </p>
                )}
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* hidden dialog kept for "add lesson" trigger wiring if needed */}
      {reminderOpen && null}
    </div>
  );
}

function StatCard({
  icon,
  label,
  value,
  tone,
}: {
  icon: React.ReactNode;
  label: string;
  value: string | number;
  tone: "sky" | "emerald" | "rose" | "amber";
}) {
  const tones = {
    sky: "text-sky-600 bg-sky-50 dark:bg-sky-500/10 dark:text-sky-300",
    emerald:
      "text-emerald-600 bg-emerald-50 dark:bg-emerald-500/10 dark:text-emerald-300",
    rose: "text-rose-600 bg-rose-50 dark:bg-rose-500/10 dark:text-rose-300",
    amber: "text-amber-600 bg-amber-50 dark:bg-amber-500/10 dark:text-amber-300",
  };
  return (
    <Card>
      <CardContent className="p-4">
        <div className="flex items-center justify-between">
          <span className="text-xs text-muted-foreground">{label}</span>
          <span
            className={cn(
              "flex h-7 w-7 items-center justify-center rounded-lg",
              tones[tone]
            )}
          >
            {icon}
          </span>
        </div>
        <p className="mt-2 text-2xl font-semibold tracking-tight">{value}</p>
      </CardContent>
    </Card>
  );
}

function NextLessonCard({
  lesson,
  minutes,
  tier,
}: {
  lesson: LessonWithStudent;
  minutes: number;
  tier: string;
}) {
  const tierColor =
    tier === "now" || tier === "15min"
      ? "from-rose-500 to-rose-600"
      : tier === "1h"
        ? "from-amber-500 to-amber-600"
        : "from-emerald-500 to-emerald-600";
  return (
    <div
      className={cn(
        "relative overflow-hidden rounded-2xl bg-gradient-to-br p-5 text-white shadow-sm",
        tierColor
      )}
    >
      <div className="absolute -right-8 -top-8 h-32 w-32 rounded-full bg-white/10" />
      <div className="absolute -bottom-10 -right-2 h-24 w-24 rounded-full bg-white/10" />
      <div className="relative flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-4">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-white/20 backdrop-blur">
            {lesson.format === "online" ? (
              <Video className="h-6 w-6" />
            ) : (
              <MapPin className="h-6 w-6" />
            )}
          </div>
          <div>
            <div className="flex items-center gap-2 text-sm text-white/80">
              <span>
                {tier === "now"
                  ? "Начинается сейчас"
                  : `Следующее занятие · ${tierLabel(tier as never)}`}
              </span>
            </div>
            <h3 className="text-xl font-semibold">{lesson.student.name}</h3>
            <p className="text-2xl font-bold text-white">
              {lesson.timeStart}–{endTime(lesson.timeStart, lesson.durationMinutes)}
            </p>
            <p className="text-sm text-white/80">
              {lesson.durationMinutes} мин
            </p>
          </div>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold">
            {tier === "now" ? "Сейчас" : relativeFromMinutes(minutes)}
          </div>
          {lesson.link && (
            <a
              href={lesson.link}
              target="_blank"
              rel="noreferrer"
              className="mt-1 inline-flex items-center gap-1 rounded-lg bg-white/20 px-3 py-1 text-sm font-medium backdrop-blur hover:bg-white/30"
            >
              <Video className="h-4 w-4" /> Открыть
            </a>
          )}
        </div>
      </div>
    </div>
  );
}

function EmptyState({
  icon,
  title,
  hint,
}: {
  icon: React.ReactNode;
  title: string;
  hint?: string;
}) {
  return (
    <div className="flex flex-col items-center justify-center gap-2 py-8 text-center">
      <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-muted-foreground">
        {icon}
      </div>
      <p className="text-sm font-medium">{title}</p>
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

function plural(n: number, one: string, few: string, many: string) {
  const mod10 = n % 10;
  const mod100 = n % 100;
  if (mod10 === 1 && mod100 !== 11) return one;
  if (mod10 >= 2 && mod10 <= 4 && (mod100 < 10 || mod100 >= 20)) return few;
  return many;
}
