import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSettings, getTaxReminderStatus } from "@/lib/report";
import {
  addDays,
  isLastDayOfMonth,
  monthOf,
  nowInTZ,
  todayInTZ,
  tzDateTimeToEpoch,
} from "@/lib/tz";
import { reminderTierFor } from "@/lib/reminders";
import { dispatchMany } from "@/lib/notifications-channels";

export type NotificationItem = {
  key: string; // stable dedup key
  type:
    | "lesson_30min"
    | "lesson_1h"
    | "lesson_15min"
    | "lesson_now"
    | "tax"
    | "daily_report"
    | "weekly_report"
    | "monthly_report"
    | "debt";
  title: string;
  body: string;
  url?: string;
  tag?: string;
};

// GET /api/notifications/feed — returns all notifications that should be shown
// right now. Each item has a stable `key` so the client can dedupe (only fire
// a browser notification once per key per day).
export async function GET() {
  const settings = await getSettings();
  const tz = settings.timezone;
  const now = nowInTZ(tz);
  const today = now.date;
  const items: NotificationItem[] = [];

  // 1) Lesson reminders (next 2 days, planned/rescheduled)
  const toDate = addDays(today, 2);
  const upcoming = await db.lesson.findMany({
    where: {
      date: { gte: today, lte: toDate },
      lessonStatus: { in: ["planned", "rescheduled"] },
    },
    include: { student: true },
    orderBy: [{ date: "asc" }, { timeStart: "asc" }],
  });

  for (const l of upcoming) {
    const epoch = tzDateTimeToEpoch(l.date, l.timeStart, tz);
    const minutesUntil = Math.round((epoch - now.timestamp) / 60000);
    const tier = reminderTierFor(minutesUntil, settings);
    if (tier === "none" || tier === "past") continue;
    const dateKey = l.date;
    const typeMap = {
      "30min": "lesson_30min" as const,
      "1h": "lesson_1h" as const,
      "15min": "lesson_15min" as const,
      now: "lesson_now" as const,
    };
    const type = typeMap[tier as keyof typeof typeMap];
    if (!type) continue;
    const titleMap = {
      lesson_30min: "⏰ Занятие через 30 минут",
      lesson_1h: "⏰ Занятие через час",
      lesson_15min: "🔔 Занятие скоро",
      lesson_now: "🔴 Занятие начинается",
    };
    const title = titleMap[type];
    const body = `${l.student.name} · ${l.timeStart} · ${l.subject}`;
    items.push({
      key: `${type}:${l.id}:${dateKey}`,
      type,
      title,
      body,
      url: "/?section=schedule",
      tag: `lesson-${l.id}`,
    });
  }

  // 2) Tax reminder
  const tax = await getTaxReminderStatus();
  if (tax.enabled && tax.due) {
    items.push({
      key: `tax:${today}`,
      type: "tax",
      title: "🏛️ Налоговая",
      body: "Подайте данные в налоговую сегодня",
      url: "/?section=today",
      tag: "tax-reminder",
    });
  }

  // 3) Daily report — due when current time >= dailyReportTime
  const [dh, dm] = settings.dailyReportTime.split(":").map(Number);
  const nowMin = now.hour * 60 + now.minute;
  const reportMin = (dh ?? 21) * 60 + (dm ?? 0);
  if (nowMin >= reportMin) {
    items.push({
      key: `daily:${today}`,
      type: "daily_report",
      title: "📊 Ежедневный отчёт готов",
      body: `Отчёт за ${today} доступен в разделе «Отчёты»`,
      url: "/?section=reports",
      tag: "daily-report",
    });
  }

  // 4) Weekly report — on the configured weekday at the configured time
  const weeklyDay = Number(settings.weeklyReportDay); // 0=Sun..6=Sat
  const [wh, wm] = settings.weeklyReportTime.split(":").map(Number);
  const weeklyMin = (wh ?? 21) * 60 + (wm ?? 0);
  if (now.weekday === weeklyDay && nowMin >= weeklyMin) {
    items.push({
      key: `weekly:${today}`,
      type: "weekly_report",
      title: "📈 Еженедельный отчёт готов",
      body: "Отчёт за неделю доступен в разделе «Отчёты»",
      url: "/?section=reports",
      tag: "weekly-report",
    });
  }

  // 5) Monthly report — on the last day of the month at monthlyReportTime
  const [mh, mm] = settings.monthlyReportTime.split(":").map(Number);
  const monthlyMin = (mh ?? 21) * 60 + (mm ?? 0);
  if (isLastDayOfMonth(today) && nowMin >= monthlyMin) {
    items.push({
      key: `monthly:${monthOf(today)}`,
      type: "monthly_report",
      title: "🗓️ Ежемесячный отчёт готов",
      body: "Отчёт за месяц доступен в разделе «Отчёты»",
      url: "/?section=reports",
      tag: "monthly-report",
    });
  }

  // 6) Debt notification — if there are any debtors
  const debtors = await db.lesson.findMany({
    where: {
      lessonStatus: "conducted",
      OR: [{ paymentStatus: "unpaid" }, { paymentStatus: "partial" }],
    },
    include: { student: true },
  });
  if (debtors.length > 0) {
    const totalDebt = debtors.reduce(
      (s, l) => s + Math.max(0, l.price - l.paidAmount),
      0
    );
    items.push({
      key: `debt:${today}`,
      type: "debt",
      title: "⚠️ Есть должники",
      body: `${debtors.length} неоплаченных занятий на сумму ${totalDebt.toLocaleString(
        "ru-RU"
      )} ₽`,
      url: "/?section=payments",
      tag: "debt",
    });
  }

  // Dispatch to external channels (MAX, VK). In direct-link mode, dispatch
  // returns shareUrl + text for each channel — we collect these as "shares"
  // so the client can show "Open in MAX / VK" buttons.
  let dispatch = { dispatched: 0, failed: 0, results: [] as any[] };
  if (settings.maxEnabled || settings.vkEnabled) {
    try {
      dispatch = await dispatchMany(items, settings);
    } catch {
      /* ignore dispatch errors — feed still returns items for the browser */
    }
  }

  // Collect share items (for direct-link mode) — each has a channel, shareUrl,
  // and the text to copy to clipboard.
  const shares: Array<{
    key: string;
    channel: "max" | "vk";
    title: string;
    body: string;
    shareUrl: string;
    text: string;
  }> = [];
  for (const r of dispatch.results) {
    if (r.ok && r.shareUrl && r.text) {
      // Find the corresponding item title/body by key.
      const item = items.find((i) => i.key === r.key || r.key?.includes(i.key.split(":")[0]));
      shares.push({
        key: r.key || item?.key || "",
        channel: r.channel,
        title: item?.title || r.text.split("\n")[0] || "",
        body: item?.body || r.text.split("\n").slice(1).join("\n") || "",
        shareUrl: r.shareUrl,
        text: r.text,
      });
    }
  }

  return NextResponse.json({
    items,
    shares,
    now: now.timestamp,
    today,
    channels: {
      max: settings.maxEnabled,
      vk: settings.vkEnabled,
      dispatched: dispatch.dispatched,
      failed: dispatch.failed,
    },
  });
}
