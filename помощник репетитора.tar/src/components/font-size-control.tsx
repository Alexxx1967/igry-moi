"use client";

import { useFontSize, FONT_SIZES } from "@/lib/use-font-size";
import { Button } from "@/components/ui/button";
import { Minus, Plus, Type } from "lucide-react";
import { useState, useRef, useEffect } from "react";
import { cn } from "@/lib/utils";

/** Font-size control: A-/A+ buttons + dropdown with size presets. */
export function FontSizeControl() {
  const { index, name, increase, decrease, reset, set, canIncrease, canDecrease } =
    useFontSize();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  return (
    <div className="relative" ref={ref}>
      <div className="flex items-center gap-0.5 rounded-lg border bg-background">
        <button
          onClick={decrease}
          disabled={!canDecrease}
          className="flex h-7 w-7 items-center justify-center text-muted-foreground transition hover:bg-muted disabled:opacity-30"
          aria-label="Уменьшить шрифт"
          title="Уменьшить шрифт"
        >
          <Minus className="h-3.5 w-3.5" />
        </button>
        <button
          onClick={() => setOpen((v) => !v)}
          className="flex h-7 items-center gap-1 px-1.5 text-xs font-medium text-muted-foreground transition hover:bg-muted"
          aria-label="Размер шрифта"
          title={`Размер шрифта: ${name}`}
        >
          <Type className="h-3.5 w-3.5" />
          <span className="hidden sm:inline">{name}</span>
        </button>
        <button
          onClick={increase}
          disabled={!canIncrease}
          className="flex h-7 w-7 items-center justify-center text-muted-foreground transition hover:bg-muted disabled:opacity-30"
          aria-label="Увеличить шрифт"
          title="Увеличить шрифт"
        >
          <Plus className="h-3.5 w-3.5" />
        </button>
      </div>

      {open && (
        <div className="absolute right-0 top-9 z-50 w-44 overflow-hidden rounded-xl border bg-popover shadow-lg">
          <div className="border-b px-3 py-1.5 text-xs font-medium text-muted-foreground">
            Размер шрифта
          </div>
          {FONT_SIZES.map((s, i) => (
            <button
              key={i}
              onClick={() => {
                set(i);
                setOpen(false);
              }}
              className={cn(
                "flex w-full items-center justify-between px-3 py-2 text-left transition hover:bg-muted/50",
                i === index && "bg-emerald-50 dark:bg-emerald-500/10"
              )}
            >
              <span
                className={cn(
                  "font-medium",
                  i === index && "text-emerald-700 dark:text-emerald-300"
                )}
                style={{ fontSize: `${0.875 * s.scale}rem` }}
              >
                {s.name}
              </span>
              {i === index && (
                <span className="text-xs text-emerald-600">✓</span>
              )}
            </button>
          ))}
          <button
            onClick={() => {
              reset();
              setOpen(false);
            }}
            className="w-full border-t px-3 py-2 text-left text-xs text-muted-foreground transition hover:bg-muted/50"
          >
            Сбросить
          </button>
        </div>
      )}
    </div>
  );
}
