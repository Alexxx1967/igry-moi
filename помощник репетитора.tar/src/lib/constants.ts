// Domain constants & labels for the Tutor Assistant

export const LESSON_STATUSES = [
  "planned",
  "conducted",
  "cancelled",
  "rescheduled",
  "no_show",
] as const;
export type LessonStatus = (typeof LESSON_STATUSES)[number];

export const PAYMENT_STATUSES = [
  "paid",
  "unpaid",
  "partial",
  "awaiting_confirmation",
  "refund",
  "free_trial",
] as const;
export type PaymentStatus = (typeof PAYMENT_STATUSES)[number];

export const LESSON_FORMATS = ["online", "offline"] as const;
export type LessonFormat = (typeof LESSON_FORMATS)[number];

export const LESSON_STATUS_LABELS: Record<LessonStatus, string> = {
  planned: "Запланировано",
  conducted: "Проведено",
  cancelled: "Отменено",
  rescheduled: "Перенесено",
  no_show: "Неявка",
};

export const PAYMENT_STATUS_LABELS: Record<PaymentStatus, string> = {
  paid: "Оплачено",
  unpaid: "Не оплачено",
  partial: "Частично оплачено",
  awaiting_confirmation: "Ожидает подтверждения",
  refund: "Возврат",
  free_trial: "Пробное / бесплатно",
};

export const LESSON_FORMAT_LABELS: Record<LessonFormat, string> = {
  online: "Онлайн",
  offline: "Офлайн",
};

// Russian weekday names (Monday-first)
export const WEEKDAYS_RU = [
  "Понедельник",
  "Вторник",
  "Среда",
  "Четверг",
  "Пятница",
  "Суббота",
  "Воскресенье",
];

export const WEEKDAYS_RU_SHORT = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"];

// Months in Russian (nominative & genitive for dates)
export const MONTHS_RU_NOM = [
  "Январь",
  "Февраль",
  "Март",
  "Апрель",
  "Май",
  "Июнь",
  "Июль",
  "Август",
  "Сентябрь",
  "Октябрь",
  "Ноябрь",
  "Декабрь",
];

export const MONTHS_RU_GEN = [
  "января",
  "февраля",
  "марта",
  "апреля",
  "мая",
  "июня",
  "июля",
  "августа",
  "сентября",
  "октября",
  "ноября",
  "декабря",
];

export const STUDENT_COLORS = [
  "emerald",
  "amber",
  "rose",
  "violet",
  "cyan",
  "orange",
  "teal",
  "fuchsia",
] as const;

export type StudentColor = (typeof STUDENT_COLORS)[number];

// Tailwind class fragments per color for badges/dots — neutral-safe palette
export const COLOR_CLASSES: Record<
  string,
  { dot: string; badge: string; soft: string; text: string }
> = {
  emerald: {
    dot: "bg-emerald-500",
    badge: "bg-emerald-100 text-emerald-700 border-emerald-200 dark:bg-emerald-500/15 dark:text-emerald-300 dark:border-emerald-500/30",
    soft: "bg-emerald-50 dark:bg-emerald-500/10",
    text: "text-emerald-700 dark:text-emerald-300",
  },
  amber: {
    dot: "bg-amber-500",
    badge: "bg-amber-100 text-amber-700 border-amber-200 dark:bg-amber-500/15 dark:text-amber-300 dark:border-amber-500/30",
    soft: "bg-amber-50 dark:bg-amber-500/10",
    text: "text-amber-700 dark:text-amber-300",
  },
  rose: {
    dot: "bg-rose-500",
    badge: "bg-rose-100 text-rose-700 border-rose-200 dark:bg-rose-500/15 dark:text-rose-300 dark:border-rose-500/30",
    soft: "bg-rose-50 dark:bg-rose-500/10",
    text: "text-rose-700 dark:text-rose-300",
  },
  violet: {
    dot: "bg-violet-500",
    badge: "bg-violet-100 text-violet-700 border-violet-200 dark:bg-violet-500/15 dark:text-violet-300 dark:border-violet-500/30",
    soft: "bg-violet-50 dark:bg-violet-500/10",
    text: "text-violet-700 dark:text-violet-300",
  },
  cyan: {
    dot: "bg-cyan-500",
    badge: "bg-cyan-100 text-cyan-700 border-cyan-200 dark:bg-cyan-500/15 dark:text-cyan-300 dark:border-cyan-500/30",
    soft: "bg-cyan-50 dark:bg-cyan-500/10",
    text: "text-cyan-700 dark:text-cyan-300",
  },
  orange: {
    dot: "bg-orange-500",
    badge: "bg-orange-100 text-orange-700 border-orange-200 dark:bg-orange-500/15 dark:text-orange-300 dark:border-orange-500/30",
    soft: "bg-orange-50 dark:bg-orange-500/10",
    text: "text-orange-700 dark:text-orange-300",
  },
  teal: {
    dot: "bg-teal-500",
    badge: "bg-teal-100 text-teal-700 border-teal-200 dark:bg-teal-500/15 dark:text-teal-300 dark:border-teal-500/30",
    soft: "bg-teal-50 dark:bg-teal-500/10",
    text: "text-teal-700 dark:text-teal-300",
  },
  fuchsia: {
    dot: "bg-fuchsia-500",
    badge: "bg-fuchsia-100 text-fuchsia-700 border-fuchsia-200 dark:bg-fuchsia-500/15 dark:text-fuchsia-300 dark:border-fuchsia-500/30",
    soft: "bg-fuchsia-50 dark:bg-fuchsia-500/10",
    text: "text-fuchsia-700 dark:text-fuchsia-300",
  },
};

export function colorClasses(color: string | null | undefined) {
  return COLOR_CLASSES[color ?? "emerald"] ?? COLOR_CLASSES.emerald;
}

// Settings keys
export const SETTING_KEYS = {
  timezone: "timezone",
  dailyReportTime: "dailyReportTime",
  weeklyReportDay: "weeklyReportDay", // 0-6 (0 = Sunday)
  weeklyReportTime: "weeklyReportTime",
  monthlyReportTime: "monthlyReportTime", // time on the last day of month
  reminder30min: "reminder30min",
  reminder1h: "reminder1h",
  reminder15min: "reminder15min",
  autoReminderToStudent: "autoReminderToStudent",
  taxReminderTime: "taxReminderTime", // daily tax-reminder time
  taxReminderLastDone: "taxReminderLastDone", // YYYY-MM-DD of last "done"
  taxReminderEnabled: "taxReminderEnabled",
  // Notification channels
  browserNotifEnabled: "browserNotifEnabled",
  maxEnabled: "maxEnabled",
  maxDirectLink: "maxDirectLink", // прямая ссылка на чат MAX (без бота)
  maxBotToken: "maxBotToken", // (legacy, для bot API — не используется в режиме прямой ссылки)
  maxPhone: "maxPhone",
  maxChatId: "maxChatId",
  vkEnabled: "vkEnabled",
  vkDirectLink: "vkDirectLink", // прямая ссылка на чат ВК (без токена)
  vkAccessToken: "vkAccessToken", // (legacy)
  vkPeerId: "vkPeerId", // (legacy)
  tutorName: "tutorName",
} as const;

export const DEFAULT_SETTINGS: Record<string, string> = {
  timezone: "Europe/Moscow",
  dailyReportTime: "21:00",
  weeklyReportDay: "0", // Sunday
  weeklyReportTime: "21:00",
  monthlyReportTime: "21:00",
  reminder30min: "true",
  reminder1h: "true",
  reminder15min: "true",
  autoReminderToStudent: "false",
  taxReminderTime: "20:00",
  taxReminderLastDone: "",
  taxReminderEnabled: "true",
  browserNotifEnabled: "true",
  maxEnabled: "false",
  maxDirectLink: "",
  maxBotToken: "",
  maxPhone: "",
  maxChatId: "",
  vkEnabled: "false",
  vkDirectLink: "",
  vkAccessToken: "",
  vkPeerId: "",
  tutorName: "",
};

// Common timezones with friendly labels
export const TIMEZONES: { value: string; label: string }[] = [
  { value: "Europe/Moscow", label: "Москва (МСК, UTC+3)" },
  { value: "Europe/Kaliningrad", label: "Калининград (UTC+2)" },
  { value: "Europe/Samara", label: "Самара (UTC+4)" },
  { value: "Asia/Yekaterinburg", label: "Екатеринбург (UTC+5)" },
  { value: "Asia/Omsk", label: "Омск (UTC+6)" },
  { value: "Asia/Krasnoyarsk", label: "Красноярск (UTC+7)" },
  { value: "Asia/Irkutsk", label: "Иркутск (UTC+8)" },
  { value: "Asia/Yakutsk", label: "Якутск (UTC+9)" },
  { value: "Asia/Vladivostok", label: "Владивосток (UTC+10)" },
  { value: "Asia/Magadan", label: "Магадан (UTC+11)" },
  { value: "Europe/Kiev", label: "Киев (UTC+2)" },
  { value: "Europe/Minsk", label: "Минск (UTC+3)" },
  { value: "Asia/Almaty", label: "Алматы (UTC+5)" },
  { value: "Asia/Tashkent", label: "Ташкент (UTC+5)" },
  { value: "Europe/Istanbul", label: "Стамбул (UTC+3)" },
  { value: "Europe/London", label: "Лондон (UTC+0)" },
  { value: "Europe/Berlin", label: "Берлин (UTC+1)" },
  { value: "America/New_York", label: "Нью-Йорк (UTC-5)" },
];
