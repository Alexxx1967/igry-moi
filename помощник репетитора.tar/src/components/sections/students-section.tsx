"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Plus,
  Pencil,
  Trash2,
  Users,
  Phone,
  Mail,
  AlertTriangle,
  CheckCircle2,
  CalendarCheck,
  Wallet,
  Upload,
  GraduationCap,
  UserX,
} from "lucide-react";
import {
  useStudents,
  useDeleteStudent,
  useDeleteAllStudents,
  useSettings,
} from "@/lib/hooks";
import { formatMoney, monthLabel, monthOf, todayInTZ } from "@/lib/tz";
import { StudentFormDialog } from "@/components/student-form-dialog";
import { MonthlyPaymentDialog } from "@/components/monthly-payment-dialog";
import { UploadWordStudentsDialog } from "@/components/upload-word-students-dialog";
import { StudentAvatar } from "@/components/status-badges";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { toast } from "sonner";
import type { StudentWithStats } from "@/lib/types";

export function StudentsSection() {
  const { data: students = [], isLoading } = useStudents();
  const { data: settings } = useSettings();
  const tz = settings?.timezone ?? "Europe/Moscow";
  const currentMonth = monthOf(todayInTZ(tz));
  const deleteMut = useDeleteStudent();
  const deleteAllMut = useDeleteAllStudents();
  const [formOpen, setFormOpen] = useState(false);
  const [editing, setEditing] = useState<StudentWithStats | null>(null);
  const [deleting, setDeleting] = useState<StudentWithStats | null>(null);
  const [payStudent, setPayStudent] = useState<StudentWithStats | null>(null);
  const [uploadOpen, setUploadOpen] = useState(false);
  const [confirmDeleteAll, setConfirmDeleteAll] = useState(false);

  const totalDebt = students.reduce((s, st) => s + st.debt, 0);
  const prepaymentTotal = students.reduce(
    (s, st) => s + (st.monthPrepaid?.paid ? st.monthPrepaid.amount : 0),
    0
  );

  function openNew() {
    setEditing(null);
    setFormOpen(true);
  }
  function openEdit(s: StudentWithStats) {
    setEditing(s);
    setFormOpen(true);
  }

  return (
    <div className="grid gap-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Ученики</h1>
          <p className="text-sm text-muted-foreground">
            Всего: {students.length}. Долг: {formatMoney(totalDebt)}. Предоплаты за {monthLabel(currentMonth)}: {formatMoney(prepaymentTotal)}.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button variant="outline" onClick={() => setUploadOpen(true)}>
            <Upload className="mr-1 h-4 w-4" /> Из Word
          </Button>
          <Button
            variant="outline"
            onClick={() => setConfirmDeleteAll(true)}
            disabled={students.length === 0}
            className="text-rose-600 hover:bg-rose-50 hover:text-rose-700 dark:hover:bg-rose-500/10"
          >
            <UserX className="mr-1 h-4 w-4" /> Удалить всех
          </Button>
          <Button onClick={openNew} className="bg-emerald-600 hover:bg-emerald-700">
            <Plus className="mr-1 h-4 w-4" /> Новый ученик
          </Button>
        </div>
      </div>

      {isLoading ? (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {Array.from({ length: 6 }).map((_, i) => (
            <Skeleton key={i} className="h-40 w-full" />
          ))}
        </div>
      ) : students.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center gap-2 py-12 text-center">
            <div className="flex h-12 w-12 items-center justify-center rounded-full bg-muted text-muted-foreground">
              <Users className="h-6 w-6" />
            </div>
            <p className="text-sm font-medium">Учеников пока нет</p>
            <p className="text-xs text-muted-foreground">
              Добавьте первого ученика, чтобы начать вести расписание.
            </p>
            <Button onClick={openNew} className="mt-2 bg-emerald-600 hover:bg-emerald-700">
              <Plus className="mr-1 h-4 w-4" /> Добавить ученика
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          {students.map((s) => (
            <Card key={s.id} className="flex flex-col">
              <CardHeader className="flex flex-row items-start justify-between space-y-0 pb-3">
                <div className="flex items-center gap-3">
                  <StudentAvatar name={s.name} color={s.color} size="lg" />
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-1.5">
                      <CardTitle className="text-base">{s.name}</CardTitle>
                      {s.grade && (
                        <span className="inline-flex items-center gap-1 rounded-full border border-emerald-200 bg-emerald-50 px-2 py-0.5 text-[10px] font-medium text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
                          <GraduationCap className="h-3 w-3" />
                          {s.grade}
                        </span>
                      )}
                    </div>
                    <p className="text-xs text-muted-foreground">
                      {s.totalLessons} занятий всего
                    </p>
                  </div>
                </div>
                <div className="flex gap-1">
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8"
                    onClick={() => openEdit(s)}
                    aria-label="Редактировать"
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                  <Button
                    variant="ghost"
                    size="icon"
                    className="h-8 w-8 text-rose-600 hover:text-rose-700"
                    onClick={() => setDeleting(s)}
                    aria-label="Удалить"
                  >
                    <Trash2 className="h-4 w-4" />
                  </Button>
                </div>
              </CardHeader>
              <CardContent className="flex flex-1 flex-col gap-3">
                <div className="grid grid-cols-3 gap-2 text-center">
                  <div className="rounded-lg bg-muted/50 p-2">
                    <p className="text-xs text-muted-foreground">Проведено</p>
                    <p className="text-sm font-semibold">{s.conductedLessons}</p>
                  </div>
                  <div className="rounded-lg bg-muted/50 p-2">
                    <p className="text-xs text-muted-foreground">Долгов</p>
                    <p
                      className={cn(
                        "text-sm font-semibold",
                        s.unpaidLessons > 0 ? "text-rose-600" : ""
                      )}
                    >
                      {s.unpaidLessons}
                    </p>
                  </div>
                  <div
                    className={cn(
                      "rounded-lg p-2",
                      s.debt > 0
                        ? "bg-rose-50 dark:bg-rose-500/10"
                        : "bg-emerald-50 dark:bg-emerald-500/10"
                    )}
                  >
                    <p className="text-xs text-muted-foreground">Долг</p>
                    <p
                      className={cn(
                        "text-sm font-semibold",
                        s.debt > 0
                          ? "text-rose-600"
                          : "text-emerald-600"
                      )}
                    >
                      {formatMoney(s.debt)}
                    </p>
                  </div>
                </div>

                <div className="grid gap-1 text-xs text-muted-foreground">
                  {s.grade && (
                    <span className="flex items-center gap-1.5">
                      <GraduationCap className="h-3.5 w-3.5" /> {s.grade}
                    </span>
                  )}
                  {s.pricePerLesson != null && (
                    <span className="flex items-center gap-1.5 font-medium text-emerald-700 dark:text-emerald-300">
                      <Wallet className="h-3.5 w-3.5" /> {formatMoney(s.pricePerLesson)} за урок
                    </span>
                  )}
                  {s.phone && (
                    <span className="flex items-center gap-1.5">
                      <Phone className="h-3.5 w-3.5" /> {s.phone}
                    </span>
                  )}
                  {s.email && (
                    <span className="flex items-center gap-1.5">
                      <Mail className="h-3.5 w-3.5" /> {s.email}
                    </span>
                  )}
                  {s.comment && (
                    <span className="line-clamp-2 text-muted-foreground/80">
                      {s.comment}
                    </span>
                  )}
                  {!s.grade && !s.phone && !s.email && !s.comment && (
                    <span className="text-muted-foreground/60">
                      Нет контактов и заметок
                    </span>
                  )}
                </div>

                {/* Monthly prepayment block */}
                <div className="rounded-lg border p-2.5">
                  <div className="mb-1.5 flex items-center justify-between">
                    <span className="flex items-center gap-1.5 text-xs font-medium">
                      <CalendarCheck className="h-3.5 w-3.5 text-emerald-600" />
                      {monthLabel(currentMonth)}
                    </span>
                    <Button
                      size="sm"
                      variant={s.monthPrepaid ? "outline" : "default"}
                      className={
                        s.monthPrepaid
                          ? "h-6 px-2 text-xs"
                          : "h-6 bg-emerald-600 px-2 text-xs hover:bg-emerald-700"
                      }
                      onClick={() => setPayStudent(s)}
                    >
                      {s.monthPrepaid ? "Изменить" : "Оплата за месяц"}
                    </Button>
                  </div>
                  {s.monthPrepaid ? (
                    <div>
                      <div className="flex items-center justify-between text-xs">
                        <span className="text-muted-foreground">
                          Оплачено {s.monthPrepaid.lessonsCount} зан. ·{" "}
                          {formatMoney(s.monthPrepaid.amount)}
                        </span>
                        {!s.monthPrepaid.paid && (
                          <span className="font-medium text-amber-600">
                            не оплачено
                          </span>
                        )}
                      </div>
                      <div className="mt-1.5 h-2 overflow-hidden rounded-full bg-muted">
                        <div
                          className={cn(
                            "h-full rounded-full",
                            s.monthPrepaid.conductedThisMonth >=
                              s.monthPrepaid.lessonsCount
                              ? "bg-amber-500"
                              : "bg-emerald-500"
                          )}
                          style={{
                            width: `${
                              s.monthPrepaid.lessonsCount > 0
                                ? Math.min(
                                    100,
                                    (s.monthPrepaid.conductedThisMonth /
                                      s.monthPrepaid.lessonsCount) *
                                      100
                                  )
                                : 0
                            }%`,
                          }}
                        />
                      </div>
                      <div className="mt-1 flex items-center justify-between text-[11px]">
                        <span className="text-muted-foreground">
                          Проведено {s.monthPrepaid.conductedThisMonth}
                        </span>
                        <span
                          className={cn(
                            "font-medium",
                            s.monthPrepaid.remaining > 0
                              ? "text-emerald-700 dark:text-emerald-300"
                              : "text-amber-600"
                          )}
                        >
                          {s.monthPrepaid.remaining > 0
                            ? `Осталось ${s.monthPrepaid.remaining}`
                            : "Лимит исчерпан"}
                        </span>
                      </div>
                    </div>
                  ) : (
                    <p className="text-xs text-muted-foreground">
                      Предоплата не отмечена
                    </p>
                  )}
                </div>

                {/* Carryover balance from past months */}
                {s.prepaymentBalanceTotal > 0 && (
                  <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-2.5 dark:border-sky-500/30 dark:bg-sky-500/5">
                    <div className="flex items-center justify-between">
                      <span className="flex items-center gap-1.5 text-xs font-medium text-sky-700 dark:text-sky-300">
                        <Wallet className="h-3.5 w-3.5" />
                        Остались деньги с прошлых месяцев
                      </span>
                      <span className="text-sm font-semibold text-sky-700 dark:text-sky-300">
                        {formatMoney(s.prepaymentBalanceTotal)}
                      </span>
                    </div>
                    <div className="mt-1.5 grid gap-0.5">
                      {s.prepaymentBalance.map((b, i) => (
                        <p
                          key={i}
                          className="text-[11px] text-muted-foreground"
                        >
                          с {b.monthLabel} — {formatMoney(b.amount)} (
                          {b.unusedLessons} из {b.lessonsCount} занятий не
                          проведено)
                        </p>
                      ))}
                    </div>
                  </div>
                )}

                {s.debt > 0 ? (
                  <div className="mt-auto flex items-center gap-1.5 rounded-lg border border-rose-200 bg-rose-50/50 p-2 text-xs text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
                    <AlertTriangle className="h-3.5 w-3.5" /> Есть долг{" "}
                    {formatMoney(s.debt)}
                  </div>
                ) : (
                  s.conductedLessons > 0 && (
                    <div className="mt-auto flex items-center gap-1.5 rounded-lg border border-emerald-200 bg-emerald-50/50 p-2 text-xs text-emerald-700 dark:border-emerald-500/30 dark:bg-emerald-500/10 dark:text-emerald-300">
                      <CheckCircle2 className="h-3.5 w-3.5" /> Все занятия оплачены
                    </div>
                  )
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <StudentFormDialog
        open={formOpen}
        onOpenChange={setFormOpen}
        student={editing}
      />
      <MonthlyPaymentDialog
        open={!!payStudent}
        onOpenChange={(v) => !v && setPayStudent(null)}
        student={payStudent}
        month={currentMonth}
      />
      <Dialog open={!!deleting} onOpenChange={(v) => !v && setDeleting(null)}>
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle>Удалить ученика?</DialogTitle>
            <DialogDescription>
              Ученик {deleting?.name} и все его занятия будут удалены безвозвратно.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setDeleting(null)}>
              Отмена
            </Button>
            <Button
              variant="destructive"
              disabled={deleteMut.isPending}
              onClick={() => {
                if (!deleting) return;
                deleteMut.mutate(deleting.id, {
                  onSuccess: () => {
                    toast.success("Ученик удалён");
                    setDeleting(null);
                  },
                  onError: (e) => toast.error(e.message),
                });
              }}
            >
              Удалить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      <UploadWordStudentsDialog open={uploadOpen} onOpenChange={setUploadOpen} />

      {/* Confirm delete ALL students */}
      <Dialog
        open={confirmDeleteAll}
        onOpenChange={setConfirmDeleteAll}
      >
        <DialogContent className="sm:max-w-[460px]">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2 text-rose-600">
              <UserX className="h-5 w-5" /> Удалить всех учеников?
            </DialogTitle>
            <DialogDescription>
              Будут безвозвратно удалены все ученики ({students.length}),
              все их занятия и предоплаты. Это действие полезно, чтобы очистить
              список перед загрузкой новых учеников из Word.
            </DialogDescription>
          </DialogHeader>
          <div className="rounded-lg border border-rose-200 bg-rose-50/60 p-3 text-sm text-rose-700 dark:border-rose-500/30 dark:bg-rose-500/10 dark:text-rose-300">
            <p className="flex items-start gap-2">
              <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0" />
              <span>
                Удалено будет: <b>{students.length}</b> учеников. Занятия и
                предоплаты тоже будут удалены. Восстановить нельзя.
              </span>
            </p>
          </div>
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => setConfirmDeleteAll(false)}
            >
              Отмена
            </Button>
            <Button
              variant="destructive"
              disabled={deleteAllMut.isPending}
              onClick={() => {
                deleteAllMut.mutate(undefined, {
                  onSuccess: (res) => {
                    toast.success(
                      `Удалено: ${res.deleted.students} учеников, ${res.deleted.lessons} занятий`
                    );
                    setConfirmDeleteAll(false);
                  },
                  onError: (e) => toast.error(e.message),
                });
              }}
            >
              {deleteAllMut.isPending
                ? "Удаление..."
                : "Да, удалить всех"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
