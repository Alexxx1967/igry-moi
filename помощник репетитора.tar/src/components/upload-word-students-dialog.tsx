"use client";

import { useRef, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { toast } from "sonner";
import {
  Loader2,
  Upload,
  FileText,
  CheckCircle2,
  AlertCircle,
} from "lucide-react";
import { api } from "@/lib/api-client";
import {
  useCreateStudent,
  useUploadDocxStudents,
  type ParsedStudent,
} from "@/lib/hooks";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
};

export function UploadWordStudentsDialog({ open, onOpenChange }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [parsed, setParsed] = useState<ParsedStudent[] | null>(null);
  const [selected, setSelected] = useState<Set<number>>(new Set());
  const [fileName, setFileName] = useState("");
  const uploadMut = useUploadDocxStudents();
  const createMut = useCreateStudent();

  function reset() {
    setParsed(null);
    setSelected(new Set());
    setFileName("");
    if (inputRef.current) inputRef.current.value = "";
  }

  async function handleFile(file: File) {
    if (!file.name.toLowerCase().endsWith(".docx")) {
      toast.error("Поддерживаются только .docx файлы");
      return;
    }
    setFileName(file.name);
    setParsed(null);
    try {
      const res = await uploadMut.mutateAsync(file);
      if (!res.students || res.students.length === 0) {
        toast.error("Не удалось распознать учеников в документе");
      } else {
        setParsed(res.students);
        setSelected(new Set(res.students.map((_, i) => i)));
        toast.success(`Распознано учеников: ${res.students.length}`);
      }
    } catch (e) {
      toast.error((e as Error).message);
    }
  }

  function toggle(i: number) {
    setSelected((prev) => {
      const next = new Set(prev);
      if (next.has(i)) next.delete(i);
      else next.add(i);
      return next;
    });
  }

  async function handleImport() {
    if (!parsed) return;
    const toImport = parsed.filter((_, i) => selected.has(i));
    if (toImport.length === 0) {
      toast.error("Выберите хотя бы одного ученика");
      return;
    }
    let ok = 0;
    let fail = 0;
    for (const p of toImport) {
      if (!p.name) {
        fail += 1;
        continue;
      }
      try {
        await createMut.mutateAsync({
          name: p.name,
          phone: p.phone ?? undefined,
          email: p.email ?? undefined,
          grade: p.grade ?? undefined,
          comment: p.comment ?? undefined,
          color: "emerald",
        });
        ok += 1;
      } catch {
        fail += 1;
      }
    }
    if (ok > 0)
      toast.success(`Импортировано учеников: ${ok}${fail ? `, пропущено: ${fail}` : ""}`);
    else toast.error("Не удалось импортировать учеников");
    if (ok > 0) {
      onOpenChange(false);
      reset();
    }
  }

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        onOpenChange(v);
        if (!v) reset();
      }}
    >
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-[560px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Upload className="h-5 w-5 text-emerald-600" />
            Загрузить учеников из Word
          </DialogTitle>
          <DialogDescription>
            Загрузите .docx со списком учеников — ИИ распознает имена, телефоны,
            классы и заметки. Можно список, таблицу или свободный текст.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-3 py-1">
          <input
            ref={inputRef}
            type="file"
            accept=".docx"
            className="hidden"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleFile(f);
            }}
          />
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            disabled={uploadMut.isPending}
            className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed border-emerald-300 bg-emerald-50/40 p-6 text-center transition hover:bg-emerald-50 dark:border-emerald-500/40 dark:bg-emerald-500/5"
          >
            {uploadMut.isPending ? (
              <>
                <Loader2 className="h-8 w-8 animate-spin text-emerald-600" />
                <span className="text-sm text-muted-foreground">
                  Анализ документа...
                </span>
              </>
            ) : (
              <>
                <FileText className="h-8 w-8 text-emerald-600" />
                <span className="text-sm font-medium">
                  {fileName || "Выберите .docx файл"}
                </span>
                <span className="text-xs text-muted-foreground">
                  Нажмите, чтобы выбрать документ Word
                </span>
              </>
            )}
          </button>

          {parsed && parsed.length > 0 && (
            <div className="mt-1 rounded-lg border">
              <div className="flex items-center justify-between border-b px-3 py-2">
                <span className="text-sm font-medium">
                  Распознано: {parsed.length}
                </span>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() =>
                    setSelected(
                      selected.size === parsed.length
                        ? new Set()
                        : new Set(parsed.map((_, i) => i))
                    )
                  }
                >
                  {selected.size === parsed.length
                    ? "Снять все"
                    : "Выбрать все"}
                </Button>
              </div>
              <div className="max-h-72 overflow-y-auto">
                {parsed.map((p, i) => {
                  const checked = selected.has(i);
                  const complete = !!p.name;
                  return (
                    <label
                      key={i}
                      className="flex cursor-pointer items-start gap-3 border-b px-3 py-2 last:border-0 hover:bg-muted/40"
                    >
                      <Checkbox
                        checked={checked}
                        onCheckedChange={() => toggle(i)}
                        className="mt-1"
                      />
                      <div className="grid flex-1 gap-0.5 text-sm">
                        <div className="flex flex-wrap items-center gap-2">
                          <span className="font-medium">
                            {p.name ?? "—"}
                          </span>
                          {p.grade && (
                            <span className="text-xs text-muted-foreground">
                              · {p.grade}
                            </span>
                          )}
                          {complete ? (
                            <CheckCircle2 className="h-3.5 w-3.5 text-emerald-500" />
                          ) : (
                            <span className="flex items-center gap-1 text-xs text-amber-600">
                              <AlertCircle className="h-3 w-3" /> нет имени
                            </span>
                          )}
                        </div>
                        {(p.phone || p.email) && (
                          <p className="text-xs text-muted-foreground">
                            {[p.phone, p.email].filter(Boolean).join(" · ")}
                          </p>
                        )}
                        {p.comment && (
                          <p className="text-xs text-muted-foreground/80">
                            {p.comment}
                          </p>
                        )}
                      </div>
                    </label>
                  );
                })}
              </div>
            </div>
          )}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Закрыть
          </Button>
          {parsed && parsed.length > 0 && (
            <Button
              onClick={handleImport}
              disabled={selected.size === 0}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              Импортировать {selected.size}
            </Button>
          )}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
