// Service Worker for the Tutor Assistant PWA.
// Responsibilities:
//   1. Precache the app shell so the app can launch offline on Android.
//   2. Show push/local notifications (called via `registration.showNotification`
//      from the page, or posted from the client via `postMessage`).
//   3. Handle notification clicks — focus/open the app and navigate.

const CACHE_NAME = "tutor-assistant-v1";
const APP_SHELL = ["/", "/manifest.json", "/icon-192.png", "/icon-512.png"];

self.addEventListener("install", (event) => {
  event.waitUntil(
    caches.open(CACHE_NAME).then((cache) => cache.addAll(APP_SHELL).catch(() => {}))
  );
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(
    caches
      .keys()
      .then((keys) =>
        Promise.all(
          keys.filter((k) => k !== CACHE_NAME).map((k) => caches.delete(k))
        )
      )
  );
  self.clients.claim();
});

// Network-first for navigations (so the app is fresh when online),
// cache fallback for offline launch.
self.addEventListener("fetch", (event) => {
  const req = event.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);
  // Don't cache API requests — always go to network.
  if (url.pathname.startsWith("/api/")) return;
  if (req.mode === "navigate") {
    event.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE_NAME).then((c) => c.put(req, copy));
          return res;
        })
        .catch(() => caches.match(req).then((r) => r || caches.match("/")))
    );
    return;
  }
  // Static assets: stale-while-revalidate
  if (req.destination === "style" || req.destination === "script" || req.destination === "image") {
    event.respondWith(
      caches.match(req).then((cached) => {
        const network = fetch(req)
          .then((res) => {
            const copy = res.clone();
            caches.open(CACHE_NAME).then((c) => c.put(req, copy));
            return res;
          })
          .catch(() => cached);
        return cached || network;
      })
    );
  }
});

// Helper to show a notification (used both by push and by client messages).
function showNotification(payload) {
  const title = payload.title || "Ассистент репетитора";
  const options = {
    body: payload.body || "",
    icon: payload.icon || "/icon-192.png",
    badge: payload.badge || "/icon-192.png",
    tag: payload.tag || payload.key || undefined,
    data: payload.data || {},
    renotify: !!payload.tag,
  };
  return self.registration.showNotification(title, options);
}

// Push events (for future server push).
self.addEventListener("push", (event) => {
  let payload = {};
  try {
    payload = event.data ? event.data.json() : {};
  } catch {
    payload = { body: event.data ? event.data.text() : "" };
  }
  event.waitUntil(showNotification(payload));
});

// Messages from the page — used to fire notifications while the SW is alive
// (works even when the page is hidden/backgrounded on Android).
self.addEventListener("message", (event) => {
  if (event.data && event.data.type === "SHOW_NOTIFICATION") {
    event.waitUntil(showNotification(event.data.payload));
  }
});

// Notification click — focus or open the app, optionally navigate.
self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const targetUrl = event.notification.data?.url || "/";
  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (const client of clientList) {
        if ("focus" in client) {
          client.postMessage({ type: "NOTIFICATION_CLICK", url: targetUrl });
          return client.focus();
        }
      }
      if (self.clients.openWindow) return self.clients.openWindow(targetUrl);
    })
  );
});
