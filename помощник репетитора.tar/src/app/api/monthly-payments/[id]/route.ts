import { NextRequest, NextResponse } from "next/server";
import { deleteMonthlyPayment } from "@/lib/report";

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await deleteMonthlyPayment(id);
  return NextResponse.json({ ok: true });
}
