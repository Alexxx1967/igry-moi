import { NextResponse } from "next/server";
import { autorenewSchedule } from "@/lib/schedule-autorenew";

// POST /api/schedule/autorenew — automatically extends recurring ("weekly")
// lessons into the next month. Idempotent. Called by the dashboard on load
// (and can be triggered manually).
export async function POST() {
  const result = await autorenewSchedule();
  return NextResponse.json({ ok: true, ...result });
}
