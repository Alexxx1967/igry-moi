import { NextRequest, NextResponse } from "next/server";
import { buildMonthlyReport, getSettings } from "@/lib/report";
import { buildReportDocx, textToSections } from "@/lib/docx-helpers";
import { todayInTZ } from "@/lib/tz";

// GET /api/reports/monthly/docx?date=YYYY-MM-DD
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const settings = await getSettings();
  const date = searchParams.get("date") ?? todayInTZ(settings.timezone);
  const report = await buildMonthlyReport(date);
  const sections = textToSections(report.text);
  const buffer = await buildReportDocx(
    "Ежемесячный отчёт",
    `${report.monthLabel} · ${settings.timezone}`,
    sections
  );
  return new NextResponse(buffer as unknown as BodyInit, {
    headers: {
      "Content-Type":
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "Content-Disposition": `attachment; filename="monthly-${report.month}.docx"`,
    },
  });
}
