// Notification channel dispatcher.
//
// Two modes per channel:
//   • "direct link" mode (default, no bot/token needed): the system stores a
//     direct link to the tutor's chat in MAX/VK. When a notification fires,
//     the text is copied to the clipboard and the chat is opened — the tutor
//     just pastes and sends. Also exposed as share-able links in the UI.
//   • "bot API" mode (legacy): uses bot tokens (kept for backward compat).
//
// Deduplication per (key, channel) via NotificationLog so each notification
// fires at most once per channel.

import { db } from "@/lib/db";
import type { NotifChannel, Settings } from "@/lib/types";

export type NotificationPayload = {
  key: string;
  title: string;
  body: string;
  url?: string;
};

export type DispatchResult = {
  channel: NotifChannel;
  ok: boolean;
  error?: string;
  /** In direct-link mode, the share URL the client should open. */
  shareUrl?: string;
  /** The text to copy to the clipboard (for direct-link mode). */
  text?: string;
};

/** Check whether a notification key was already sent on a channel. */
async function alreadySent(key: string, channel: NotifChannel): Promise<boolean> {
  const row = await db.notificationLog.findUnique({
    where: { key_channel: { key, channel } },
  });
  return !!row;
}

/** Record that a notification was sent on a channel. */
async function markSent(key: string, channel: NotifChannel): Promise<void> {
  try {
    await db.notificationLog.upsert({
      where: { key_channel: { key, channel } },
      update: { sentAt: new Date() },
      create: { key, channel },
    });
  } catch {
    /* ignore race conditions */
  }
}

/** Build the full text of a notification. */
function buildText(payload: NotificationPayload): string {
  return `${payload.title}\n${payload.body}`;
}

/**
 * MAX channel — phone-number mode.
 *
 * The tutor provides their phone number. MAX opens a chat with that contact
 * via the `max://phone/<number>` URL scheme (or https://max.ru/im?phone=...).
 * When a notification fires, we return the deep link + text; the client opens
 * the link (which launches MAX on the phone) and copies the text to the
 * clipboard.
 *
 * If a bot token + chat_id are also configured (legacy mode), we send via the
 * bot API automatically.
 */
function normalizePhone(phone: string): string {
  // Keep digits and leading +. Strip spaces, dashes, parens.
  let p = phone.replace(/[^\d+]/g, "");
  if (!p.startsWith("+")) p = "+" + p;
  return p;
}

async function dispatchMax(
  settings: Settings,
  payload: NotificationPayload
): Promise<DispatchResult> {
  const text = buildText(payload);
  const rawPhone = settings.maxDirectLink.trim(); // we reuse this field for the phone

  // Phone-number mode (default, no bot needed).
  if (rawPhone) {
    const phone = normalizePhone(rawPhone);
    // MAX deep link by phone number. On Android this opens the MAX app
    // directly to a chat with the contact; on desktop it opens max.ru.
    const shareUrl = `https://max.ru/send?phone=${encodeURIComponent(phone.replace("+", ""))}`;
    return {
      channel: "max",
      ok: true,
      shareUrl,
      text,
    };
  }

  // Legacy bot API mode.
  const token = settings.maxBotToken.trim();
  const chatId = settings.maxChatId.trim();
  if (token && chatId) {
    try {
      const url = `https://botapi.max.ru/messages?access_token=${encodeURIComponent(token)}`;
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: chatId, text }),
      });
      if (!res.ok) {
        const txt = await res.text().catch(() => "");
        return { channel: "max", ok: false, error: `MAX API ${res.status}: ${txt.slice(0, 200)}` };
      }
      return { channel: "max", ok: true };
    } catch (e) {
      return { channel: "max", ok: false, error: (e as Error).message };
    }
  }

  return {
    channel: "max",
    ok: false,
    error: "Укажите номер телефона в MAX в настройках",
  };
}

/**
 * VK channel — direct link mode.
 *
 * The tutor provides a direct link to their VK chat (e.g.
 * https://vk.com/im?sel=12345 or https://vk.me/id12345). When a notification
 * fires, we return the link + text; the client opens the link and copies the
 * text to the clipboard.
 *
 * VK also supports a share dialog: https://vk.com/share.php — but that posts
 * to the wall, not to a private chat. So we use the direct-im link.
 *
 * If an access_token + peer_id are configured (legacy mode), we send via the
 * VK API automatically.
 */
async function dispatchVk(
  settings: Settings,
  payload: NotificationPayload
): Promise<DispatchResult> {
  const text = buildText(payload);
  const directLink = settings.vkDirectLink.trim();

  // Direct-link mode (no token needed).
  if (directLink) {
    return {
      channel: "vk",
      ok: true,
      shareUrl: directLink,
      text,
    };
  }

  // Legacy bot API mode.
  const token = settings.vkAccessToken.trim();
  const peerId = settings.vkPeerId.trim();
  if (token && peerId) {
    try {
      const params = new URLSearchParams({
        access_token: token,
        peer_id: peerId,
        message: text,
        v: "5.199",
        random_id: String(Math.floor(Math.random() * 2_000_000_000)),
      });
      const res = await fetch("https://api.vk.com/method/messages.send", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: params.toString(),
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok || data.error) {
        const errMsg = data.error?.error_msg || `VK API ${res.status}`;
        return { channel: "vk", ok: false, error: `ВКонтакте: ${errMsg}` };
      }
      return { channel: "vk", ok: true };
    } catch (e) {
      return { channel: "vk", ok: false, error: (e as Error).message };
    }
  }

  return {
    channel: "vk",
    ok: false,
    error: "Укажите прямую ссылку на чат ВКонтакте в настройках",
  };
}

/**
 * Dispatch a single notification to all enabled external channels (MAX, VK).
 * Browser notifications are handled client-side. Returns per-channel results
 * (with shareUrl + text for direct-link mode, so the client can open the chat
 * and copy the text).
 */
export async function dispatchNotification(
  payload: NotificationPayload,
  settings: Settings
): Promise<DispatchResult[]> {
  const results: DispatchResult[] = [];
  const channels: { channel: NotifChannel; dispatch: () => Promise<DispatchResult> }[] = [];

  if (settings.maxEnabled) {
    channels.push({ channel: "max", dispatch: () => dispatchMax(settings, payload) });
  }
  if (settings.vkEnabled) {
    channels.push({ channel: "vk", dispatch: () => dispatchVk(settings, payload) });
  }

  for (const c of channels) {
    try {
      if (await alreadySent(payload.key, c.channel)) {
        results.push({ channel: c.channel, ok: true });
        continue;
      }
      const r = await c.dispatch();
      if (r.ok) await markSent(payload.key, c.channel);
      results.push(r);
    } catch (e) {
      results.push({ channel: c.channel, ok: false, error: (e as Error).message });
    }
  }
  return results;
}

/**
 * Dispatch many notifications at once (used by the feed endpoint). In
 * direct-link mode, this collects all pending notifications and returns them
 * as a list the client can show as "pending to share" — the tutor clicks each
 * to open the chat and send.
 */
export async function dispatchMany(
  payloads: NotificationPayload[],
  settings: Settings
): Promise<{ dispatched: number; failed: number; results: DispatchResult[] }> {
  const all: DispatchResult[] = [];
  let dispatched = 0;
  let failed = 0;
  for (const p of payloads) {
    const res = await dispatchNotification(p, settings);
    for (const r of res) {
      all.push(r);
      if (r.ok) dispatched += 1;
      else failed += 1;
    }
  }
  return { dispatched, failed, results: all };
}

/** Send a test message to all configured channels. */
export async function sendTestMessage(
  settings: Settings
): Promise<DispatchResult[]> {
  const testPayload: NotificationPayload = {
    key: `test:${Date.now()}`,
    title: "🧪 Тестовое оповещение",
    body: "Оповещения работают! Это сообщение из ассистента репетитора.",
  };
  const results: DispatchResult[] = [];
  if (settings.maxEnabled) {
    results.push(await dispatchMax(settings, testPayload));
  }
  if (settings.vkEnabled) {
    results.push(await dispatchVk(settings, testPayload));
  }
  if (!settings.maxEnabled && !settings.vkEnabled) {
    results.push({
      channel: "max",
      ok: false,
      error: "Ни один внешний канал не включён",
    });
  }
  return results;
}
