import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSettings, saveSettings } from "@/lib/report";
import { addDays, startOfMonth, todayInTZ, weekdayMondayBased } from "@/lib/tz";

// Seed the database with realistic demo data centered around "today"
export async function POST() {
  const settings = await getSettings();
  const tz = settings.timezone;
  const today = todayInTZ(tz);

  // Wipe existing demo data
  await db.lesson.deleteMany();
  await db.student.deleteMany();

  const studentDefs = [
    { name: "Анна Иванова", phone: "+7 900 111-22-33", color: "emerald", grade: "9 класс", pricePerLesson: 1500, comment: "Английский, средний уровень" },
    { name: "Иван Петров", phone: "+7 900 222-33-44", color: "amber", grade: "11 класс", pricePerLesson: 1500, comment: "Математика, подготовка к ЕГЭ" },
    { name: "Мария Смирнова", phone: "+7 900 333-44-55", color: "violet", grade: "7 класс", pricePerLesson: 1500, comment: "Английский, начальный" },
    { name: "Олег Козлов", phone: "+7 901 444-55-66", color: "rose", grade: "10 класс", pricePerLesson: 2000, comment: "Физика" },
    { name: "Дарья Новикова", phone: "+7 902 555-66-77", color: "cyan", grade: "9 класс", pricePerLesson: 1200, comment: "Математика" },
    { name: "Павел Орлов", phone: "+7 903 666-77-88", color: "orange", grade: "", pricePerLesson: 1800, comment: "Английский, бизнес" },
  ];
  const byName = new Map<string, string>();
  for (const s of studentDefs) {
    const created = await db.student.create({ data: s });
    byName.set(s.name, created.id);
  }

  type PendingLesson = {
    date: string;
    timeStart: string;
    durationMinutes: number;
    studentId: string;
    subject: string;
    format: string;
    link: string | null;
    price: number;
    paidAmount: number;
    lessonStatus: string;
    paymentStatus: string;
    comment: string | null;
  };
  const lessons: PendingLesson[] = [];

  for (let offset = -7; offset <= 7; offset++) {
    const date = addDays(today, offset);
    const dow = weekdayMondayBased(date); // 0=Mon..6=Sun
    if (dow === 6) continue; // skip Sunday

    const slots: Array<{
      time: string;
      dur: number;
      student: string;
      subject: string;
      fmt: string;
      price: number;
    }> = [
      { time: "10:00", dur: 60, student: "Иван Петров", subject: "Математика", fmt: "online", price: 1500 },
      { time: "12:00", dur: 60, student: "Мария Смирнова", subject: "Английский язык", fmt: "online", price: 1500 },
      { time: "15:00", dur: 60, student: "Анна Иванова", subject: "Английский язык", fmt: "online", price: 1500 },
      { time: "17:00", dur: 90, student: "Олег Козлов", subject: "Физика", fmt: "offline", price: 2000 },
    ];
    if (dow === 1 || dow === 3 || dow === 5) {
      slots.push({ time: "19:00", dur: 60, student: "Дарья Новикова", subject: "Математика", fmt: "online", price: 1200 });
    }
    if (dow === 2 || dow === 4) {
      slots.push({ time: "20:00", dur: 60, student: "Павел Орлов", subject: "Английский язык", fmt: "online", price: 1800 });
    }

    for (const s of slots) {
      let lessonStatus = "planned";
      let paymentStatus = "unpaid";
      let paidAmount = 0;

      if (offset < 0) {
        lessonStatus = "conducted";
        if (offset === -1 && s.student === "Олег Козлов") {
          lessonStatus = "cancelled";
          paymentStatus = "free_trial";
          paidAmount = 0;
        } else if (s.student === "Анна Иванова" && (offset === -1 || offset === -3)) {
          paymentStatus = "unpaid";
          paidAmount = 0;
        } else if (s.student === "Олег Козлов" && offset === -2) {
          paymentStatus = "partial";
          paidAmount = 1000;
        } else if (s.student === "Павел Орлов" && offset === -2) {
          paymentStatus = "awaiting_confirmation";
          paidAmount = 0;
        } else {
          paymentStatus = "paid";
          paidAmount = s.price;
        }
      } else if (offset === 0) {
        if (s.time <= "12:00") {
          lessonStatus = "conducted";
          paymentStatus = "paid";
          paidAmount = s.price;
        } else {
          lessonStatus = "planned";
          paymentStatus = "unpaid";
          paidAmount = 0;
        }
      } else {
        if (offset === 2 && s.student === "Дарья Новикова") lessonStatus = "rescheduled";
        if (offset === 3 && s.student === "Иван Петров") lessonStatus = "cancelled";
      }

      lessons.push({
        date,
        timeStart: s.time,
        durationMinutes: s.dur,
        studentId: byName.get(s.student)!,
        subject: s.subject,
        format: s.fmt,
        link: s.fmt === "online" ? "https://zoom.us/j/1234567890?pwd=abc" : null,
        price: s.price,
        paidAmount,
        lessonStatus,
        paymentStatus,
        comment:
          lessonStatus === "cancelled"
            ? "Перенос по просьбе ученика"
            : paymentStatus === "partial"
              ? "Частичная оплата, остаток позже"
              : null,
      });
    }
  }

  await db.lesson.createMany({ data: lessons });

  // Add monthly prepayments for the current month for some students
  await db.monthlyPayment.deleteMany();
  const currentMonth = today.slice(0, 7);
  const prepayDefs: Array<{
    studentName: string;
    lessonsCount: number;
    amount: number;
  }> = [
    // Иван Петров — pays per lesson, no prepayment
    { studentName: "Мария Смирнова", lessonsCount: 8, amount: 12000 },
    { studentName: "Дарья Новикова", lessonsCount: 8, amount: 9600 },
    { studentName: "Павел Орлов", lessonsCount: 4, amount: 7200 },
  ];
  for (const p of prepayDefs) {
    const sid = byName.get(p.studentName);
    if (!sid) continue;
    await db.monthlyPayment.create({
      data: {
        studentId: sid,
        month: currentMonth,
        lessonsCount: p.lessonsCount,
        amount: p.amount,
        paid: true,
        paidAt: new Date(),
        comment: "Предоплата за месяц",
      },
    });
  }

  // Add a prepayment for the PREVIOUS month to demonstrate carryover balance.
  // Мария Смирнова paid for 8 lessons last month but only 5 were conducted →
  // unused 3 lessons × 1500 = 4500 ₽ carries over to the current month.
  const prevMonthDate = addDays(startOfMonth(currentMonth), -1);
  const prevMonth = prevMonthDate.slice(0, 7);
  const prevPrepayDefs: Array<{
    studentName: string;
    lessonsCount: number;
    amount: number;
  }> = [
    { studentName: "Мария Смирнова", lessonsCount: 8, amount: 12000 },
    { studentName: "Дарья Новикова", lessonsCount: 8, amount: 9600 },
  ];
  for (const p of prevPrepayDefs) {
    const sid = byName.get(p.studentName);
    if (!sid) continue;
    await db.monthlyPayment.create({
      data: {
        studentId: sid,
        month: prevMonth,
        lessonsCount: p.lessonsCount,
        amount: p.amount,
        paid: true,
        paidAt: new Date(),
        comment: "Предоплата за прошлый месяц",
      },
    });
  }

  await saveSettings({});

  return NextResponse.json({
    ok: true,
    students: studentDefs.length,
    lessons: lessons.length,
    prepayments: prepayDefs.length,
    today,
    timezone: tz,
  });
}
