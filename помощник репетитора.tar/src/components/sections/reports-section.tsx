"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Copy,
  Check,
  ChevronLeft,
  ChevronRight,
  FileText,
  Loader2,
  Sparkles,
  CalendarDays,
  Download,
  Users,
} from "lucide-react";
import { toast } from "sonner";
import { api } from "@/lib/api-client";
import { useSettings, useStudents, useStudentReport } from "@/lib/hooks";
import {
  addDays,
  endOfMonth,
  formatLongDate,
  formatMoney,
  formatShortDate,
  monthLabel,
  monthOf,
  nextMonth,
  prevMonth,
  startOfMonth,
  startOfWeek,
  todayInTZ,
  weekdayShort,
} from "@/lib/tz";
import type {
  DailyReport,
  MonthlyReport,
  WeeklyReport,
  YearlyReport,
} from "@/lib/types";
import { LessonStatusBadge, PaymentStatusBadge, StudentAvatar } from "@/components/status-badges";
import { endTime } from "@/lib/tz";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";

type ReportTab = "daily" | "weekly" | "monthly" | "yearly" | "student";

export function ReportsSection() {
  const { data: settings } = useSettings();
  const tz = settings?.timezone ?? "Europe/Moscow";
  const today = todayInTZ(tz);

  const [tab, setTab] = useState<ReportTab>("daily");
  const [dailyDate, setDailyDate] = useState<string>(today);
  const [weeklyDate, setWeeklyDate] = useState<string>(today);
  const [monthlyDate, setMonthlyDate] = useState<string>(today);
  const [yearlyYear, setYearlyYear] = useState<number>(Number(today.slice(0, 4)));
  const [studentReportStudentId, setStudentReportStudentId] = useState<string>("");
  const [studentReportFrom, setStudentReportFrom] = useState<string>(
    today.slice(0, 8) + "01"
  );
  const [studentReportTo, setStudentReportTo] = useState<string>(today);

  const weeklyStart = startOfWeek(weeklyDate);
  const weeklyEnd = addDays(weeklyStart, 6);
  const monthlyMonth = monthOf(monthlyDate);

  return (
    <div className="grid gap-5">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Отчёты</h1>
        <p className="text-sm text-muted-foreground">
          Сводки по занятиям и оплатам за любой период — по дню, неделе, месяцу,
          году и по ученику. Часовой пояс: {tz}.
        </p>
      </div>

      <Tabs value={tab} onValueChange={(v) => setTab(v as ReportTab)}>
        <TabsList className="flex-wrap">
          <TabsTrigger value="daily">День</TabsTrigger>
          <TabsTrigger value="weekly">Неделя</TabsTrigger>
          <TabsTrigger value="monthly">Месяц</TabsTrigger>
          <TabsTrigger value="yearly">Год</TabsTrigger>
          <TabsTrigger value="student">По ученику</TabsTrigger>
        </TabsList>
      </Tabs>

      {tab === "daily" ? (
        <DailyReportView
          date={dailyDate}
          tz={tz}
          onPrev={() => setDailyDate(addDays(dailyDate, -1))}
          onNext={() => setDailyDate(addDays(dailyDate, 1))}
          onToday={() => setDailyDate(today)}
        />
      ) : tab === "weekly" ? (
        <WeeklyReportView
          startDate={weeklyStart}
          endDate={weeklyEnd}
          tz={tz}
          onPrev={() => setWeeklyDate(addDays(weeklyDate, -7))}
          onNext={() => setWeeklyDate(addDays(weeklyDate, 7))}
          onThisWeek={() => setWeeklyDate(today)}
        />
      ) : tab === "monthly" ? (
        <MonthlyReportView
          month={monthlyMonth}
          tz={tz}
          onPrev={() => setMonthlyDate(endOfMonth(prevMonth(monthlyMonth)))}
          onNext={() => setMonthlyDate(startOfMonth(nextMonth(monthlyMonth)))}
          onThis={() => setMonthlyDate(today)}
        />
      ) : tab === "yearly" ? (
        <YearlyReportView
          year={yearlyYear}
          tz={tz}
          onPrev={() => setYearlyYear(yearlyYear - 1)}
          onNext={() => setYearlyYear(yearlyYear + 1)}
          onThis={() => setYearlyYear(Number(today.slice(0, 4)))}
        />
      ) : (
        <StudentReportView
          studentId={studentReportStudentId}
          from={studentReportFrom}
          to={studentReportTo}
          onSelectStudent={setStudentReportStudentId}
          onFromChange={setStudentReportFrom}
          onToChange={setStudentReportTo}
        />
      )}
    </div>
  );
}

function CopyButton({ text }: { text: string }) {
  const [copied, setCopied] = useState(false);
  return (
    <Button
      variant="outline"
      size="sm"
      onClick={() => {
        navigator.clipboard.writeText(text);
        setCopied(true);
        toast.success("Отчёт скопирован");
        setTimeout(() => setCopied(false), 2000);
      }}
    >
      {copied ? (
        <>
          <Check className="mr-1 h-4 w-4" /> Скопировано
        </>
      ) : (
        <>
          <Copy className="mr-1 h-4 w-4" /> Копировать текст
        </>
      )}
    </Button>
  );
}

function WordDownloadButton({
  url,
  fileName,
  label = "Word",
}: {
  url: string;
  fileName: string;
  label?: string;
}) {
  const [loading, setLoading] = useState(false);
  return (
    <Button
      variant="outline"
      size="sm"
      disabled={loading}
      onClick={async () => {
        setLoading(true);
        try {
          const res = await fetch(url);
          if (!res.ok) throw new Error(`Ошибка ${res.status}`);
          const blob = await res.blob();
          const objectUrl = URL.createObjectURL(blob);
          const a = document.createElement("a");
          a.href = objectUrl;
          a.download = fileName;
          document.body.appendChild(a);
          a.click();
          a.remove();
          URL.revokeObjectURL(objectUrl);
          toast.success("Документ Word скачан");
        } catch (e) {
          toast.error((e as Error).message);
        } finally {
          setLoading(false);
        }
      }}
    >
      {loading ? (
        <Loader2 className="mr-1 h-4 w-4 animate-spin" />
      ) : (
        <Download className="mr-1 h-4 w-4" />
      )}
      {label}
    </Button>
  );
}

function DateNav({
  label,
  onPrev,
  onNext,
  onToday,
}: {
  label: string;
  onPrev: () => void;
  onNext: () => void;
  onToday: () => void;
}) {
  return (
    <div className="flex items-center justify-between">
      <Button variant="ghost" size="sm" onClick={onPrev}>
        <ChevronLeft className="h-4 w-4" /> Назад
      </Button>
      <span className="text-sm font-medium">{label}</span>
      <div className="flex gap-1">
        <Button variant="outline" size="sm" onClick={onToday}>
          Сегодня
        </Button>
        <Button variant="ghost" size="sm" onClick={onNext}>
          Вперёд <ChevronRight className="h-4 w-4" />
        </Button>
      </div>
    </div>
  );
}

function DailyReportView({
  date,
  tz,
  onPrev,
  onNext,
  onToday,
}: {
  date: string;
  tz: string;
  onPrev: () => void;
  onNext: () => void;
  onToday: () => void;
}) {
  // key remount re-fetches when date changes
  return (
    <DailyReportInner
      key={date}
      date={date}
      tz={tz}
      onPrev={onPrev}
      onNext={onNext}
      onToday={onToday}
    />
  );
}

function DailyReportInner({
  date,
  tz,
  onPrev,
  onNext,
  onToday,
}: {
  date: string;
  tz: string;
  onPrev: () => void;
  onNext: () => void;
  onToday: () => void;
}) {
  const [report, setReport] = useState<DailyReport | null>(null);
  const [loading, setLoading] = useState(true);

  useAsyncEffect(async () => {
    setLoading(true);
    try {
      const r = await api.get<DailyReport>(`/api/reports/daily?date=${date}`);
      setReport(r);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [date]);

  if (loading || !report) {
    return (
      <div className="grid gap-3">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  return (
    <div className="grid gap-4">
      <DateNav
        label={formatLongDate(date)}
        onPrev={onPrev}
        onNext={onNext}
        onToday={onToday}
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <MiniStat label="Всего" value={report.total} tone="zinc" />
        <MiniStat label="Проведено" value={report.conducted} tone="emerald" />
        <MiniStat label="Отменено" value={report.cancelled} tone="zinc" />
        <MiniStat label="Перенесено" value={report.rescheduled} tone="amber" />
        <MiniStat label="Оплачено" value={report.paid} tone="emerald" />
        <MiniStat label="Не оплачено" value={report.unpaid} tone="rose" />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <MoneyCard label="Сумма к оплате" value={report.expectedTotal} tone="sky" />
        <MoneyCard label="Получено" value={report.receivedTotal} tone="emerald" />
        <MoneyCard
          label="Долг"
          value={report.debtTotal}
          tone={report.debtTotal > 0 ? "rose" : "emerald"}
        />
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="text-base">Занятия за день</CardTitle>
          <div className="flex gap-2">
            <WordDownloadButton
              url={`/api/reports/daily/docx?date=${date}`}
              fileName={`daily-${date}.docx`}
            />
            <CopyButton text={report.text} />
          </div>
        </CardHeader>
        <CardContent>
          {report.lessons.length === 0 ? (
            <div className="py-8 text-center text-sm text-muted-foreground">
              Ежедневный отчёт за {formatShortDate(date)}: занятий не было.
            </div>
          ) : (
            <div className="grid gap-2">
              {report.lessons.map((l, i) => (
                <div
                  key={l.id}
                  className="flex items-center gap-3 rounded-lg border p-2.5"
                >
                  <span className="text-xs font-medium text-muted-foreground">
                    {i + 1}.
                  </span>
                  <div className="w-24 shrink-0 text-sm font-medium">
                    {l.timeStart}–{endTime(l.timeStart, l.durationMinutes)}
                  </div>
                  <div className="min-w-0 flex-1">
                    <p className="truncate text-sm font-medium">
                      {l.student.name}
                    </p>
                    <p className="text-xs text-muted-foreground">{l.subject}</p>
                  </div>
                  <LessonStatusBadge status={l.lessonStatus} />
                  <PaymentStatusBadge status={l.paymentStatus} />
                  <span className="w-20 text-right text-sm font-medium">
                    {formatMoney(l.price)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      <div className="grid gap-3 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Не оплатили</CardTitle>
          </CardHeader>
          <CardContent>
            {report.debtors.length === 0 ? (
              <p className="py-4 text-center text-sm text-muted-foreground">
                Неоплаченных занятий нет.
              </p>
            ) : (
              <div className="grid gap-2">
                {report.debtors.map((d, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between rounded-lg border border-rose-200 bg-rose-50/40 p-2.5 dark:border-rose-500/30 dark:bg-rose-500/5"
                  >
                    <span className="text-sm font-medium">{d.studentName}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground">
                        {formatShortDate(d.date)}
                      </span>
                      <span className="text-sm font-semibold text-rose-600">
                        {formatMoney(d.amount)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Завтра</CardTitle>
          </CardHeader>
          <CardContent>
            {report.tomorrow.length === 0 ? (
              <p className="py-4 text-center text-sm text-muted-foreground">
                Завтра занятий нет.
              </p>
            ) : (
              <div className="grid gap-2">
                {report.tomorrow.map((t, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between rounded-lg border p-2.5"
                  >
                    <div>
                      <p className="text-sm font-medium">{t.studentName}</p>
                      <p className="text-xs text-muted-foreground">
                        {t.subject}
                      </p>
                    </div>
                    <span className="text-sm font-medium">{t.time}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4" /> Текст отчёта
          </CardTitle>
        </CardHeader>
        <CardContent>
          <pre className="max-h-72 overflow-y-auto whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-xs leading-relaxed">
            {report.text}
          </pre>
        </CardContent>
      </Card>
    </div>
  );
}

function WeeklyReportView({
  startDate,
  endDate,
  tz,
  onPrev,
  onNext,
  onThisWeek,
}: {
  startDate: string;
  endDate: string;
  tz: string;
  onPrev: () => void;
  onNext: () => void;
  onThisWeek: () => void;
}) {
  return (
    <WeeklyReportInner
      key={startDate}
      startDate={startDate}
      endDate={endDate}
      tz={tz}
      onPrev={onPrev}
      onNext={onNext}
      onThisWeek={onThisWeek}
    />
  );
}

function WeeklyReportInner({
  startDate,
  endDate,
  onPrev,
  onNext,
  onThisWeek,
}: {
  startDate: string;
  endDate: string;
  tz: string;
  onPrev: () => void;
  onNext: () => void;
  onThisWeek: () => void;
}) {
  const [report, setReport] = useState<WeeklyReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [summary, setSummary] = useState<string>("");
  const [summaryLoading, setSummaryLoading] = useState(false);

  useAsyncEffect(async () => {
    setLoading(true);
    setSummary("");
    try {
      const r = await api.get<WeeklyReport>(
        `/api/reports/weekly?date=${startDate}`
      );
      setReport(r);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [startDate]);

  async function generateSummary() {
    if (!report) return;
    setSummaryLoading(true);
    try {
      const res = await api.post<{ summary: string }>(
        `/api/reports/summary?date=${startDate}`
      );
      setSummary(res.summary);
      toast.success("Итог сформирован");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setSummaryLoading(false);
    }
  }

  if (loading || !report) {
    return (
      <div className="grid gap-3">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const maxDay = Math.max(1, ...report.byDay.map((d) => d.count));

  return (
    <div className="grid gap-4">
      <DateNav
        label={`${formatShortDate(startDate)} — ${formatShortDate(endDate)}`}
        onPrev={onPrev}
        onNext={onNext}
        onToday={onThisWeek}
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <MiniStat label="Всего" value={report.total} tone="zinc" />
        <MiniStat label="Проведено" value={report.conducted} tone="emerald" />
        <MiniStat label="Отменено" value={report.cancelled} tone="zinc" />
        <MiniStat label="Перенесено" value={report.rescheduled} tone="amber" />
        <MiniStat label="Оплачено" value={report.paid} tone="emerald" />
        <MiniStat label="Не оплачено" value={report.unpaid} tone="rose" />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <MoneyCard label="Получено" value={report.receivedTotal} tone="emerald" />
        <MoneyCard
          label="К оплате (остаток)"
          value={Math.max(0, report.expectedTotal - report.receivedTotal)}
          tone="sky"
        />
        <MoneyCard
          label="Общий долг"
          value={report.debtTotal}
          tone={report.debtTotal > 0 ? "rose" : "emerald"}
        />
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <CalendarDays className="h-4 w-4" /> По дням недели
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2">
            {report.byDay.map((d) => (
              <div key={d.day} className="flex items-center gap-3">
                <span className="w-28 shrink-0 text-sm text-muted-foreground">
                  {d.day}
                </span>
                <div className="h-6 flex-1 overflow-hidden rounded-md bg-muted">
                  <div
                    className="flex h-full items-center justify-end rounded-md bg-emerald-500/80 px-2 text-[10px] font-medium text-white"
                    style={{
                      width: `${Math.max(8, (d.count / maxDay) * 100)}%`,
                    }}
                  >
                    {d.count > 0 ? d.count : ""}
                  </div>
                </div>
                <span className="w-24 shrink-0 text-right text-xs text-muted-foreground">
                  {d.conducted} пров.
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-3 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Должники за неделю</CardTitle>
          </CardHeader>
          <CardContent>
            {report.debtors.length === 0 ? (
              <p className="py-4 text-center text-sm text-muted-foreground">
                Неоплаченных занятий нет.
              </p>
            ) : (
              <div className="grid gap-2">
                {report.debtors.map((d, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between rounded-lg border border-rose-200 bg-rose-50/40 p-2.5 dark:border-rose-500/30 dark:bg-rose-500/5"
                  >
                    <span className="text-sm font-medium">{d.studentName}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground">
                        {d.lessonsCount} зан.
                      </span>
                      <span className="text-sm font-semibold text-rose-600">
                        {formatMoney(d.amount)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
            <CardTitle className="text-base">По ученикам</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid max-h-72 gap-2 overflow-y-auto pr-1">
              {report.byStudent.map((s, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between rounded-lg border p-2.5"
                >
                  <span className="text-sm font-medium">{s.studentName}</span>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-muted-foreground">
                      {s.conducted}/{s.total} пров.
                    </span>
                    <span className="font-medium text-emerald-600">
                      {formatMoney(s.revenue)}
                    </span>
                    {s.debt > 0 && (
                      <span className="font-medium text-rose-600">
                        {formatMoney(s.debt)}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4" /> Текст отчёта
          </CardTitle>
          <div className="flex gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={generateSummary}
              disabled={summaryLoading}
            >
              {summaryLoading ? (
                <>
                  <Loader2 className="mr-1 h-4 w-4 animate-spin" /> Генерация...
                </>
              ) : (
                <>
                  <Sparkles className="mr-1 h-4 w-4 text-emerald-600" /> Итог через ИИ
                </>
              )}
            </Button>
            <WordDownloadButton
              url={`/api/reports/weekly/docx?date=${startDate}`}
              fileName={`weekly-${startDate}.docx`}
            />
            <CopyButton text={report.text} />
          </div>
        </CardHeader>
        <CardContent>
          {summary && (
            <div className="mb-3 rounded-lg border border-emerald-200 bg-emerald-50/50 p-3 text-sm dark:border-emerald-500/30 dark:bg-emerald-500/10">
              <p className="mb-1 text-xs font-medium uppercase text-emerald-700 dark:text-emerald-300">
                Краткий итог
              </p>
              <p className="text-sm">{summary}</p>
            </div>
          )}
          <pre className="max-h-72 overflow-y-auto whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-xs leading-relaxed">
            {report.text}
          </pre>
        </CardContent>
      </Card>
    </div>
  );
}

function MiniStat({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: "zinc" | "emerald" | "rose" | "amber";
}) {
  const tones = {
    zinc: "text-zinc-700 dark:text-zinc-300",
    emerald: "text-emerald-600 dark:text-emerald-400",
    rose: "text-rose-600 dark:text-rose-400",
    amber: "text-amber-600 dark:text-amber-400",
  };
  return (
    <Card>
      <CardContent className="p-3">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className={cn("mt-1 text-xl font-semibold", tones[tone])}>{value}</p>
      </CardContent>
    </Card>
  );
}

function MoneyCard({
  label,
  value,
  tone,
}: {
  label: string;
  value: number;
  tone: "sky" | "emerald" | "rose";
}) {
  const tones = {
    sky: "text-sky-600 dark:text-sky-400",
    emerald: "text-emerald-600 dark:text-emerald-400",
    rose: "text-rose-600 dark:text-rose-400",
  };
  return (
    <Card>
      <CardContent className="p-4">
        <p className="text-xs text-muted-foreground">{label}</p>
        <p className={cn("mt-1 text-2xl font-semibold tracking-tight", tones[tone])}>
          {formatMoney(value)}
        </p>
      </CardContent>
    </Card>
  );
}

// ---------------------------------------------------------------------------
// Monthly report view
// ---------------------------------------------------------------------------

function MonthlyReportView({
  month,
  tz,
  onPrev,
  onNext,
  onThis,
}: {
  month: string;
  tz: string;
  onPrev: () => void;
  onNext: () => void;
  onThis: () => void;
}) {
  return (
    <MonthlyReportInner
      key={month}
      month={month}
      tz={tz}
      onPrev={onPrev}
      onNext={onNext}
      onThis={onThis}
    />
  );
}

function MonthlyReportInner({
  month,
  onPrev,
  onNext,
  onThis,
}: {
  month: string;
  tz: string;
  onPrev: () => void;
  onNext: () => void;
  onThis: () => void;
}) {
  const [report, setReport] = useState<MonthlyReport | null>(null);
  const [loading, setLoading] = useState(true);

  useAsyncEffect(async () => {
    setLoading(true);
    try {
      const r = await api.get<MonthlyReport>(
        `/api/reports/monthly?date=${startOfMonth(month)}`
      );
      setReport(r);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [month]);

  if (loading || !report) {
    return (
      <div className="grid gap-3">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const maxWeek = Math.max(1, ...report.byWeek.map((w) => w.count));

  return (
    <div className="grid gap-4">
      <DateNav
        label={`${monthLabel(month)}`}
        onPrev={onPrev}
        onNext={onNext}
        onToday={onThis}
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <MiniStat label="Всего" value={report.total} tone="zinc" />
        <MiniStat label="Проведено" value={report.conducted} tone="emerald" />
        <MiniStat label="Отменено" value={report.cancelled} tone="zinc" />
        <MiniStat label="Перенесено" value={report.rescheduled} tone="amber" />
        <MiniStat label="Оплачено" value={report.paid} tone="emerald" />
        <MiniStat label="Не оплачено" value={report.unpaid} tone="rose" />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <MoneyCard
          label="Оплата по занятиям"
          value={report.receivedTotal}
          tone="emerald"
        />
        <MoneyCard
          label="Предоплаты за месяц"
          value={report.prepaymentTotal}
          tone="sky"
        />
        <MoneyCard
          label="Всего получено"
          value={report.grandReceived}
          tone="emerald"
        />
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <CalendarDays className="h-4 w-4" /> По неделям
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2">
            {report.byWeek.map((w, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="w-56 shrink-0 text-xs text-muted-foreground">
                  {w.label}
                </span>
                <div className="h-6 flex-1 overflow-hidden rounded-md bg-muted">
                  <div
                    className="flex h-full items-center justify-end rounded-md bg-emerald-500/80 px-2 text-[10px] font-medium text-white"
                    style={{
                      width: `${Math.max(8, (w.count / maxWeek) * 100)}%`,
                    }}
                  >
                    {w.count > 0 ? w.count : ""}
                  </div>
                </div>
                <span className="w-24 shrink-0 text-right text-xs text-muted-foreground">
                  {w.conducted} пров.
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {report.prepayments.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Предоплаты за месяц</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2">
              {report.byStudent
                .filter((s) => s.prepaid)
                .map((s, i) => (
                  <div
                    key={i}
                    className="flex flex-wrap items-center justify-between gap-2 rounded-lg border p-2.5"
                  >
                    <span className="text-sm font-medium">{s.studentName}</span>
                    <div className="flex flex-wrap items-center gap-3 text-xs">
                      <span className="text-muted-foreground">
                        {s.prepaid!.lessonsCount} зан. ·{" "}
                        {formatMoney(s.prepaid!.amount)}
                      </span>
                      <span className="text-muted-foreground">
                        проведено {s.prepaid!.conductedThisMonth}
                      </span>
                      <span
                        className={cn(
                          "font-medium",
                          s.prepaid!.remaining > 0
                            ? "text-emerald-700 dark:text-emerald-300"
                            : "text-amber-600"
                        )}
                      >
                        {s.prepaid!.remaining > 0
                          ? `осталось ${s.prepaid!.remaining}`
                          : "лимит исчерпан"}
                      </span>
                    </div>
                  </div>
                ))}
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid gap-3 lg:grid-cols-2">
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Должники за месяц</CardTitle>
          </CardHeader>
          <CardContent>
            {report.debtors.length === 0 ? (
              <p className="py-4 text-center text-sm text-muted-foreground">
                Должников нет.
              </p>
            ) : (
              <div className="grid gap-2">
                {report.debtors.map((d, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between rounded-lg border border-rose-200 bg-rose-50/40 p-2.5 dark:border-rose-500/30 dark:bg-rose-500/5"
                  >
                    <span className="text-sm font-medium">{d.studentName}</span>
                    <div className="flex items-center gap-3">
                      <span className="text-xs text-muted-foreground">
                        {d.lessonsCount} зан.
                      </span>
                      <span className="text-sm font-semibold text-rose-600">
                        {formatMoney(d.amount)}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">По ученикам</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid max-h-72 gap-2 overflow-y-auto pr-1">
              {report.byStudent.map((s, i) => (
                <div
                  key={i}
                  className="flex items-center justify-between rounded-lg border p-2.5"
                >
                  <span className="text-sm font-medium">{s.studentName}</span>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-muted-foreground">
                      {s.conducted}/{s.total} пров.
                    </span>
                    <span className="font-medium text-emerald-600">
                      {formatMoney(s.revenue)}
                    </span>
                    {s.debt > 0 && (
                      <span className="font-medium text-rose-600">
                        {formatMoney(s.debt)}
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4" /> Текст отчёта
          </CardTitle>
          <div className="flex gap-2">
            <WordDownloadButton
              url={`/api/reports/monthly/docx?date=${report.startDate}`}
              fileName={`monthly-${report.month}.docx`}
            />
            <CopyButton text={report.text} />
          </div>
        </CardHeader>
        <CardContent>
          <pre className="max-h-80 overflow-y-auto whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-xs leading-relaxed">
            {report.text}
          </pre>
        </CardContent>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Yearly report view
// ---------------------------------------------------------------------------

function YearlyReportView({
  year,
  tz,
  onPrev,
  onNext,
  onThis,
}: {
  year: number;
  tz: string;
  onPrev: () => void;
  onNext: () => void;
  onThis: () => void;
}) {
  return (
    <YearlyReportInner
      key={year}
      year={year}
      tz={tz}
      onPrev={onPrev}
      onNext={onNext}
      onThis={onThis}
    />
  );
}

function YearlyReportInner({
  year,
  onPrev,
  onNext,
  onThis,
}: {
  year: number;
  tz: string;
  onPrev: () => void;
  onNext: () => void;
  onThis: () => void;
}) {
  const [report, setReport] = useState<YearlyReport | null>(null);
  const [loading, setLoading] = useState(true);

  useAsyncEffect(async () => {
    setLoading(true);
    try {
      const r = await api.get<YearlyReport>(`/api/reports/yearly?year=${year}`);
      setReport(r);
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }, [year]);

  if (loading || !report) {
    return (
      <div className="grid gap-3">
        <Skeleton className="h-10 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  const maxMonth = Math.max(1, ...report.byMonth.map((m) => m.count));

  return (
    <div className="grid gap-4">
      <DateNav
        label={`${year} год`}
        onPrev={onPrev}
        onNext={onNext}
        onToday={onThis}
      />

      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <MiniStat label="Всего" value={report.total} tone="zinc" />
        <MiniStat label="Проведено" value={report.conducted} tone="emerald" />
        <MiniStat label="Отменено" value={report.cancelled} tone="zinc" />
        <MiniStat label="Перенесено" value={report.rescheduled} tone="amber" />
        <MiniStat label="Оплачено" value={report.paid} tone="emerald" />
        <MiniStat label="Не оплачено" value={report.unpaid} tone="rose" />
      </div>

      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <MoneyCard
          label="Оплата по занятиям"
          value={report.receivedTotal}
          tone="emerald"
        />
        <MoneyCard
          label="Предоплаты за год"
          value={report.prepaymentTotal}
          tone="sky"
        />
        <MoneyCard
          label="Всего получено за год"
          value={report.grandReceived}
          tone="emerald"
        />
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <CalendarDays className="h-4 w-4" /> По месяцам
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid gap-2">
            {report.byMonth.map((m, i) => (
              <div key={i} className="flex items-center gap-3">
                <span className="w-28 shrink-0 text-sm text-muted-foreground">
                  {m.label}
                </span>
                <div className="h-6 flex-1 overflow-hidden rounded-md bg-muted">
                  <div
                    className="flex h-full items-center justify-end rounded-md bg-emerald-500/80 px-2 text-[10px] font-medium text-white"
                    style={{
                      width: `${Math.max(8, (m.count / maxMonth) * 100)}%`,
                    }}
                  >
                    {m.count > 0 ? m.count : ""}
                  </div>
                </div>
                <span className="w-28 shrink-0 text-right text-xs text-muted-foreground">
                  {m.conducted} пров. · {formatMoney(m.revenue)}
                </span>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4" /> Текст отчёта
          </CardTitle>
          <div className="flex gap-2">
            <WordDownloadButton
              url={`/api/reports/yearly/docx?year=${year}`}
              fileName={`yearly-${year}.docx`}
            />
            <CopyButton text={report.text} />
          </div>
        </CardHeader>
        <CardContent>
          <pre className="max-h-80 overflow-y-auto whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-xs leading-relaxed">
            {report.text}
          </pre>
        </CardContent>
      </Card>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Student report view (custom period for one student)
// ---------------------------------------------------------------------------

function StudentReportView({
  studentId,
  from,
  to,
  onSelectStudent,
  onFromChange,
  onToChange,
}: {
  studentId: string;
  from: string;
  to: string;
  onSelectStudent: (id: string) => void;
  onFromChange: (d: string) => void;
  onToChange: (d: string) => void;
}) {
  const { data: students = [] } = useStudents();
  const { data: report, isLoading } = useStudentReport(
    studentId || undefined,
    from || undefined,
    to || undefined
  );

  return (
    <div className="grid gap-4">
      {/* Controls: student + date range */}
      <Card>
        <CardContent className="grid gap-3 p-4">
          <div className="grid gap-1.5">
            <Label htmlFor="sr-student">Ученик</Label>
            <Select value={studentId} onValueChange={onSelectStudent}>
              <SelectTrigger id="sr-student">
                <SelectValue placeholder="Выберите ученика" />
              </SelectTrigger>
              <SelectContent>
                {students.map((s) => (
                  <SelectItem key={s.id} value={s.id}>
                    {s.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="sr-from">С даты</Label>
              <Input
                id="sr-from"
                type="date"
                value={from}
                onChange={(e) => onFromChange(e.target.value)}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="sr-to">По дату</Label>
              <Input
                id="sr-to"
                type="date"
                value={to}
                onChange={(e) => onToChange(e.target.value)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {!studentId ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center gap-2 py-10 text-center">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-muted-foreground">
              <Users className="h-5 w-5" />
            </div>
            <p className="text-sm font-medium">Выберите ученика</p>
            <p className="text-xs text-muted-foreground">
              Укажите ученика и период — отчёт построится автоматически.
            </p>
          </CardContent>
        </Card>
      ) : isLoading ? (
        <div className="grid gap-3">
          <Skeleton className="h-32 w-full" />
          <Skeleton className="h-48 w-full" />
        </div>
      ) : !report ? (
        <Card>
          <CardContent className="py-8 text-center text-sm text-muted-foreground">
            Нет данных за указанный период.
          </CardContent>
        </Card>
      ) : (
        <StudentReportContent report={report} />
      )}
    </div>
  );
}

function StudentReportContent({ report }: { report: import("@/lib/types").StudentReport }) {
  return (
    <div className="grid gap-4">
      {/* Student info header */}
      <Card>
        <CardContent className="p-4">
          <div className="flex items-center gap-3">
            <StudentAvatar name={report.student.name} color={report.student.color} size="lg" />
            <div>
              <h2 className="text-xl font-semibold">{report.student.name}</h2>
              <p className="text-sm text-muted-foreground">
                {formatShortDate(report.startDate)} — {formatShortDate(report.endDate)}
              </p>
              {report.student.grade && (
                <p className="text-xs text-muted-foreground">
                  Класс: {report.student.grade}
                  {report.student.pricePerLesson
                    ? ` · ${formatMoney(report.student.pricePerLesson)} за урок`
                    : ""}
                </p>
              )}
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
        <MiniStat label="Всего" value={report.total} tone="zinc" />
        <MiniStat label="Проведено" value={report.conducted} tone="emerald" />
        <MiniStat label="Отменено" value={report.cancelled} tone="zinc" />
        <MiniStat label="Перенесено" value={report.rescheduled} tone="amber" />
        <MiniStat label="Оплачено" value={report.paid} tone="emerald" />
        <MiniStat label="Не оплачено" value={report.unpaid} tone="rose" />
      </div>

      {/* Money */}
      <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
        <MoneyCard label="Сумма к оплате" value={report.expectedTotal} tone="sky" />
        <MoneyCard
          label={report.prepaymentTotal > 0 ? "Получено (занятия + предоплаты)" : "Получено"}
          value={report.grandReceived}
          tone="emerald"
        />
        <MoneyCard
          label="Долг"
          value={report.debtTotal}
          tone={report.debtTotal > 0 ? "rose" : "emerald"}
        />
      </div>

      {report.carryoverBalanceTotal > 0 && (
        <div className="rounded-lg border border-sky-200 bg-sky-50/60 p-3 dark:border-sky-500/30 dark:bg-sky-500/5">
          <p className="text-sm font-medium text-sky-700 dark:text-sky-300">
            Остались деньги с прошлых месяцев: {formatMoney(report.carryoverBalanceTotal)}
          </p>
        </div>
      )}

      {/* Lessons list */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="text-base">Занятия за период</CardTitle>
          <CopyButton text={report.text} />
        </CardHeader>
        <CardContent>
          {report.lessons.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              Занятий за период нет.
            </p>
          ) : (
            <div className="grid max-h-[36rem] gap-2 overflow-y-auto pr-1">
              {report.lessons.map((l) => (
                <div
                  key={l.id}
                  className="flex items-center gap-3 rounded-lg border p-2.5"
                >
                  <div className="w-24 shrink-0 text-sm font-medium">
                    {formatShortDate(l.date)}
                  </div>
                  <div className="w-20 shrink-0">
                    <span className="inline-flex items-center gap-1 rounded-md bg-emerald-600 px-2 py-0.5 text-sm font-bold text-white">
                      {l.timeStart}
                    </span>
                  </div>
                  <div className="min-w-0 flex-1">
                    <LessonStatusBadge status={l.lessonStatus} />
                    <PaymentStatusBadge status={l.paymentStatus} />
                  </div>
                  <span className="w-24 text-right text-sm font-medium">
                    {formatMoney(l.price)}
                  </span>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Prepayments */}
      {report.prepayments.length > 0 && (
        <Card>
          <CardHeader className="pb-3">
            <CardTitle className="text-base">Предоплаты за период</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid gap-2">
              {report.prepayments.map((p) => (
                <div
                  key={p.id}
                  className="flex items-center justify-between rounded-lg border p-2.5"
                >
                  <span className="text-sm font-medium">
                    {monthLabel(p.month)}
                  </span>
                  <div className="flex items-center gap-3 text-xs">
                    <span className="text-muted-foreground">
                      {p.lessonsCount} зан.
                    </span>
                    <span className="font-medium text-emerald-600">
                      {formatMoney(p.amount)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Text report */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <FileText className="h-4 w-4" /> Текст отчёта
          </CardTitle>
          <CopyButton text={report.text} />
        </CardHeader>
        <CardContent>
          <pre className="max-h-80 overflow-y-auto whitespace-pre-wrap rounded-lg bg-muted/50 p-3 text-xs leading-relaxed">
            {report.text}
          </pre>
        </CardContent>
      </Card>
    </div>
  );
}

// Tiny async-effect helper
import { useEffect } from "react";
function useAsyncEffect(fn: () => Promise<void> | void, deps: any[]) {
  useEffect(() => {
    let cancelled = false;
    Promise.resolve(fn()).catch(() => {});
    return () => {
      cancelled = true;
    };
  }, deps);
}
