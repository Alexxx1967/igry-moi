"use client";

import { useEffect, useMemo, useState } from "react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  CalendarDays,
  LayoutDashboard,
  Wallet,
  FileText,
  Users,
  Settings2,
  Plus,
  Sun,
  Moon,
  GraduationCap,
  Clock,
  AlertTriangle,
  Sparkles,
} from "lucide-react";
import { useTheme } from "next-themes";
import { useDashboard, useSettings } from "@/lib/hooks";
import { TodaySection } from "@/components/sections/today-section";
import { ScheduleSection } from "@/components/sections/schedule-section";
import { PaymentsSection } from "@/components/sections/payments-section";
import { ReportsSection } from "@/components/sections/reports-section";
import { StudentsSection } from "@/components/sections/students-section";
import { SettingsSection } from "@/components/sections/settings-section";
import { LessonFormDialog } from "@/components/lesson-form-dialog";
import { NotificationBell } from "@/components/notification-bell";
import { FontSizeControl } from "@/components/font-size-control";
import { formatLongDate, formatMoney, todayInTZ, weekdayName } from "@/lib/tz";

type Section =
  | "today"
  | "schedule"
  | "payments"
  | "reports"
  | "students"
  | "settings";

const NAV: { id: Section; label: string; icon: React.ReactNode }[] = [
  { id: "today", label: "Сегодня", icon: <LayoutDashboard className="h-4 w-4" /> },
  { id: "schedule", label: "Расписание", icon: <CalendarDays className="h-4 w-4" /> },
  { id: "payments", label: "Оплаты", icon: <Wallet className="h-4 w-4" /> },
  { id: "reports", label: "Отчёты", icon: <FileText className="h-4 w-4" /> },
  { id: "students", label: "Ученики", icon: <Users className="h-4 w-4" /> },
  { id: "settings", label: "Настройки", icon: <Settings2 className="h-4 w-4" /> },
];

export default function Home() {
  const [section, setSection] = useState<Section>("today");
  const [addLessonSignal, setAddLessonSignal] = useState(0);
  const [addOpen, setAddOpen] = useState(false);
  const { theme, setTheme } = useTheme();
  const [mounted, setMounted] = useState(false);
  useEffect(() => setMounted(true), []);

  const { data: dash } = useDashboard();
  const { data: settings } = useSettings();
  const tz = settings?.timezone ?? "Europe/Moscow";

  // On first load, switch to the section requested via ?section= (PWA shortcut).
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const s = params.get("section");
    if (s && ["today", "schedule", "payments", "reports", "students", "settings"].includes(s)) {
      setSection(s as Section);
    }
  }, []);

  // Listen for navigation events coming from notification clicks (via SW).
  useEffect(() => {
    const handler = (e: Event) => {
      const detail = (e as CustomEvent<string>).detail;
      if (
        detail &&
        ["today", "schedule", "payments", "reports", "students", "settings"].includes(detail)
      ) {
        setSection(detail as Section);
      }
    };
    window.addEventListener("ta:navigate", handler);
    return () => window.removeEventListener("ta:navigate", handler);
  }, []);

  const handleBellNavigate = (s: string) => {
    if (["today", "schedule", "payments", "reports", "students", "settings"].includes(s)) {
      setSection(s as Section);
    }
  };

  // Live clock
  const [clock, setClock] = useState<string>("");
  useEffect(() => {
    const update = () => {
      try {
        setClock(
          new Intl.DateTimeFormat("ru-RU", {
            timeZone: tz,
            hour: "2-digit",
            minute: "2-digit",
            second: "2-digit",
          }).format(new Date())
        );
      } catch {
        setClock("--:--:--");
      }
    };
    update();
    const t = setInterval(update, 1000);
    return () => clearInterval(t);
  }, [tz]);

  function handleAddLesson() {
    setAddLessonSignal((n) => n + 1);
    setAddOpen(true);
  }

  const debt = dash?.debtTotal ?? 0;
  const nextReminder = dash?.reminders?.[0];

  return (
    <div className="flex min-h-screen flex-col">
      {/* Header */}
      <header className="sticky top-0 z-30 border-b bg-background/80 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-6xl items-center justify-between gap-3 px-3 sm:px-4">
          <div className="flex items-center gap-2">
            <div className="flex h-8 w-8 items-center justify-center rounded-lg bg-emerald-600 text-white">
              <GraduationCap className="h-5 w-5" />
            </div>
            <div className="leading-tight">
              <p className="text-sm font-semibold">Ассистент репетитора</p>
              <p className="hidden text-[10px] text-muted-foreground sm:block">
                занятия · оплаты · отчёты
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <div className="hidden items-center gap-1.5 rounded-lg border bg-muted/40 px-2.5 py-1 text-xs sm:flex">
              <Clock className="h-3.5 w-3.5 text-muted-foreground" />
              <span className="font-medium tabular-nums">{clock}</span>
              <span className="text-muted-foreground">· {tz}</span>
            </div>
            {mounted && (
              <Button
                variant="ghost"
                size="icon"
                className="h-9 w-9"
                onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
                aria-label="Сменить тему"
              >
                {theme === "dark" ? (
                  <Sun className="h-4 w-4" />
                ) : (
                  <Moon className="h-4 w-4" />
                )}
              </Button>
            )}
            {mounted && <FontSizeControl />}
            {mounted && <NotificationBell onNavigate={handleBellNavigate} />}
            <Button
              onClick={handleAddLesson}
              size="sm"
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              <Plus className="h-4 w-4" />
              <span className="hidden sm:inline">Занятие</span>
            </Button>
          </div>
        </div>

        {/* Mobile horizontal nav */}
        <div className="border-t md:hidden">
          <div className="flex gap-1 overflow-x-auto px-2 py-1.5">
            {NAV.map((n) => (
              <button
                key={n.id}
                onClick={() => setSection(n.id)}
                className={cn(
                  "flex shrink-0 items-center gap-1.5 rounded-lg px-3 py-1.5 text-sm font-medium transition",
                  section === n.id
                    ? "bg-emerald-600 text-white"
                    : "text-muted-foreground hover:bg-muted"
                )}
              >
                {n.icon}
                {n.label}
              </button>
            ))}
          </div>
        </div>
      </header>

      <div className="mx-auto flex w-full max-w-6xl flex-1 gap-0 px-3 sm:px-4 md:gap-6 md:py-6">
        {/* Sidebar (desktop) */}
        <aside className="sticky top-[3.75rem] hidden h-[calc(100vh-3.75rem-2.5rem)] w-56 shrink-0 py-6 md:block">
          <nav className="grid gap-1">
            {NAV.map((n) => (
              <button
                key={n.id}
                onClick={() => setSection(n.id)}
                className={cn(
                  "flex items-center gap-2.5 rounded-lg px-3 py-2 text-sm font-medium transition",
                  section === n.id
                    ? "bg-emerald-50 text-emerald-700 dark:bg-emerald-500/10 dark:text-emerald-300"
                    : "text-muted-foreground hover:bg-muted hover:text-foreground"
                )}
              >
                {n.icon}
                {n.label}
                {n.id === "payments" && debt > 0 && (
                  <span className="ml-auto rounded-full bg-rose-100 px-1.5 py-0.5 text-[10px] font-semibold text-rose-700 dark:bg-rose-500/20 dark:text-rose-300">
                    {formatMoney(debt)}
                  </span>
                )}
              </button>
            ))}
          </nav>

          <div className="mt-6 rounded-xl border bg-card p-3">
            <p className="flex items-center gap-1.5 text-xs font-medium text-muted-foreground">
              <Sparkles className="h-3.5 w-3.5 text-emerald-500" /> Подсказка
            </p>
            <p className="mt-1 text-xs text-muted-foreground">
              Вставьте расписание текстом в разделе «Расписание» — ассистент
              распознает даты и учеников с помощью ИИ.
            </p>
          </div>
        </aside>

        {/* Main content */}
        <main className="min-w-0 flex-1 py-4 md:py-6">
          {section === "today" && (
            <TodaySection
              onNavigate={(s) => setSection(s as Section)}
              onAddLesson={handleAddLesson}
            />
          )}
          {section === "schedule" && (
            <ScheduleSection addLessonSignal={addLessonSignal} />
          )}
          {section === "payments" && <PaymentsSection />}
          {section === "reports" && <ReportsSection />}
          {section === "students" && <StudentsSection />}
          {section === "settings" && <SettingsSection />}
        </main>
      </div>

      {/* Sticky footer */}
      <footer className="mt-auto border-t bg-background">
        <div className="mx-auto flex max-w-6xl flex-wrap items-center justify-between gap-2 px-3 py-2 sm:px-4">
          <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-muted-foreground">
            <span className="flex items-center gap-1">
              <Clock className="h-3.5 w-3.5" />
              <span className="font-medium tabular-nums text-foreground">
                {clock || "--:--"}
              </span>
              <span>· {tz}</span>
            </span>
            {nextReminder && (
              <span className="hidden items-center gap-1 sm:flex">
                <CalendarDays className="h-3.5 w-3.5 text-emerald-500" />
                Следующее: {nextReminder.lesson.student.name} в{" "}
                {nextReminder.lesson.timeStart}
              </span>
            )}
          </div>
          <div className="flex items-center gap-3 text-xs">
            {debt > 0 ? (
              <span className="flex items-center gap-1 font-medium text-rose-600">
                <AlertTriangle className="h-3.5 w-3.5" />
                Долг: {formatMoney(debt)}
              </span>
            ) : (
              <span className="flex items-center gap-1 font-medium text-emerald-600">
                <Sparkles className="h-3.5 w-3.5" />
                Все оплачено
              </span>
            )}
            <span className="hidden text-muted-foreground sm:inline">
              {weekdayName(dash?.now.date ?? "")}, {formatLongDate(dash?.now.date ?? "")}
            </span>
          </div>
        </div>
      </footer>

      <LessonFormDialog
        open={addOpen}
        onOpenChange={setAddOpen}
        defaultDate={todayInTZ(tz)}
      />
    </div>
  );
}
