"use client";

import {
  Bell,
  BellRing,
  Smartphone,
  Download,
  Check,
  X,
  Send,
  QrCode,
  Copy,
  MessageCircle,
  Loader2,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { cn } from "@/lib/utils";
import { useNotifications } from "@/lib/use-notifications";
import {
  useSettings,
  useUpdateSettings,
} from "@/lib/hooks";
import { toast } from "sonner";
import { useState, useEffect } from "react";
import { api } from "@/lib/api-client";

/** Settings card for all notification channels + PWA install + QR download. */
export function NotificationSettings() {
  const {
    supported,
    permission,
    enabled,
    requestPermission,
    toggleEnabled,
  } = useNotifications();
  const { data: settings } = useSettings();
  const updateMut = useUpdateSettings();

  const [installEvent, setInstallEvent] = useState<any>(null);
  const [installed, setInstalled] = useState(false);
  const [testing, setTesting] = useState(false);
  const [apkDownloading, setApkDownloading] = useState(false);

  // Local editable copies of channel credentials
  const [maxLink, setMaxLink] = useState("");
  const [vkLink, setVkLink] = useState("");
  const [appUrl, setAppUrl] = useState("");

  useEffect(() => {
    if (settings) {
      setMaxLink(settings.maxDirectLink);
      setVkLink(settings.vkDirectLink);
    }
  }, [settings]);

  useEffect(() => {
    setAppUrl(window.location.origin);
  }, []);

  useEffect(() => {
    function onBIP(e: Event) {
      e.preventDefault();
      setInstallEvent(e);
    }
    function onAppInstalled() {
      setInstalled(true);
      setInstallEvent(null);
      toast.success("Приложение установлено");
    }
    window.addEventListener("beforeinstallprompt", onBIP);
    window.addEventListener("appinstalled", onAppInstalled);
    if (window.matchMedia("(display-mode: standalone)").matches) {
      setInstalled(true);
    }
    return () => {
      window.removeEventListener("beforeinstallprompt", onBIP);
      window.removeEventListener("appinstalled", onAppInstalled);
    };
  }, []);

  async function handleInstall() {
    if (!installEvent) {
      toast.info(
        "Чтобы установить: меню браузера (⋮) → «Установить приложение» или отсканируйте QR-код телефоном."
      );
      return;
    }
    installEvent.prompt();
    const choice = await installEvent.userChoice;
    if (choice.outcome === "accepted") setInstalled(true);
    setInstallEvent(null);
  }

  async function handleEnableBrowser() {
    if (permission !== "granted") {
      const result = await requestPermission();
      if (result === "granted") toast.success("Браузерные оповещения включены");
      else if (result === "denied")
        toast.error("Оповещения заблокированы в настройках браузера");
    } else {
      await toggleEnabled(!enabled);
      toast.success(enabled ? "Браузерные оповещения выключены" : "Включены");
    }
  }

  function saveChannel(
    patch: Partial<{
      maxEnabled: boolean;
      maxDirectLink: string;
      vkEnabled: boolean;
      vkDirectLink: string;
    }>
  ) {
    updateMut.mutate(patch, {
      onSuccess: () => toast.success("Настройки канала сохранены"),
      onError: (e) => toast.error(e.message),
    });
  }

  async function handleTest() {
    setTesting(true);
    try {
      const res = await api.post<{ ok: boolean; results: any[] }>(
        "/api/notifications/test"
      );
      const ok = res.results.filter((r: any) => r.ok).length;
      const fail = res.results.filter((r: any) => !r.ok).length;
      if (ok > 0 && fail === 0) {
        // For each successful result, open the share dialog / chat.
        for (const r of res.results.filter((r: any) => r.ok)) {
          if (r.shareUrl && r.text) {
            // Try Web Share API first (mobile) — pre-fills text.
            if (typeof navigator !== "undefined" && "share" in navigator) {
              try {
                await navigator.share({
                  title: r.channel === "max" ? "MAX" : "ВКонтакте",
                  text: r.text,
                });
                continue;
              } catch {
                // user cancelled — fall through to open URL
              }
            }
            // Desktop fallback: copy + open.
            try {
              await navigator.clipboard.writeText(r.text);
            } catch {
              /* ignore */
            }
            window.open(r.shareUrl, "_blank");
          }
        }
        toast.success(
          `Готово — текст скопирован, чат открыт. Вставьте и отправьте.`
        );
      } else if (ok > 0) {
        toast.warning(`Отправлено: ${ok}, ошибок: ${fail}`);
      } else {
        const errs = res.results
          .map((r: any) => `${r.channel}: ${r.error}`)
          .join("; ");
        toast.error(`Не отправлено: ${errs}`);
      }
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setTesting(false);
    }
  }

  function copyLink() {
    navigator.clipboard.writeText(appUrl);
    toast.success("Ссылка скопирована");
  }

  return (
    <div className="grid gap-4">
      {/* PWA install + QR */}
      <div className="rounded-lg border p-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
              <Smartphone className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-medium">Приложение для телефона (Android)</p>
              <p className="text-xs text-muted-foreground">
                {installed
                  ? "Установлено — открывается с иконки на главном экране."
                  : "Отсканируйте QR-код телефоном или установите через Chrome."}
              </p>
            </div>
          </div>
          {!installed && (
            <Button size="sm" variant="outline" onClick={handleInstall}>
              <Download className="mr-1 h-4 w-4" /> Установить
            </Button>
          )}
          {installed && (
            <span className="flex items-center gap-1 text-xs font-medium text-emerald-600">
              <Check className="h-4 w-4" /> Установлено
            </span>
          )}
        </div>
        <div className="mt-3 flex flex-wrap items-center gap-4 rounded-lg bg-muted/40 p-3">
          {appUrl && (
            <img
              src={`/api/qr?url=${encodeURIComponent("/")}`}
              alt="QR-код для установки приложения"
              width={120}
              height={120}
              className="rounded-lg border bg-white"
            />
          )}
          <div className="min-w-0 flex-1">
            <p className="text-xs font-medium text-muted-foreground">
              Ссылка на приложение
            </p>
            <div className="mt-1 flex items-center gap-2">
              <code className="min-w-0 flex-1 truncate rounded bg-background px-2 py-1 text-xs">
                {appUrl}
              </code>
              <Button size="sm" variant="outline" onClick={copyLink}>
                <Copy className="h-3.5 w-3.5" />
              </Button>
            </div>
            <p className="mt-2 text-[11px] text-muted-foreground">
              📱 Откройте эту ссылку в Chrome на телефоне → меню (⋮) → «Установить
              приложение». Браузер и приложение синхронизируются автоматически —
              данные общие.
            </p>
          </div>
        </div>
      </div>

      {/* APK download */}
      <div className="rounded-lg border p-3">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300">
              <Download className="h-5 w-5" />
            </span>
            <div>
              <p className="text-sm font-medium">Скачать APK-файл</p>
              <p className="text-xs text-muted-foreground">
                Готовый установочный файл .apk для Android. Скачивается и
                устанавливается как обычное приложение.
              </p>
            </div>
          </div>
          <Button
            size="sm"
            className="bg-emerald-600 hover:bg-emerald-700"
            disabled={apkDownloading}
            onClick={async () => {
              setApkDownloading(true);
              try {
                const res = await fetch("/api/download/apk");
                if (!res.ok) {
                  const data = await res.json().catch(() => ({}));
                  throw new Error(data?.error || `Ошибка ${res.status}`);
                }
                const blob = await res.blob();
                const url = URL.createObjectURL(blob);
                const a = document.createElement("a");
                a.href = url;
                a.download = "tutor-assistant.apk";
                document.body.appendChild(a);
                a.click();
                a.remove();
                URL.revokeObjectURL(url);
                toast.success("APK скачан — установите его на телефоне");
              } catch (e) {
                toast.error((e as Error).message);
              } finally {
                setApkDownloading(false);
              }
            }}
          >
            {apkDownloading ? (
              <>
                <Loader2 className="mr-1 h-4 w-4 animate-spin" /> Сборка...
              </>
            ) : (
              <>
                <Download className="mr-1 h-4 w-4" /> Скачать APK
              </>
            )}
          </Button>
        </div>
        <div className="mt-3 rounded-lg bg-muted/40 p-3 text-[11px] text-muted-foreground">
          <p>
            📱 Файл <code className="rounded bg-background px-1">tutor-assistant.apk</code> —
            это готовое Android-приложение. Скачайте его на телефон, разрешите
            установку из неизвестных источников и откройте. Иконка «Репетитор»
            появится на главном экране.
          </p>
          <p className="mt-1">
            Первая сборка может занять до 30 секунд (сервер компилирует APK
            специально для вашего адреса). Приложение и браузер используют общий
            сервер — данные синхронизируются автоматически.
          </p>
          <p className="mt-1">
            <b>Альтернатива без скачивания:</b> откройте ссылку приложения в
            Chrome на телефоне → меню (⋮) → «Установить приложение».
          </p>
        </div>
      </div>

      {/* Channel selector */}
      <div>
        <p className="mb-2 text-xs font-medium text-muted-foreground">
          Куда отправлять оповещения
        </p>
        <div className="grid gap-2">
          {/* Browser */}
          <div className="flex items-center justify-between rounded-lg border p-3">
            <div className="flex items-start gap-3">
              <span
                className={cn(
                  "flex h-9 w-9 items-center justify-center rounded-lg",
                  enabled && permission === "granted"
                    ? "bg-emerald-100 text-emerald-700 dark:bg-emerald-500/15 dark:text-emerald-300"
                    : "bg-muted text-muted-foreground"
                )}
              >
                {enabled && permission === "granted" ? (
                  <BellRing className="h-5 w-5" />
                ) : (
                  <Bell className="h-5 w-5" />
                )}
              </span>
              <div>
                <p className="text-sm font-medium">Браузер / приложение</p>
                <p className="text-xs text-muted-foreground">
                  {!supported
                    ? "Не поддерживается."
                    : permission === "denied"
                      ? "Заблокированы в браузере."
                      : permission === "granted"
                        ? enabled
                          ? "Включены."
                          : "Разрешение есть, выключены."
                        : "Нажмите, чтобы разрешить."}
                </p>
              </div>
            </div>
            {supported && (
              <Button
                size="sm"
                variant={permission === "granted" ? "outline" : "default"}
                className={
                  permission === "granted"
                    ? ""
                    : "bg-emerald-600 hover:bg-emerald-700"
                }
                onClick={handleEnableBrowser}
                disabled={permission === "denied"}
              >
                {permission === "denied" ? (
                  <>
                    <X className="mr-1 h-4 w-4" /> Заблокировано
                  </>
                ) : permission === "granted" ? (
                  enabled ? (
                    <>
                      <Check className="mr-1 h-4 w-4" /> Вкл
                    </>
                  ) : (
                    "Включить"
                  )
                ) : (
                  <>
                    <Bell className="mr-1 h-4 w-4" /> Разрешить
                  </>
                )}
              </Button>
            )}
          </div>

          {/* MAX */}
          <div className="rounded-lg border p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-start gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-100 text-amber-700 dark:bg-amber-500/15 dark:text-amber-300">
                  <MessageCircle className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-sm font-medium">MAX (мессенджер)</p>
                  <p className="text-xs text-muted-foreground">
                    Оповещения по прямой ссылке — без бота
                  </p>
                </div>
              </div>
              <Switch
                checked={settings?.maxEnabled ?? false}
                onCheckedChange={(v) => saveChannel({ maxEnabled: v })}
              />
            </div>
            {settings?.maxEnabled && (
              <div className="mt-3 grid gap-2">
                <div className="grid gap-1">
                  <Label htmlFor="max-link" className="text-xs">
                    Ваш номер телефона в MAX
                  </Label>
                  <Input
                    id="max-link"
                    type="tel"
                    placeholder="+7 999 123-45-67"
                    value={maxLink}
                    onChange={(e) => setMaxLink(e.target.value)}
                    onBlur={() => saveChannel({ maxDirectLink: maxLink })}
                  />
                </div>
                <div className="rounded-lg bg-amber-50/60 p-2.5 text-[11px] text-amber-800 dark:bg-amber-500/10 dark:text-amber-300">
                  <p className="font-medium">Как это работает:</p>
                  <p className="mt-1">
                    1) Укажите ваш номер телефона, на который зарегистрирован
                    аккаунт MAX.
                  </p>
                  <p>
                    2) Когда придёт оповещение, в колокольчике появится кнопка
                    «MAX → открыть».
                  </p>
                  <p>
                    3) <b>На телефоне:</b> откроется системный диалог «Поделиться»
                    с готовым текстом — выберите MAX, текст подставится
                    автоматически, нажмите отправить.
                  </p>
                  <p>
                    3) <b>На компьютере:</b> текст скопируется в буфер, откроется
                    чат в MAX — вставьте текст (Ctrl+V) и отправьте.
                  </p>
                  <p className="mt-1 font-medium text-amber-700 dark:text-amber-300">
                    ⚡ Без ботов, без токенов, без webhook.
                  </p>
                </div>
              </div>
            )}
          </div>

          {/* VK */}
          <div className="rounded-lg border p-3">
            <div className="flex items-center justify-between">
              <div className="flex items-start gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-lg bg-sky-100 text-sky-700 dark:bg-sky-500/15 dark:text-sky-300">
                  <MessageCircle className="h-5 w-5" />
                </span>
                <div>
                  <p className="text-sm font-medium">ВКонтакте</p>
                  <p className="text-xs text-muted-foreground">
                    Оповещения по прямой ссылке — без токена
                  </p>
                </div>
              </div>
              <Switch
                checked={settings?.vkEnabled ?? false}
                onCheckedChange={(v) => saveChannel({ vkEnabled: v })}
              />
            </div>
            {settings?.vkEnabled && (
              <div className="mt-3 grid gap-2">
                <div className="grid gap-1">
                  <Label htmlFor="vk-link" className="text-xs">
                    Прямая ссылка на ваш диалог ВКонтакте
                  </Label>
                  <Input
                    id="vk-link"
                    placeholder="https://vk.com/im?sel=12345 или https://vk.me/id12345"
                    value={vkLink}
                    onChange={(e) => setVkLink(e.target.value)}
                    onBlur={() => saveChannel({ vkDirectLink: vkLink })}
                  />
                </div>
                <div className="rounded-lg bg-sky-50/60 p-2.5 text-[11px] text-sky-800 dark:bg-sky-500/10 dark:text-sky-300">
                  <p className="font-medium">Как это работает:</p>
                  <p className="mt-1">
                    1) Укажите ссылку на ваш диалог ВК (например{" "}
                    <code>vk.me/ваш_id</code>).
                  </p>
                  <p>
                    2) Когда придёт оповещение, в колокольчике появится кнопка
                    «ВК → открыть».
                  </p>
                  <p>
                    3) <b>На телефоне:</b> откроется системный диалог «Поделиться»
                    с готовым текстом — выберите ВКонтакте, текст подставится
                    автоматически, нажмите отправить.
                  </p>
                  <p>
                    3) <b>На компьютере:</b> текст скопируется в буфер, откроется
                    диалог ВК — вставьте текст (Ctrl+V) и отправьте.
                  </p>
                  <p className="mt-1 font-medium text-sky-700 dark:text-sky-300">
                    ⚡ Без токенов, без сообществ, без API.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Test button */}
      <Button
        variant="outline"
        onClick={handleTest}
        disabled={testing || (!settings?.maxEnabled && !settings?.vkEnabled)}
      >
        <Send className="mr-1 h-4 w-4" />
        {testing ? "Отправка..." : "Отправить тестовое оповещение"}
      </Button>
      {(!settings?.maxEnabled && !settings?.vkEnabled) && (
        <p className="text-xs text-muted-foreground">
          Включите MAX или ВКонтакте, чтобы отправить тест.
        </p>
      )}
    </div>
  );
}
