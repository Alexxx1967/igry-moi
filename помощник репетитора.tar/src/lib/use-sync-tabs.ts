"use client";

import { useEffect } from "react";
import { useQueryClient } from "@tanstack/react-query";

const CHANNEL_NAME = "ta:sync";

/**
 * Cross-tab / cross-context synchronization. When the user changes something
 * in the browser tab OR the installed PWA, both share the same origin, so a
 * BroadcastChannel lets us tell every other open instance to refresh its data.
 *
 * Also triggers a refetch when the tab/window regains focus (covers the case
 * where the user switches between the browser and the PWA app).
 */
export function useSyncTabs() {
  const qc = useQueryClient();

  useEffect(() => {
    let channel: BroadcastChannel | null = null;
    try {
      channel = new BroadcastChannel(CHANNEL_NAME);
    } catch {
      // BroadcastChannel not supported (older browsers) — fall back to focus sync only.
    }

    function onMessage(e: MessageEvent) {
      if (e.data?.type === "INVALIDATE") {
        qc.invalidateQueries({ queryKey: e.data.keys });
      } else if (e.data?.type === "REFRESH_ALL") {
        qc.invalidateQueries();
      }
    }

    if (channel) {
      channel.addEventListener("message", onMessage);
    }

    // Refetch everything when the window/tab gains focus (browser↔PWA switch).
    function onFocus() {
      qc.invalidateQueries();
    }
    function onVisibility() {
      if (document.visibilityState === "visible") {
        qc.invalidateQueries();
      }
    }
    window.addEventListener("focus", onFocus);
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      if (channel) {
        channel.removeEventListener("message", onMessage);
        channel.close();
      }
      window.removeEventListener("focus", onFocus);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [qc]);
}

/** Broadcast an invalidation to all other open instances (browser + PWA). */
export function broadcastInvalidate(keys?: readonly unknown[]) {
  try {
    const channel = new BroadcastChannel(CHANNEL_NAME);
    if (keys) {
      channel.postMessage({ type: "INVALIDATE", keys: Array.from(keys) });
    } else {
      channel.postMessage({ type: "REFRESH_ALL" });
    }
    channel.close();
  } catch {
    /* ignore */
  }
}
