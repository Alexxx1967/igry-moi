import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

const VALID_LESSON = [
  "planned",
  "conducted",
  "cancelled",
  "rescheduled",
  "no_show",
];
const VALID_PAYMENT = [
  "paid",
  "unpaid",
  "partial",
  "awaiting_confirmation",
  "refund",
  "free_trial",
];

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const lesson = await db.lesson.findUnique({
    where: { id },
    include: { student: true },
  });
  if (!lesson) return NextResponse.json({ error: "Не найдено" }, { status: 404 });
  return NextResponse.json(lesson);
}

export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json();
  const existing = await db.lesson.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Не найдено" }, { status: 404 });

  const data: any = {};
  if (body.date !== undefined) data.date = body.date;
  if (body.timeStart !== undefined) data.timeStart = body.timeStart;
  if (body.durationMinutes !== undefined)
    data.durationMinutes = Number(body.durationMinutes) || 60;
  if (body.studentId !== undefined) data.studentId = body.studentId;
  if (body.subject !== undefined) data.subject = body.subject;
  if (body.format !== undefined)
    data.format = body.format === "offline" ? "offline" : "online";
  if (body.link !== undefined) data.link = body.link || null;
  if (body.comment !== undefined) data.comment = body.comment || null;

  if (body.price !== undefined) {
    const priceNum = Number(body.price) || 0;
    data.price = priceNum;
    // if already paid fully, keep paidAmount == price
    if (existing.paymentStatus === "paid") data.paidAmount = priceNum;
  }

  if (body.lessonStatus !== undefined && VALID_LESSON.includes(body.lessonStatus)) {
    data.lessonStatus = body.lessonStatus;
  }
  if (body.paymentStatus !== undefined && VALID_PAYMENT.includes(body.paymentStatus)) {
    const ps = body.paymentStatus;
    data.paymentStatus = ps;
    const price = body.price !== undefined ? Number(body.price) || 0 : existing.price;
    if (ps === "paid") data.paidAmount = price;
    else if (ps === "free_trial" || ps === "refund") data.paidAmount = 0;
    else if (ps === "unpaid") data.paidAmount = 0;
    else if (ps === "partial") {
      data.paidAmount =
        body.paidAmount !== undefined ? Number(body.paidAmount) || 0 : existing.paidAmount;
    }
  }
  if (body.paidAmount !== undefined && body.paymentStatus === undefined) {
    data.paidAmount = Number(body.paidAmount) || 0;
    // auto-adjust status if full paid
    if (data.paidAmount >= existing.price) data.paymentStatus = "paid";
    else if (data.paidAmount > 0) data.paymentStatus = "partial";
    else data.paymentStatus = "unpaid";
  }

  const updated = await db.lesson.update({
    where: { id },
    data,
    include: { student: true },
  });
  return NextResponse.json(updated);
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  await db.lesson.delete({ where: { id } }).catch(() => {});
  return NextResponse.json({ ok: true });
}
