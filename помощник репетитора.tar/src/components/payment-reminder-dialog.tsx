"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Loader2, Sparkles, Copy, Check } from "lucide-react";
import { api } from "@/lib/api-client";
import { buildStudentPaymentReminder } from "@/lib/reminders";
import { useSettings } from "@/lib/hooks";
import type { LessonWithStudent } from "@/lib/types";
import { formatMoney } from "@/lib/tz";
import { StudentAvatar } from "@/components/status-badges";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  lesson: LessonWithStudent | null;
};

export function PaymentReminderDialog({ open, onOpenChange, lesson }: Props) {
  const [text, setText] = useState("");
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const { data: settings } = useSettings();

  useEffect(() => {
    if (!open || !lesson) return;
    setText("");
    setCopied(false);
    // Provide an instant template, then refine with AI
    setText(buildStudentPaymentReminder(lesson, settings?.tutorName ?? ""));
  }, [open, lesson, settings]);

  async function handleGenerate() {
    if (!lesson) return;
    setLoading(true);
    try {
      const res = await api.post<{ text: string }>("/api/reminder", {
        lessonId: lesson.id,
      });
      setText(res.text);
      toast.success("Текст обновлён с помощью ИИ");
    } catch (e) {
      toast.error((e as Error).message);
    } finally {
      setLoading(false);
    }
  }

  function handleCopy() {
    navigator.clipboard.writeText(text);
    setCopied(true);
    toast.success("Скопировано в буфер обмена");
    setTimeout(() => setCopied(false), 2000);
  }

  if (!lesson) return null;
  const debt = Math.max(0, lesson.price - lesson.paidAmount);

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[520px]">
        <DialogHeader>
          <DialogTitle>Напоминание об оплате</DialogTitle>
          <DialogDescription>
            Мягкое вежливое сообщение ученику. Можно отредактировать перед отправкой.
          </DialogDescription>
        </DialogHeader>

        <div className="flex items-center gap-3 rounded-lg border bg-muted/30 p-3">
          <StudentAvatar name={lesson.student.name} color={lesson.student.color} />
          <div className="min-w-0 flex-1">
            <p className="truncate font-medium">{lesson.student.name}</p>
            <p className="text-sm text-muted-foreground">
              {lesson.date} в {lesson.timeStart} · {lesson.subject}
            </p>
          </div>
          <div className="text-right">
            <p className="text-xs text-muted-foreground">Долг</p>
            <p className="font-semibold text-rose-600">{formatMoney(debt)}</p>
          </div>
        </div>

        <Textarea
          rows={7}
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="resize-none"
        />

        <DialogFooter className="flex-col gap-2 sm:flex-row sm:justify-between">
          <Button
            variant="outline"
            size="sm"
            onClick={handleGenerate}
            disabled={loading}
          >
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" /> Генерация...
              </>
            ) : (
              <>
                <Sparkles className="mr-2 h-4 w-4 text-emerald-600" /> Улучшить через ИИ
              </>
            )}
          </Button>
          <div className="flex gap-2">
            <Button variant="ghost" onClick={() => onOpenChange(false)}>
              Закрыть
            </Button>
            <Button onClick={handleCopy}>
              {copied ? (
                <>
                  <Check className="mr-2 h-4 w-4" /> Скопировано
                </>
              ) : (
                <>
                  <Copy className="mr-2 h-4 w-4" /> Копировать
                </>
              )}
            </Button>
          </div>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
