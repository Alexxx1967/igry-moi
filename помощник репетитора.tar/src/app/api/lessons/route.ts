import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSettings } from "@/lib/report";
import { todayInTZ } from "@/lib/tz";

// GET /api/lessons?date=YYYY-MM-DD | ?from=...&to=... | ?scope=today|upcoming|unpaid
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const date = searchParams.get("date");
  const from = searchParams.get("from");
  const to = searchParams.get("to");
  const scope = searchParams.get("scope");

  const settings = await getSettings();
  const tz = settings.timezone;

  let where: any = {};

  if (date) {
    where.date = date;
  } else if (from && to) {
    where.date = { gte: from, lte: to };
  } else if (scope === "today") {
    where.date = todayInTZ(tz);
  } else if (scope === "upcoming") {
    where.date = { gte: todayInTZ(tz) };
  } else if (scope === "unpaid") {
    where.AND = [
      { lessonStatus: "conducted" },
      { OR: [{ paymentStatus: "unpaid" }, { paymentStatus: "partial" }] },
    ];
  }

  const rows = await db.lesson.findMany({
    where,
    include: { student: true },
    orderBy: [{ date: "asc" }, { timeStart: "asc" }],
  });

  return NextResponse.json(rows);
}

const VALID_LESSON = [
  "planned",
  "conducted",
  "cancelled",
  "rescheduled",
  "no_show",
];
const VALID_PAYMENT = [
  "paid",
  "unpaid",
  "partial",
  "awaiting_confirmation",
  "refund",
  "free_trial",
];

export async function POST(req: NextRequest) {
  const body = await req.json();
  const {
    date,
    timeStart,
    durationMinutes,
    studentId,
    studentName,
    subject,
    format,
    link,
    price,
    paidAmount,
    lessonStatus,
    paymentStatus,
    recurring,
    comment,
  } = body;

  if (!date || !timeStart || !subject) {
    return NextResponse.json(
      { error: "Не указаны обязательные поля (date, timeStart, subject)" },
      { status: 400 }
    );
  }

  let finalStudentId = studentId;
  if (!finalStudentId && studentName) {
    // create student on the fly
    const created = await db.student.create({
      data: { name: String(studentName).trim() },
    });
    finalStudentId = created.id;
  }
  if (!finalStudentId) {
    return NextResponse.json({ error: "Укажите ученика" }, { status: 400 });
  }

  const ls = VALID_LESSON.includes(lessonStatus) ? lessonStatus : "planned";
  const ps = VALID_PAYMENT.includes(paymentStatus) ? paymentStatus : "unpaid";
  // If no price provided, try to inherit from the student's pricePerLesson
  let priceNum = Number(price) || 0;
  if (!priceNum) {
    const student = await db.student.findUnique({
      where: { id: finalStudentId },
      select: { pricePerLesson: true },
    });
    if (student?.pricePerLesson) priceNum = student.pricePerLesson;
  }
  const paidNum =
    ps === "paid"
      ? priceNum
      : ps === "free_trial" || ps === "refund"
        ? 0
        : Number(paidAmount) || 0;

  const created = await db.lesson.create({
    data: {
      date,
      timeStart,
      durationMinutes: Number(durationMinutes) || 60,
      studentId: finalStudentId,
      subject,
      format: format === "offline" ? "offline" : "online",
      link: link || null,
      price: priceNum,
      paidAmount: paidNum,
      lessonStatus: ls,
      paymentStatus: ps,
      recurring: recurring || null,
      comment: comment || null,
    },
    include: { student: true },
  });

  return NextResponse.json(created, { status: 201 });
}
