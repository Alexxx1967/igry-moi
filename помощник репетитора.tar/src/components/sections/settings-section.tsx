"use client";

import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Switch } from "@/components/ui/switch";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import {
  Loader2,
  Save,
  RefreshCw,
  Database,
  Settings2,
  Landmark,
  BellRing,
} from "lucide-react";
import { NotificationSettings } from "@/components/notification-settings";
import {
  useSettings,
  useUpdateSettings,
  useSeed,
} from "@/lib/hooks";
import {
  TIMEZONES,
  WEEKDAYS_RU,
} from "@/lib/constants";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export function SettingsSection() {
  const { data: settings, isLoading } = useSettings();
  const updateMut = useUpdateSettings();
  const seedMut = useSeed();
  const [seedOpen, setSeedOpen] = useState(false);

  const [form, setForm] = useState<{
    timezone: string;
    dailyReportTime: string;
    weeklyReportDay: string;
    weeklyReportTime: string;
    monthlyReportTime: string;
    reminder30min: boolean;
    reminder1h: boolean;
    reminder15min: boolean;
    autoReminderToStudent: boolean;
    taxReminderEnabled: boolean;
    taxReminderTime: string;
    tutorName: string;
  } | null>(null);

  useEffect(() => {
    if (settings) {
      setForm({
        timezone: settings.timezone,
        dailyReportTime: settings.dailyReportTime,
        weeklyReportDay: settings.weeklyReportDay,
        weeklyReportTime: settings.weeklyReportTime,
        monthlyReportTime: settings.monthlyReportTime,
        reminder30min: settings.reminder30min,
        reminder1h: settings.reminder1h,
        reminder15min: settings.reminder15min,
        autoReminderToStudent: settings.autoReminderToStudent,
        taxReminderEnabled: settings.taxReminderEnabled,
        taxReminderTime: settings.taxReminderTime,
        tutorName: settings.tutorName,
      });
    }
  }, [settings]);

  if (isLoading || !form) {
    return (
      <div className="grid gap-3">
        <div className="h-10 w-full animate-pulse rounded bg-muted" />
        <div className="h-64 w-full animate-pulse rounded bg-muted" />
      </div>
    );
  }

  function save() {
    updateMut.mutate(form!, {
      onSuccess: () => toast.success("Настройки сохранены"),
      onError: (e) => toast.error(e.message),
    });
  }

  const dirty =
    JSON.stringify(form) !==
    JSON.stringify({
      timezone: settings!.timezone,
      dailyReportTime: settings!.dailyReportTime,
      weeklyReportDay: settings!.weeklyReportDay,
      weeklyReportTime: settings!.weeklyReportTime,
      monthlyReportTime: settings!.monthlyReportTime,
      reminder30min: settings!.reminder30min,
      reminder1h: settings!.reminder1h,
      reminder15min: settings!.reminder15min,
      autoReminderToStudent: settings!.autoReminderToStudent,
      taxReminderEnabled: settings!.taxReminderEnabled,
      taxReminderTime: settings!.taxReminderTime,
      tutorName: settings!.tutorName,
    });

  return (
    <div className="grid gap-5">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Настройки</h1>
        <p className="text-sm text-muted-foreground">
          Часовой пояс, время отчётов и параметры напоминаний.
        </p>
      </div>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Settings2 className="h-4 w-4" /> Основные
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4">
          <div className="grid gap-1.5">
            <Label>Часовой пояс</Label>
            <Select
              value={form.timezone}
              onValueChange={(v) => setForm({ ...form, timezone: v })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {TIMEZONES.map((tz) => (
                  <SelectItem key={tz.value} value={tz.value}>
                    {tz.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="text-xs text-muted-foreground">
              Все напоминания и отчёты считаются в этом поясе.
            </p>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="tutor-name">Имя репетитора (для подписи в напоминаниях)</Label>
            <Input
              id="tutor-name"
              placeholder="Напр. Елена"
              value={form.tutorName}
              onChange={(e) => setForm({ ...form, tutorName: e.target.value })}
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <BellRing className="h-4 w-4" /> Оповещения и приложение
          </CardTitle>
        </CardHeader>
        <CardContent>
          <NotificationSettings />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Напоминания о занятиях</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3">
          <ToggleRow
            label="За 30 минут"
            hint="Предварительное напоминание"
            checked={form.reminder30min}
            onCheckedChange={(v) => setForm({ ...form, reminder30min: v })}
          />
          <ToggleRow
            label="За 1 час"
            hint="Основное напоминание"
            checked={form.reminder1h}
            onCheckedChange={(v) => setForm({ ...form, reminder1h: v })}
          />
          <ToggleRow
            label="За 15 минут"
            hint="Срочное напоминание"
            checked={form.reminder15min}
            onCheckedChange={(v) => setForm({ ...form, reminder15min: v })}
          />
          <ToggleRow
            label="Авто-напоминания ученикам об оплате"
            hint="По умолчанию только предлагать текст напоминания"
            checked={form.autoReminderToStudent}
            onCheckedChange={(v) => setForm({ ...form, autoReminderToStudent: v })}
          />
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-base">Отчёты</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="grid gap-1.5">
            <Label htmlFor="daily-time">Время ежедневного отчёта</Label>
            <Input
              id="daily-time"
              type="time"
              value={form.dailyReportTime}
              onChange={(e) =>
                setForm({ ...form, dailyReportTime: e.target.value })
              }
            />
          </div>
          <div className="grid gap-1.5">
            <Label>День еженедельного отчёта</Label>
            <Select
              value={form.weeklyReportDay}
              onValueChange={(v) => setForm({ ...form, weeklyReportDay: v })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {WEEKDAYS_RU.map((d, i) => (
                  <SelectItem key={i} value={String((i + 1) % 7)}>
                    {d}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="weekly-time">Время еженедельного отчёта</Label>
            <Input
              id="weekly-time"
              type="time"
              value={form.weeklyReportTime}
              onChange={(e) =>
                setForm({ ...form, weeklyReportTime: e.target.value })
              }
            />
          </div>
          <div className="grid gap-1.5">
            <Label htmlFor="monthly-time">
              Время ежемесячного отчёта
              <span className="ml-1 text-xs font-normal text-muted-foreground">
                (в последний день месяца)
              </span>
            </Label>
            <Input
              id="monthly-time"
              type="time"
              value={form.monthlyReportTime}
              onChange={(e) =>
                setForm({ ...form, monthlyReportTime: e.target.value })
              }
            />
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Landmark className="h-4 w-4" /> Налоговая
          </CardTitle>
        </CardHeader>
        <CardContent className="grid gap-3">
          <ToggleRow
            label="Ежедневное напоминание о подаче данных в налоговую"
            hint="Появляется каждый день в указанное время"
            checked={form.taxReminderEnabled}
            onCheckedChange={(v) => setForm({ ...form, taxReminderEnabled: v })}
          />
          <div className="grid gap-1.5">
            <Label htmlFor="tax-time">Время напоминания о налоговой</Label>
            <Input
              id="tax-time"
              type="time"
              value={form.taxReminderTime}
              disabled={!form.taxReminderEnabled}
              onChange={(e) =>
                setForm({ ...form, taxReminderTime: e.target.value })
              }
            />
          </div>
        </CardContent>
      </Card>

      <div className="flex flex-wrap items-center justify-between gap-3">
        <Button variant="outline" onClick={() => setSeedOpen(true)}>
          <Database className="mr-1 h-4 w-4" /> Демо-данные
        </Button>
        <Button
          onClick={save}
          disabled={!dirty || updateMut.isPending}
          className="bg-emerald-600 hover:bg-emerald-700"
        >
          {updateMut.isPending ? (
            <Loader2 className="mr-1 h-4 w-4 animate-spin" />
          ) : (
            <Save className="mr-1 h-4 w-4" />
          )}
          Сохранить
        </Button>
      </div>

      <Dialog open={seedOpen} onOpenChange={setSeedOpen}>
        <DialogContent className="sm:max-w-[420px]">
          <DialogHeader>
            <DialogTitle>Загрузить демо-данные?</DialogTitle>
            <DialogDescription>
              Это удалит все текущие занятия и учеников и заполнит базу
              демонстрационными данными (6 учеников, занятия за неделю до и после
              сегодня). Полезно для знакомства с ассистентом.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setSeedOpen(false)}>
              Отмена
            </Button>
            <Button
              variant="destructive"
              disabled={seedMut.isPending}
              onClick={() => {
                seedMut.mutate(undefined, {
                  onSuccess: () => {
                    toast.success("Демо-данные загружены");
                    setSeedOpen(false);
                  },
                  onError: (e) => toast.error(e.message),
                });
              }}
            >
              {seedMut.isPending ? (
                <Loader2 className="mr-1 h-4 w-4 animate-spin" />
              ) : (
                <RefreshCw className="mr-1 h-4 w-4" />
              )}
              Загрузить
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ToggleRow({
  label,
  hint,
  checked,
  onCheckedChange,
}: {
  label: string;
  hint?: string;
  checked: boolean;
  onCheckedChange: (v: boolean) => void;
}) {
  return (
    <div className="flex items-center justify-between rounded-lg border p-3">
      <div>
        <p className="text-sm font-medium">{label}</p>
        {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
      </div>
      <Switch checked={checked} onCheckedChange={onCheckedChange} />
    </div>
  );
}
