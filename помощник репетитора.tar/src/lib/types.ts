// Shared types used across client and server

export type LessonWithStudent = {
  id: string;
  date: string;
  timeStart: string;
  durationMinutes: number;
  studentId: string;
  student: { id: string; name: string; color: string; phone: string | null };
  subject: string;
  format: string;
  link: string | null;
  price: number;
  paidAmount: number;
  lessonStatus: string;
  paymentStatus: string;
  recurring: string | null;
  comment: string | null;
  createdAt: string;
  updatedAt: string;
};

export type StudentWithStats = {
  id: string;
  name: string;
  phone: string | null;
  email: string | null;
  grade: string | null;
  pricePerLesson: number | null;
  comment: string | null;
  color: string;
  createdAt: string;
  _count: { lessons: number };
  totalLessons: number;
  conductedLessons: number;
  unpaidLessons: number;
  debt: number;
  // Current-month prepayment info
  monthPrepaid: MonthlyPaymentInfo | null;
  // Carried-over balance from past months' prepayments (unused lessons' money)
  prepaymentBalance: PrepaymentBalanceItem[];
  prepaymentBalanceTotal: number;
};

export type PrepaymentBalanceItem = {
  month: string; // YYYY-MM
  monthLabel: string;
  lessonsCount: number;
  conducted: number;
  unusedLessons: number;
  perLessonPrice: number;
  amount: number; // unused money from this month
};

export type MonthlyPaymentInfo = {
  id: string;
  month: string; // YYYY-MM
  lessonsCount: number;
  amount: number;
  paid: boolean;
  paidAt: string | null;
  comment: string | null;
  // Computed for the month
  conductedThisMonth: number;
  remaining: number; // lessonsCount - conductedThisMonth
  plannedThisMonth: number;
};

export type MonthlyPayment = {
  id: string;
  studentId: string;
  student: { id: string; name: string; color: string };
  month: string;
  lessonsCount: number;
  amount: number;
  paid: boolean;
  paidAt: string | null;
  comment: string | null;
  createdAt: string;
  updatedAt: string;
};

export type Settings = {
  timezone: string;
  dailyReportTime: string;
  weeklyReportDay: string;
  weeklyReportTime: string;
  monthlyReportTime: string;
  reminder30min: boolean;
  reminder1h: boolean;
  reminder15min: boolean;
  autoReminderToStudent: boolean;
  taxReminderTime: string;
  taxReminderLastDone: string; // YYYY-MM-DD
  taxReminderEnabled: boolean;
  // Notification channels
  browserNotifEnabled: boolean;
  maxEnabled: boolean;
  maxDirectLink: string; // прямая ссылка на чат MAX
  maxBotToken: string; // legacy
  maxPhone: string;
  maxChatId: string;
  vkEnabled: boolean;
  vkDirectLink: string; // прямая ссылка на чат ВК
  vkAccessToken: string; // legacy
  vkPeerId: string; // legacy
  tutorName: string;
};

export type NotifChannel = "browser" | "max" | "vk";

export type TaxReminderStatus = {
  enabled: boolean;
  time: string;
  lastDone: string | null; // YYYY-MM-DD
  todayDone: boolean;
  due: boolean; // reminder should show now (current time >= reminder time and not done today)
};

export type DailyReport = {
  date: string;
  total: number;
  conducted: number;
  cancelled: number;
  rescheduled: number;
  planned: number;
  noShow: number;
  paid: number;
  unpaid: number;
  expectedTotal: number;
  receivedTotal: number;
  debtTotal: number;
  lessons: LessonWithStudent[];
  debtors: { studentName: string; date: string; amount: number; lessonId: string }[];
  tomorrow: { time: string; studentName: string; subject: string; format: string }[];
  text: string;
};

export type WeeklyReport = {
  startDate: string;
  endDate: string;
  total: number;
  conducted: number;
  cancelled: number;
  rescheduled: number;
  planned: number;
  noShow: number;
  paid: number;
  unpaid: number;
  receivedTotal: number;
  expectedTotal: number;
  debtTotal: number;
  byDay: { day: string; count: number; conducted: number }[];
  debtors: {
    studentName: string;
    lessonsCount: number;
    amount: number;
  }[];
  byStudent: {
    studentName: string;
    color: string;
    total: number;
    conducted: number;
    revenue: number;
    debt: number;
  }[];
  text: string;
};

export type MonthlyReport = {
  month: string; // YYYY-MM
  monthLabel: string; // "Сентябрь 2026"
  startDate: string;
  endDate: string;
  total: number;
  conducted: number;
  cancelled: number;
  rescheduled: number;
  planned: number;
  noShow: number;
  paid: number;
  unpaid: number;
  receivedTotal: number; // per-lesson payments
  expectedTotal: number;
  debtTotal: number;
  prepaymentTotal: number; // sum of monthly prepayments received
  grandReceived: number; // receivedTotal + prepaymentTotal
  carryoverBalanceTotal: number; // unused prepayment money from previous months
  byWeek: { label: string; count: number; conducted: number }[];
  debtors: {
    studentName: string;
    lessonsCount: number;
    amount: number;
  }[];
  byStudent: {
    studentName: string;
    color: string;
    total: number;
    conducted: number;
    revenue: number;
    debt: number;
    prepaid: MonthlyPaymentInfo | null;
    carryoverBalance: number; // unused money from past months
  }[];
  prepayments: MonthlyPayment[];
  text: string;
};

export type YearlyReport = {
  year: number;
  total: number;
  conducted: number;
  cancelled: number;
  rescheduled: number;
  planned: number;
  noShow: number;
  paid: number;
  unpaid: number;
  receivedTotal: number;
  prepaymentTotal: number;
  grandReceived: number;
  debtTotal: number;
  byMonth: { month: string; label: string; count: number; conducted: number; revenue: number }[];
  byStudent: {
    studentName: string;
    color: string;
    total: number;
    conducted: number;
    revenue: number;
    debt: number;
  }[];
  text: string;
};

export type StudentReport = {
  student: {
    id: string;
    name: string;
    color: string;
    phone: string | null;
    email: string | null;
    grade: string | null;
    pricePerLesson: number | null;
    comment: string | null;
  };
  startDate: string;
  endDate: string;
  total: number;
  conducted: number;
  cancelled: number;
  rescheduled: number;
  planned: number;
  noShow: number;
  paid: number;
  unpaid: number;
  expectedTotal: number;
  receivedTotal: number;
  debtTotal: number;
  prepaymentTotal: number;
  grandReceived: number;
  lessons: LessonWithStudent[];
  prepayments: MonthlyPayment[];
  carryoverBalanceTotal: number;
  text: string;
};
