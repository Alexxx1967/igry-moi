"use client";

import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { api } from "@/lib/api-client";
import { broadcastInvalidate } from "@/lib/use-sync-tabs";
import type {
  LessonWithStudent,
  MonthlyPayment,
  MonthlyReport,
  Settings,
  StudentReport,
  StudentWithStats,
  TaxReminderStatus,
  WeeklyReport,
  YearlyReport,
} from "@/lib/types";

// Query keys
export const qk = {
  dashboard: ["dashboard"] as const,
  lessons: (params: Record<string, string | undefined>) =>
    ["lessons", params] as const,
  students: ["students"] as const,
  settings: ["settings"] as const,
  daily: (date: string) => ["daily", date] as const,
  weekly: (date: string) => ["weekly", date] as const,
  monthly: (date: string) => ["monthly", date] as const,
  yearly: (year: number) => ["yearly", year] as const,
  monthlyPayments: (month: string) => ["monthlyPayments", month] as const,
  taxReminder: ["taxReminder"] as const,
};

export type DashboardData = {
  today: LessonWithStudent[];
  reminders: { lesson: LessonWithStudent; minutes: number; tier: string }[];
  debtors: {
    id: string;
    date: string;
    timeStart: string;
    student: { id: string; name: string; color: string; phone: string | null };
    subject: string;
    price: number;
    paidAmount: number;
    debt: number;
    paymentStatus: string;
  }[];
  debtTotal: number;
  now: { date: string; time: string; weekday: number };
  todayStats: {
    total: number;
    conducted: number;
    planned: number;
    cancelled: number;
  };
  taxReminder?: TaxReminderStatus;
};

export function useDashboard() {
  return useQuery({
    queryKey: qk.dashboard,
    queryFn: () => api.get<DashboardData>("/api/dashboard"),
    refetchInterval: 60_000,
  });
}

export function useLessons(params: Record<string, string | undefined>) {
  const url = "/api/lessons?" + new URLSearchParams(
    Object.entries(params).filter(([, v]) => v) as [string, string][]
  ).toString();
  return useQuery({
    queryKey: qk.lessons(params),
    queryFn: () => api.get<LessonWithStudent[]>(url),
  });
}

export function useStudents() {
  return useQuery({
    queryKey: qk.students,
    queryFn: () => api.get<StudentWithStats[]>("/api/students"),
  });
}

export function useSettings() {
  return useQuery({
    queryKey: qk.settings,
    queryFn: () => api.get<Settings>("/api/settings"),
  });
}

// Mutations
export function useCreateLesson() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) =>
      api.post<LessonWithStudent>("/api/lessons", body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["lessons"] });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      qc.invalidateQueries({ queryKey: qk.students });
      qc.invalidateQueries({ queryKey: ["daily"] });
      qc.invalidateQueries({ queryKey: ["weekly"] });
      broadcastInvalidate();
    },
  });
}

export function useUpdateLesson() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({ id, body }: { id: string; body: Record<string, unknown> }) =>
      api.patch<LessonWithStudent>(`/api/lessons/${id}`, body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["lessons"] });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      qc.invalidateQueries({ queryKey: qk.students });
      qc.invalidateQueries({ queryKey: ["daily"] });
      qc.invalidateQueries({ queryKey: ["weekly"] });
      broadcastInvalidate();
    },
  });
}

export function useDeleteLesson() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.del(`/api/lessons/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["lessons"] });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      qc.invalidateQueries({ queryKey: qk.students });
      qc.invalidateQueries({ queryKey: ["daily"] });
      qc.invalidateQueries({ queryKey: ["weekly"] });
      broadcastInvalidate();
    },
  });
}

export function useUpdatePayment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      body,
    }: {
      id: string;
      body: { paymentStatus?: string; paidAmount?: number };
    }) => api.patch(`/api/payments/${id}`, body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["lessons"] });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      qc.invalidateQueries({ queryKey: qk.students });
      qc.invalidateQueries({ queryKey: ["daily"] });
      qc.invalidateQueries({ queryKey: ["weekly"] });
      broadcastInvalidate();
    },
  });
}

export function useCreateStudent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Record<string, unknown>) =>
      api.post<StudentWithStats>("/api/students", body),
    onSuccess: () => qc.invalidateQueries({ queryKey: qk.students }),
  });
}

export function useUpdateStudent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: ({
      id,
      body,
    }: {
      id: string;
      body: Record<string, unknown>;
    }) => api.patch(`/api/students/${id}`, body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.students });
      qc.invalidateQueries({ queryKey: ["lessons"] });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      broadcastInvalidate();
    },
  });
}

export function useDeleteStudent() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.del(`/api/students/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.students });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      qc.invalidateQueries({ queryKey: ["lessons"] });
      broadcastInvalidate();
    },
  });
}

export function useDeleteAllStudents() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () =>
      api.del<{ ok: boolean; deleted: { students: number; lessons: number; monthlyPayments: number } }>(
        "/api/students/all"
      ),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.students });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      qc.invalidateQueries({ queryKey: ["lessons"] });
      broadcastInvalidate();
    },
  });
}

export function useUpdateSettings() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: Partial<Settings>) => api.put<Settings>("/api/settings", body),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.settings });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      broadcastInvalidate();
    },
  });
}

export function useSeed() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => api.post<{ ok: boolean }>("/api/seed"),
    onSuccess: () => {
      qc.invalidateQueries();
      broadcastInvalidate();
    },
  });
}

// ---- Word upload ----

export type ParsedStudent = {
  name: string | null;
  phone: string | null;
  email: string | null;
  grade: string | null;
  comment: string | null;
};

export function useUploadDocxSchedule() {
  return useMutation({
    mutationFn: async (file: File) => {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload/docx-schedule", {
        method: "POST",
        body: fd,
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data?.error || `Ошибка ${res.status}`);
      }
      return (await res.json()) as {
        lessons: import("@/lib/llm").ParsedLesson[];
        textPreview: string;
      };
    },
  });
}

export function useUploadDocxStudents() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: async (file: File) => {
      const fd = new FormData();
      fd.append("file", file);
      const res = await fetch("/api/upload/docx-students", {
        method: "POST",
        body: fd,
      });
      if (!res.ok) {
        const data = await res.json().catch(() => ({}));
        throw new Error(data?.error || `Ошибка ${res.status}`);
      }
      return (await res.json()) as {
        students: ParsedStudent[];
        textPreview: string;
      };
    },
    onSuccess: () => qc.invalidateQueries({ queryKey: qk.students }),
  });
}

// ---- Word download helper ----

export function downloadReportDocx(
  url: string,
  fallbackName = "report.docx"
) {
  return fetch(url)
    .then((res) => {
      if (!res.ok) throw new Error(`Ошибка ${res.status}`);
      return res.blob();
    })
    .then((blob) => {
      const a = document.createElement("a");
      const objectUrl = URL.createObjectURL(blob);
      a.href = objectUrl;
      a.download = fallbackName;
      document.body.appendChild(a);
      a.click();
      a.remove();
      URL.revokeObjectURL(objectUrl);
    });
}

// ---- Monthly / yearly reports ----

export function useMonthlyReport(date: string | undefined) {
  return useQuery({
    queryKey: date ? qk.monthly(date) : ["monthly", "none"],
    queryFn: () => api.get<MonthlyReport>(`/api/reports/monthly?date=${date}`),
    enabled: !!date,
  });
}

export function useYearlyReport(year: number | undefined) {
  return useQuery({
    queryKey: year ? qk.yearly(year) : ["yearly", "none"],
    queryFn: () => api.get<YearlyReport>(`/api/reports/yearly?year=${year}`),
    enabled: !!year,
  });
}

export function useStudentReport(
  studentId: string | undefined,
  from: string | undefined,
  to: string | undefined
) {
  return useQuery({
    queryKey: ["studentReport", studentId, from, to],
    queryFn: () =>
      api.get<StudentReport>(
        `/api/reports/student?studentId=${studentId}&from=${from}&to=${to}`
      ),
    enabled: !!studentId && !!from && !!to,
  });
}

// ---- Monthly prepayments ----

export function useMonthlyPayments(month: string | undefined) {
  return useQuery({
    queryKey: month ? qk.monthlyPayments(month) : ["monthlyPayments", "none"],
    queryFn: () =>
      api.get<MonthlyPayment[]>(`/api/monthly-payments?month=${month}`),
    enabled: !!month,
  });
}

export function useUpsertMonthlyPayment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (body: {
      studentId: string;
      month: string;
      lessonsCount: number;
      amount: number;
      paid?: boolean;
      comment?: string | null;
    }) => api.post<MonthlyPayment>("/api/monthly-payments", body),
    onSuccess: (_data, vars) => {
      qc.invalidateQueries({ queryKey: qk.monthlyPayments(vars.month) });
      qc.invalidateQueries({ queryKey: qk.students });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      qc.invalidateQueries({ queryKey: ["monthly"] });
      qc.invalidateQueries({ queryKey: ["yearly"] });
    },
  });
}

export function useDeleteMonthlyPayment() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: (id: string) => api.del(`/api/monthly-payments/${id}`),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["monthlyPayments"] });
      qc.invalidateQueries({ queryKey: qk.students });
      qc.invalidateQueries({ queryKey: qk.dashboard });
      qc.invalidateQueries({ queryKey: ["monthly"] });
      qc.invalidateQueries({ queryKey: ["yearly"] });
    },
  });
}

// ---- Tax reminder ----

export function useTaxReminder() {
  return useQuery({
    queryKey: qk.taxReminder,
    queryFn: () => api.get<TaxReminderStatus>("/api/tax-reminder"),
    refetchInterval: 60_000,
  });
}

export function useMarkTaxDone() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => api.post<{ ok: boolean }>("/api/tax-reminder/done"),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.taxReminder });
      qc.invalidateQueries({ queryKey: qk.dashboard });
    },
  });
}

export function useUndoTaxDone() {
  const qc = useQueryClient();
  return useMutation({
    mutationFn: () => api.post<{ ok: boolean }>("/api/tax-reminder/undo"),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: qk.taxReminder });
      qc.invalidateQueries({ queryKey: qk.dashboard });
    },
  });
}
