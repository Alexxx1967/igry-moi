import { NextResponse } from "next/server";
import { buildApkForOrigin } from "@/lib/apk-builder";

// GET /api/download/apk — returns a real, signed Android .apk that launches
// the tutor-assistant PWA at the current origin. The origin is resolved from
// the X-Forwarded-Host/Host headers (so it works through the gateway and is
// reachable from a phone). The APK is built on first request and cached per
// origin, so subsequent downloads are instant.
export async function GET(req: Request) {
  // Resolve the public origin — prefer forwarded host (set by the gateway),
  // fall back to the request's own host.
  const forwardedHost = req.headers.get("x-forwarded-host");
  const forwardedProto = req.headers.get("x-forwarded-proto") || "https";
  const host = forwardedHost || req.headers.get("host") || new URL(req.url).host;
  const origin = `${forwardedProto}://${host}`;

  try {
    const apk = buildApkForOrigin(origin);
    return new NextResponse(apk as unknown as BodyInit, {
      headers: {
        "Content-Type": "application/vnd.android.package-archive",
        "Content-Disposition": `attachment; filename="tutor-assistant.apk"`,
        "Cache-Control": "public, max-age=3600",
      },
    });
  } catch (e) {
    return NextResponse.json(
      {
        error:
          "Не удалось собрать APK: " +
          (e as Error).message +
          ". Используйте установку через Chrome (меню → Установить приложение) или pwabuilder.com.",
      },
      { status: 500 }
    );
  }
}
