import { NextRequest, NextResponse } from "next/server";
import { getSettings, saveSettings } from "@/lib/report";

export async function GET() {
  const settings = await getSettings();
  return NextResponse.json(settings);
}

export async function PUT(req: NextRequest) {
  const body = await req.json();
  await saveSettings(body);
  const settings = await getSettings();
  return NextResponse.json(settings);
}
