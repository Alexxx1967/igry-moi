import { NextRequest, NextResponse } from "next/server";
import { parseScheduleText, expandRecurring } from "@/lib/llm";
import { getSettings } from "@/lib/report";
import { todayInTZ } from "@/lib/tz";

// POST /api/parse-schedule  { text }  -> ParsedLesson[] (recurring expanded)
export async function POST(req: NextRequest) {
  const body = await req.json();
  const text: string = body?.text ?? "";
  if (!text.trim()) {
    return NextResponse.json({ error: "Пустой текст" }, { status: 400 });
  }
  const settings = await getSettings();
  const refDate = todayInTZ(settings.timezone);
  const parsed = await parseScheduleText(text, refDate);
  const expanded = expandRecurring(parsed, refDate);
  return NextResponse.json({
    lessons: expanded,
    rawCount: parsed.length,
    expandedCount: expanded.length,
  });
}
