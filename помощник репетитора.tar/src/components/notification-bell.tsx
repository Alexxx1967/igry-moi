"use client";

import { useState, useRef, useEffect } from "react";
import { Bell, BellOff, Check, X, Settings2, BellRing } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { useNotifications } from "@/lib/use-notifications";

type Props = {
  onNavigate?: (section: string) => void;
};

/** Bell icon with unread badge + dropdown showing recent notifications. */
export function NotificationBell({ onNavigate }: Props) {
  const {
    supported,
    permission,
    enabled,
    requestPermission,
    toggleEnabled,
    recent,
    unread,
    markAllRead,
    shares,
    openShare,
    dismissShare,
  } = useNotifications();
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    function onDocClick(e: MouseEvent) {
      if (ref.current && !ref.current.contains(e.target as Node)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", onDocClick);
    return () => document.removeEventListener("mousedown", onDocClick);
  }, []);

  if (!supported) {
    return (
      <span
        className="hidden h-9 w-9 items-center justify-center text-muted-foreground sm:flex"
        title="Оповещения не поддерживаются этим браузером"
      >
        <BellOff className="h-4 w-4" />
      </span>
    );
  }

  const needsPermission = permission !== "granted";
  const totalPending = unread + shares.length;

  async function handleBellClick() {
    // If permission not granted AND no shares pending, request permission.
    if (needsPermission && shares.length === 0 && recent.length === 0) {
      await requestPermission();
      return;
    }
    setOpen((v) => !v);
    if (unread > 0) markAllRead();
  }

  return (
    <div className="relative" ref={ref}>
      <Button
        variant="ghost"
        size="icon"
        className="relative h-9 w-9"
        onClick={handleBellClick}
        aria-label="Оповещения"
      >
        {enabled && !needsPermission ? (
          <BellRing className="h-4 w-4 text-emerald-600" />
        ) : (
          <Bell className="h-4 w-4" />
        )}
        {totalPending > 0 && (
          <span className="absolute -right-0.5 -top-0.5 flex h-4 min-w-4 items-center justify-center rounded-full bg-rose-500 px-1 text-[10px] font-bold text-white">
            {totalPending > 9 ? "9+" : totalPending}
          </span>
        )}
        {enabled && !needsPermission && (
          <span className="absolute bottom-1 right-1 h-2 w-2 rounded-full bg-emerald-500 ring-2 ring-background" />
        )}
      </Button>

      {open && (
        <div className="absolute right-0 top-11 z-50 w-80 overflow-hidden rounded-xl border bg-popover shadow-lg">
          <div className="flex items-center justify-between border-b px-3 py-2">
            <span className="flex items-center gap-1.5 text-sm font-medium">
              <Bell className="h-4 w-4" /> Оповещения
            </span>
            <div className="flex items-center gap-1">
              <button
                onClick={() => toggleEnabled(!enabled)}
                className={cn(
                  "flex items-center gap-1 rounded-md px-2 py-1 text-xs font-medium transition",
                  enabled
                    ? "text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-500/10"
                    : "text-muted-foreground hover:bg-muted"
                )}
                title={enabled ? "Включены" : "Выключены"}
              >
                {enabled ? <Check className="h-3.5 w-3.5" /> : <X className="h-3.5 w-3.5" />}
                {enabled ? "Вкл" : "Выкл"}
              </button>
            </div>
          </div>

          <div className="max-h-80 overflow-y-auto">
            {recent.length === 0 ? (
              <div className="flex flex-col items-center justify-center gap-2 py-8 text-center">
                <div className="flex h-10 w-10 items-center justify-center rounded-full bg-muted text-muted-foreground">
                  <Bell className="h-5 w-5" />
                </div>
                <p className="text-sm font-medium">Пока нет оповещений</p>
                <p className="text-xs text-muted-foreground">
                  Напоминания о занятиях, отчётах и налоговой появятся здесь.
                </p>
              </div>
            ) : (
              <div className="grid">
                {/* Pending shares (MAX / VK direct-link mode) */}
                {shares.length > 0 && (
                  <div className="border-b">
                    <div className="flex items-center justify-between px-3 py-1.5 bg-amber-50/60 dark:bg-amber-500/10">
                      <span className="text-[10px] font-semibold uppercase text-amber-700 dark:text-amber-300">
                        ⚡ Отправить в мессенджер
                      </span>
                    </div>
                    {shares.map((s, i) => (
                      <div
                        key={`${s.key}-${s.channel}-${i}`}
                        className="border-b px-3 py-2 last:border-0"
                      >
                        <p className="text-xs font-medium leading-tight">
                          {s.title}
                        </p>
                        <p className="text-[11px] text-muted-foreground line-clamp-2">
                          {s.body}
                        </p>
                        <div className="mt-1.5 flex items-center gap-1.5">
                          <button
                            onClick={() => openShare(s)}
                            className={cn(
                              "rounded-md px-2 py-1 text-[11px] font-medium text-white transition",
                              s.channel === "max"
                                ? "bg-amber-500 hover:bg-amber-600"
                                : "bg-sky-500 hover:bg-sky-600"
                            )}
                          >
                            {s.channel === "max" ? "MAX" : "ВК"} → открыть
                          </button>
                          <button
                            onClick={() => dismissShare(s.key, s.channel)}
                            className="rounded-md px-2 py-1 text-[11px] text-muted-foreground hover:bg-muted"
                          >
                            ×
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
                {/* Recent notifications */}
                {recent.map((n, i) => (
                  <button
                    key={`${n.key}-${i}`}
                    onClick={() => {
                      setOpen(false);
                      if (n.url) {
                        const u = new URL(n.url, window.location.origin);
                        const section = u.searchParams.get("section");
                        if (section && onNavigate) onNavigate(section);
                      }
                    }}
                    className="flex items-start gap-2 border-b px-3 py-2 text-left transition last:border-0 hover:bg-muted/50"
                  >
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium leading-tight">
                        {n.title}
                      </p>
                      <p className="text-xs text-muted-foreground line-clamp-2">
                        {n.body}
                      </p>
                    </div>
                  </button>
                ))}
              </div>
            )}
          </div>

          {needsPermission && (
            <div className="border-t bg-amber-50/60 p-3 dark:bg-amber-500/10">
              <p className="mb-2 text-xs text-amber-800 dark:text-amber-300">
                Разрешите оповещения, чтобы получать напоминания о занятиях и
                отчётах.
              </p>
              <Button
                size="sm"
                className="h-7 w-full bg-emerald-600 hover:bg-emerald-700"
                onClick={requestPermission}
              >
                <Settings2 className="mr-1 h-3.5 w-3.5" /> Разрешить оповещения
              </Button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
