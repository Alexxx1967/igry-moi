// Timezone & date helpers. All lesson dates/times are stored as wall-clock
// strings in the tutor's timezone, so we need helpers to interpret "now".

import {
  MONTHS_RU_GEN,
  MONTHS_RU_NOM,
  WEEKDAYS_RU,
  WEEKDAYS_RU_SHORT,
} from "./constants";

/** Pad a number to 2 digits. */
export function pad2(n: number): string {
  return String(n).padStart(2, "0");
}

/** Format a Date as YYYY-MM-DD using the given IANA timezone. */
export function formatDateTZ(date: Date, timeZone: string): string {
  const parts = new Intl.DateTimeFormat("en-CA", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
  }).formatToParts(date);
  const y = parts.find((p) => p.type === "year")!.value;
  const m = parts.find((p) => p.type === "month")!.value;
  const d = parts.find((p) => p.type === "day")!.value;
  return `${y}-${m}-${d}`;
}

/** Current wall-clock time in the tutor's timezone as components. */
export function nowInTZ(timeZone: string): {
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  weekday: number; // 0 (Sun) - 6 (Sat)
  hour: number;
  minute: number;
  timestamp: number;
} {
  const now = new Date();
  const fmt = new Intl.DateTimeFormat("en-GB", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    weekday: "short",
    hour12: false,
  });
  const parts = fmt.formatToParts(now);
  const get = (t: string) => parts.find((p) => p.type === t)!.value;
  const y = get("year");
  const m = get("month");
  const d = get("day");
  const hourStr = get("hour");
  const minStr = get("minute");
  const weekdayShort = get("weekday"); // e.g. "Mon"

  const hour = parseInt(hourStr === "24" ? "0" : hourStr, 10);
  const minute = parseInt(minStr, 10);

  // Map short weekday to 0-6 (Sun-Sat)
  const weekdayMap: Record<string, number> = {
    Sun: 0,
    Mon: 1,
    Tue: 2,
    Wed: 3,
    Thu: 4,
    Fri: 5,
    Sat: 6,
  };

  return {
    date: `${y}-${m}-${d}`,
    time: `${pad2(hour)}:${pad2(minute)}`,
    weekday: weekdayMap[weekdayShort] ?? 0,
    hour,
    minute,
    timestamp: now.getTime(),
  };
}

/**
 * Convert a wall-clock date+time in the tutor's timezone into a UTC epoch ms.
 * Used to compute "minutes until lesson".
 */
export function tzDateTimeToEpoch(
  dateStr: string,
  timeStr: string,
  timeZone: string
): number {
  // Build a UTC date from the wall-clock parts, then correct for the offset
  // of the target timezone at that instant.
  const [y, m, d] = dateStr.split("-").map(Number);
  const [hh, mm] = timeStr.split(":").map(Number);
  const asUtc = Date.UTC(y, (m ?? 1) - 1, d ?? 1, hh ?? 0, mm ?? 0, 0);

  // Compute the timezone offset at that UTC instant (in minutes).
  const dtf = new Intl.DateTimeFormat("en-US", {
    timeZone,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false,
  });
  const parts = dtf.formatToParts(new Date(asUtc));
  const get = (t: string) =>
    parseInt(parts.find((p) => p.type === t)!.value, 10);
  const tzY = get("year");
  const tzM = get("month");
  const tzD = get("day");
  const tzH = get("hour") === 24 ? 0 : get("hour");
  const tzMin = get("minute");
  const tzS = get("second");
  const tzAsUtc = Date.UTC(tzY, tzM - 1, tzD, tzH, tzMin, tzS);
  const offsetMs = tzAsUtc - asUtc; // how far ahead the TZ is from UTC

  return asUtc - offsetMs;
}

/** Minutes from "now" until a lesson's start (can be negative). */
export function minutesUntilLesson(
  dateStr: string,
  timeStr: string,
  timeZone: string,
  fromMs: number = Date.now()
): number {
  const lessonEpoch = tzDateTimeToEpoch(dateStr, timeStr, timeZone);
  return Math.round((lessonEpoch - fromMs) / 60000);
}

/** Add days to a YYYY-MM-DD string. */
export function addDays(dateStr: string, days: number): string {
  const [y, m, d] = dateStr.split("-").map(Number);
  const base = new Date(Date.UTC(y, (m ?? 1) - 1, d ?? 1));
  base.setUTCDate(base.getUTCDate() + days);
  return `${base.getUTCFullYear()}-${pad2(base.getUTCMonth() + 1)}-${pad2(
    base.getUTCDate()
  )}`;
}

/** Weekday index (0=Sun..6=Sat) for a YYYY-MM-DD string. */
export function weekdayOf(dateStr: string): number {
  const [y, m, d] = dateStr.split("-").map(Number);
  return new Date(Date.UTC(y, (m ?? 1) - 1, d ?? 1)).getUTCDay();
}

/** Monday-based index (0=Mon..6=Sun). */
export function weekdayMondayBased(dateStr: string): number {
  const w = weekdayOf(dateStr);
  return (w + 6) % 7;
}

/** Format YYYY-MM-DD as "10 июня 2026". */
export function formatLongDate(dateStr: string): string {
  const [y, m, d] = dateStr.split("-").map(Number);
  return `${d} ${MONTHS_RU_GEN[(m ?? 1) - 1]} ${y}`;
}

/** Format YYYY-MM-DD as "10.06.2026". */
export function formatShortDate(dateStr: string): string {
  const [y, m, d] = dateStr.split("-");
  return `${d}.${m}.${y}`;
}

/** Format YYYY-MM-DD as "10 июня". */
export function formatDayMonth(dateStr: string): string {
  const [, m, d] = dateStr.split("-").map(Number);
  return `${d} ${MONTHS_RU_GEN[(m ?? 1) - 1]}`;
}

/** Month nominative name + year, e.g. "Июнь 2026". */
export function monthYearLabel(dateStr: string): string {
  const [y, m] = dateStr.split("-").map(Number);
  return `${MONTHS_RU_NOM[(m ?? 1) - 1]} ${y}`;
}

/** Weekday name for a date string. */
export function weekdayName(dateStr: string): string {
  return WEEKDAYS_RU[weekdayMondayBased(dateStr)];
}

/** Weekday short name for a date string. */
export function weekdayShort(dateStr: string): string {
  return WEEKDAYS_RU_SHORT[weekdayMondayBased(dateStr)];
}

/** Returns the Monday of the week containing dateStr as YYYY-MM-DD. */
export function startOfWeek(dateStr: string): string {
  const wd = weekdayMondayBased(dateStr);
  return addDays(dateStr, -wd);
}

/** Compute end time "HH:MM" from start + duration. */
export function endTime(timeStart: string, durationMinutes: number): string {
  const [hh, mm] = timeStart.split(":").map(Number);
  const total = (hh ?? 0) * 60 + (mm ?? 0) + durationMinutes;
  const h = Math.floor(total / 60) % 24;
  const m = total % 60;
  return `${pad2(h)}:${pad2(m)}`;
}

/** Human-readable relative time in Russian, e.g. "через 2 ч 15 мин". */
export function relativeFromMinutes(minutes: number): string {
  if (minutes < 0) {
    const abs = Math.abs(minutes);
    if (abs < 60) return `${abs} мин назад`;
    const h = Math.floor(abs / 60);
    const m = abs % 60;
    return m ? `${h} ч ${m} мин назад` : `${h} ч назад`;
  }
  if (minutes < 60) return `через ${minutes} мин`;
  const h = Math.floor(minutes / 60);
  const m = minutes % 60;
  return m ? `через ${h} ч ${m} мин` : `через ${h} ч`;
}

/** Today's date string in the given timezone. */
export function todayInTZ(timeZone: string): string {
  return nowInTZ(timeZone).date;
}

/** Format a price as "1 500 ₽". */
export function formatMoney(amount: number): string {
  return `${amount.toLocaleString("ru-RU")} ₽`;
}

/** Is dateStr today? */
export function isSameDay(a: string, b: string): boolean {
  return a === b;
}

// ---- Month / year helpers ----

/** Extract YYYY-MM from a YYYY-MM-DD string. */
export function monthOf(dateStr: string): string {
  return dateStr.slice(0, 7);
}

/** First day of the month (YYYY-MM-DD) for a given YYYY-MM or YYYY-MM-DD. */
export function startOfMonth(monthOrDate: string): string {
  const [y, m] = monthOrDate.slice(0, 7).split("-").map(Number);
  return `${y}-${pad2(m ?? 1)}-01`;
}

/** Last day of the month (YYYY-MM-DD) for a given YYYY-MM or YYYY-MM-DD. */
export function endOfMonth(monthOrDate: string): string {
  const [y, m] = monthOrDate.slice(0, 7).split("-").map(Number);
  // day 0 of next month = last day of current month
  const last = new Date(Date.UTC(y, (m ?? 1), 0)).getUTCDate();
  return `${y}-${pad2(m ?? 1)}-${pad2(last)}`;
}

/** Next month as YYYY-MM given a YYYY-MM. */
export function nextMonth(monthStr: string): string {
  const [y, m] = monthStr.split("-").map(Number);
  const d = new Date(Date.UTC(y, (m ?? 1) - 1, 1));
  d.setUTCMonth(d.getUTCMonth() + 1);
  return `${d.getUTCFullYear()}-${pad2(d.getUTCMonth() + 1)}`;
}

/** Previous month as YYYY-MM given a YYYY-MM. */
export function prevMonth(monthStr: string): string {
  const [y, m] = monthStr.split("-").map(Number);
  const d = new Date(Date.UTC(y, (m ?? 1) - 1, 1));
  d.setUTCMonth(d.getUTCMonth() - 1);
  return `${d.getUTCFullYear()}-${pad2(d.getUTCMonth() + 1)}`;
}

/** Label "Сентябрь 2026" for a YYYY-MM. */
export function monthLabel(monthStr: string): string {
  const [y, m] = monthStr.split("-").map(Number);
  return `${MONTHS_RU_NOM[(m ?? 1) - 1]} ${y}`;
}

/** Short label "сен 2026" for a YYYY-MM. */
export function monthShortLabel(monthStr: string): string {
  const [y, m] = monthStr.split("-").map(Number);
  const gen = MONTHS_RU_GEN[(m ?? 1) - 1];
  return `${gen.slice(0, 3)} ${y}`;
}

/** All weeks (Mon–Sun) that overlap a month, as {label, start, end}. */
export function monthWeeks(monthStr: string): { label: string; start: string; end: string }[] {
  const start = startOfMonth(monthStr);
  const end = endOfMonth(monthStr);
  const weeks: { label: string; start: string; end: string }[] = [];
  let cursor = startOfWeek(start);
  let idx = 1;
  while (cursor <= end) {
    const wEnd = addDays(cursor, 6);
    weeks.push({
      label: `Неделя ${idx}`,
      start: cursor < start ? start : cursor,
      end: wEnd > end ? end : wEnd,
    });
    cursor = addDays(wEnd, 1);
    idx += 1;
  }
  return weeks;
}

/** Is the given YYYY-MM-DD the last day of its month? */
export function isLastDayOfMonth(dateStr: string): boolean {
  return dateStr === endOfMonth(dateStr);
}

/** All 12 months of a given year as YYYY-MM. */
export function monthsOfYear(year: number): string[] {
  return Array.from({ length: 12 }, (_, i) => `${year}-${pad2(i + 1)}`);
}
