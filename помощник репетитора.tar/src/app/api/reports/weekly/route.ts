import { NextRequest, NextResponse } from "next/server";
import { buildWeeklyReport, getSettings } from "@/lib/report";
import { todayInTZ } from "@/lib/tz";

// GET /api/reports/weekly?date=YYYY-MM-DD (defaults to today; report covers the week containing that date)
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const settings = await getSettings();
  const date = searchParams.get("date") ?? todayInTZ(settings.timezone);
  const report = await buildWeeklyReport(date);
  return NextResponse.json(report);
}
