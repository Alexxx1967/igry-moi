"use client";

import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/query-client";
import { ThemeProvider } from "@/components/theme-provider";
import { useSyncTabs } from "@/lib/use-sync-tabs";

function SyncManager() {
  useSyncTabs();
  return null;
}

export function Providers({ children }: { children: React.ReactNode }) {
  return (
    <ThemeProvider
      attribute="class"
      defaultTheme="light"
      enableSystem={false}
      disableTransitionOnChange
    >
      <QueryClientProvider client={queryClient}>
        <SyncManager />
        {children}
      </QueryClientProvider>
    </ThemeProvider>
  );
}
