import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";
import { generateStudentPaymentReminder } from "@/lib/llm";
import { getSettings } from "@/lib/report";

// POST /api/reminder  { lessonId }  -> AI-generated soft reminder text for the student
export async function POST(req: NextRequest) {
  const body = await req.json();
  const lessonId: string | undefined = body?.lessonId;
  if (!lessonId) {
    return NextResponse.json({ error: "Укажите lessonId" }, { status: 400 });
  }
  const lesson = await db.lesson.findUnique({
    where: { id: lessonId },
    include: { student: true },
  });
  if (!lesson) {
    return NextResponse.json({ error: "Занятие не найдено" }, { status: 404 });
  }
  const settings = await getSettings();
  const typed = {
    id: lesson.id,
    date: lesson.date,
    timeStart: lesson.timeStart,
    durationMinutes: lesson.durationMinutes,
    studentId: lesson.studentId,
    student: {
      id: lesson.student.id,
      name: lesson.student.name,
      color: lesson.student.color,
      phone: lesson.student.phone,
    },
    subject: lesson.subject,
    format: lesson.format,
    link: lesson.link,
    price: lesson.price,
    paidAmount: lesson.paidAmount,
    lessonStatus: lesson.lessonStatus,
    paymentStatus: lesson.paymentStatus,
    comment: lesson.comment,
    createdAt: lesson.createdAt.toISOString(),
    updatedAt: lesson.updatedAt.toISOString(),
  };
  const text = await generateStudentPaymentReminder(typed, settings.tutorName);
  return NextResponse.json({ text });
}
