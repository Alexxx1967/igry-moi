import { NextRequest, NextResponse } from "next/server";
import { buildYearlyReport, getSettings } from "@/lib/report";
import { todayInTZ } from "@/lib/tz";

// GET /api/reports/yearly?year=YYYY (defaults to current year)
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const settings = await getSettings();
  const today = todayInTZ(settings.timezone);
  const yearStr = searchParams.get("year");
  const year = yearStr ? Number(yearStr) : Number(today.slice(0, 4));
  const report = await buildYearlyReport(year);
  return NextResponse.json(report);
}
