import { NextRequest, NextResponse } from "next/server";
import { getSettings } from "@/lib/report";
import { buildDailyReport } from "@/lib/report";
import { todayInTZ } from "@/lib/tz";

// GET /api/reports/daily?date=YYYY-MM-DD (defaults to today)
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const settings = await getSettings();
  const date = searchParams.get("date") ?? todayInTZ(settings.timezone);
  const report = await buildDailyReport(date);
  return NextResponse.json(report);
}
