import { NextRequest, NextResponse } from "next/server";
import { buildStudentReport, getSettings } from "@/lib/report";
import { addDays, todayInTZ } from "@/lib/tz";

// GET /api/reports/student?studentId=...&from=YYYY-MM-DD&to=YYYY-MM-DD
// Returns a detailed report for one student over a custom period.
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const studentId = searchParams.get("studentId");
  const from = searchParams.get("from");
  const to = searchParams.get("to");

  if (!studentId) {
    return NextResponse.json({ error: "Укажите studentId" }, { status: 400 });
  }
  if (!from || !to) {
    return NextResponse.json(
      { error: "Укажите период (from и to)" },
      { status: 400 }
    );
  }

  try {
    const report = await buildStudentReport(studentId, from, to);
    return NextResponse.json(report);
  } catch (e) {
    return NextResponse.json({ error: (e as Error).message }, { status: 500 });
  }
}
