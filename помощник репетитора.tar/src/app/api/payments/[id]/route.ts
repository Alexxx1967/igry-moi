import { NextRequest, NextResponse } from "next/server";
import { db } from "@/lib/db";

const VALID_PAYMENT = [
  "paid",
  "unpaid",
  "partial",
  "awaiting_confirmation",
  "refund",
  "free_trial",
];

// PATCH /api/payments/[id]  { paymentStatus, paidAmount }
export async function PATCH(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  const { id } = await params;
  const body = await req.json();
  const existing = await db.lesson.findUnique({ where: { id } });
  if (!existing) return NextResponse.json({ error: "Не найдено" }, { status: 404 });

  const data: any = {};
  if (body.paymentStatus && VALID_PAYMENT.includes(body.paymentStatus)) {
    data.paymentStatus = body.paymentStatus;
    const ps = body.paymentStatus;
    if (ps === "paid") data.paidAmount = existing.price;
    else if (ps === "free_trial" || ps === "refund") data.paidAmount = 0;
    else if (ps === "unpaid") data.paidAmount = 0;
    else if (ps === "partial")
      data.paidAmount =
        body.paidAmount !== undefined ? Number(body.paidAmount) || 0 : existing.paidAmount;
  }
  if (body.paidAmount !== undefined) {
    const paid = Number(body.paidAmount) || 0;
    data.paidAmount = paid;
    if (paid >= existing.price) data.paymentStatus = "paid";
    else if (paid > 0) data.paymentStatus = "partial";
    else data.paymentStatus = "unpaid";
  }

  const updated = await db.lesson.update({
    where: { id },
    data,
    include: { student: true },
  });
  return NextResponse.json(updated);
}
