import { NextResponse } from "next/server";
import { getTaxReminderStatus } from "@/lib/report";

// GET /api/tax-reminder — current status (enabled, due, todayDone)
export async function GET() {
  const status = await getTaxReminderStatus();
  return NextResponse.json(status);
}
