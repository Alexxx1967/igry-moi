import { NextRequest, NextResponse } from "next/server";
import { buildYearlyReport, getSettings } from "@/lib/report";
import { buildReportDocx, textToSections } from "@/lib/docx-helpers";
import { todayInTZ } from "@/lib/tz";

// GET /api/reports/yearly/docx?year=YYYY
export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);
  const settings = await getSettings();
  const today = todayInTZ(settings.timezone);
  const yearStr = searchParams.get("year");
  const year = yearStr ? Number(yearStr) : Number(today.slice(0, 4));
  const report = await buildYearlyReport(year);
  const sections = textToSections(report.text);
  const buffer = await buildReportDocx(
    "Ежегодный отчёт",
    `${year} год · ${settings.timezone}`,
    sections
  );
  return new NextResponse(buffer as unknown as BodyInit, {
    headers: {
      "Content-Type":
        "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
      "Content-Disposition": `attachment; filename="yearly-${year}.docx"`,
    },
  });
}
