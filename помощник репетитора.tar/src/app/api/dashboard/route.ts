import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getSettings, getTaxReminderStatus } from "@/lib/report";
import { addDays, nowInTZ, todayInTZ, tzDateTimeToEpoch } from "@/lib/tz";
import { reminderTierFor } from "@/lib/reminders";
import { autorenewSchedule } from "@/lib/schedule-autorenew";
import type { LessonWithStudent } from "@/lib/types";

// GET /api/dashboard — aggregates today's lessons, upcoming reminders,
// debtors and quick stats for the dashboard. Also triggers auto-renewal of
// the schedule into the next month (idempotent).
export async function GET() {
  const settings = await getSettings();
  const tz = settings.timezone;
  const today = todayInTZ(tz);
  const now = nowInTZ(tz);

  // Auto-renew the schedule into the next month (idempotent, safe to call on
  // every dashboard load). Errors are swallowed — the dashboard must load.
  try {
    await autorenewSchedule();
  } catch {
    /* ignore */
  }

  const todayLessons = await db.lesson.findMany({
    where: { date: today },
    include: { student: true },
    orderBy: { timeStart: "asc" },
  });

  // Upcoming active reminders: planned/rescheduled lessons from today through +2 days
  const toDate = addDays(today, 2);
  const upcoming = await db.lesson.findMany({
    where: {
      date: { gte: today, lte: toDate },
      lessonStatus: { in: ["planned", "rescheduled"] },
    },
    include: { student: true },
    orderBy: [{ date: "asc" }, { timeStart: "asc" }],
  });

  const toTyped = (l: any): LessonWithStudent => ({
    id: l.id,
    date: l.date,
    timeStart: l.timeStart,
    durationMinutes: l.durationMinutes,
    studentId: l.studentId,
    student: {
      id: l.student.id,
      name: l.student.name,
      color: l.student.color,
      phone: l.student.phone,
    },
    subject: l.subject,
    format: l.format,
    link: l.link,
    price: l.price,
    paidAmount: l.paidAmount,
    lessonStatus: l.lessonStatus,
    paymentStatus: l.paymentStatus,
    comment: l.comment,
    createdAt: l.createdAt.toISOString(),
    updatedAt: l.updatedAt.toISOString(),
  });

  const remindersWithTier = upcoming
    .map(toTyped)
    .map((l) => {
      const epoch = tzDateTimeToEpoch(l.date, l.timeStart, tz);
      const minutes = Math.round((epoch - now.timestamp) / 60000);
      const tier = reminderTierFor(minutes, settings);
      return { lesson: l, minutes, tier };
    })
    .filter((r) => r.tier !== "none" && r.tier !== "past")
    .sort((a, b) => a.minutes - b.minutes);

  // Debtors (conducted but owing)
  const debtors = await db.lesson.findMany({
    where: {
      lessonStatus: "conducted",
      OR: [{ paymentStatus: "unpaid" }, { paymentStatus: "partial" }],
    },
    include: { student: true },
    orderBy: [{ date: "asc" }, { timeStart: "asc" }],
  });

  const debtTotal = debtors.reduce(
    (s, l) => s + Math.max(0, l.price - l.paidAmount),
    0
  );

  const todayConducted = todayLessons.filter(
    (l) => l.lessonStatus === "conducted"
  ).length;
  const todayPlanned = todayLessons.filter(
    (l) => l.lessonStatus === "planned" || l.lessonStatus === "rescheduled"
  ).length;
  const todayCancelled = todayLessons.filter(
    (l) => l.lessonStatus === "cancelled"
  ).length;

  const taxReminder = await getTaxReminderStatus();

  return NextResponse.json({
    today: todayLessons.map(toTyped),
    reminders: remindersWithTier.map((r) => ({
      lesson: r.lesson,
      minutes: r.minutes,
      tier: r.tier,
    })),
    debtors: debtors.map((l) => ({
      id: l.id,
      date: l.date,
      timeStart: l.timeStart,
      student: {
        id: l.student.id,
        name: l.student.name,
        color: l.student.color,
        phone: l.student.phone,
      },
      subject: l.subject,
      price: l.price,
      paidAmount: l.paidAmount,
      debt: Math.max(0, l.price - l.paidAmount),
      paymentStatus: l.paymentStatus,
    })),
    debtTotal,
    now: { date: now.date, time: now.time, weekday: now.weekday },
    todayStats: {
      total: todayLessons.length,
      conducted: todayConducted,
      planned: todayPlanned,
      cancelled: todayCancelled,
    },
    taxReminder,
  });
}
