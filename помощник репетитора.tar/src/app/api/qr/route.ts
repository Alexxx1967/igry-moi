import { NextResponse } from "next/server";
import QRCode from "qrcode";

// GET /api/qr?url=<url> — returns a PNG QR code pointing to the given URL.
// If no url is provided, points to the app root (for PWA install).
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const target = searchParams.get("url") || "/";
  // Resolve absolute URL based on request origin.
  const base = new URL(req.url).origin;
  const absolute = new URL(target, base).toString();
  try {
    const png = await QRCode.toBuffer(absolute, {
      type: "png",
      margin: 1,
      width: 480,
      color: { dark: "#059669", light: "#ffffff" },
    });
    return new NextResponse(png as unknown as BodyInit, {
      headers: {
        "Content-Type": "image/png",
        "Cache-Control": "public, max-age=86400",
      },
    });
  } catch (e) {
    return NextResponse.json(
      { error: "Не удалось сгенерировать QR-код" },
      { status: 500 }
    );
  }
}
