"use client";

import { useEffect, useState } from "react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import {
  LESSON_FORMATS,
  LESSON_STATUSES,
  LESSON_STATUS_LABELS,
  LESSON_FORMAT_LABELS,
  PAYMENT_STATUSES,
  PAYMENT_STATUS_LABELS,
  STUDENT_COLORS,
  type LessonFormat,
  type LessonStatus,
  type PaymentStatus,
} from "@/lib/constants";
import type { LessonWithStudent, StudentWithStats } from "@/lib/types";
import { useStudents, useCreateLesson, useUpdateLesson } from "@/lib/hooks";

type Props = {
  open: boolean;
  onOpenChange: (v: boolean) => void;
  lesson?: LessonWithStudent | null;
  defaultDate?: string;
  defaultStudentId?: string;
};

export function LessonFormDialog({
  open,
  onOpenChange,
  lesson,
  defaultDate,
  defaultStudentId,
}: Props) {
  const isEdit = !!lesson;
  const { data: students = [] } = useStudents();
  const createMut = useCreateLesson();
  const updateMut = useUpdateLesson();

  const [date, setDate] = useState("");
  const [timeStart, setTimeStart] = useState("15:00");
  const [duration, setDuration] = useState(60);
  const [studentId, setStudentId] = useState("");
  const [newStudentName, setNewStudentName] = useState("");
  const [creatingNew, setCreatingNew] = useState(false);
  const [subject, setSubject] = useState("");
  const [format, setFormat] = useState<LessonFormat>("online");
  const [link, setLink] = useState("");
  const [price, setPrice] = useState(1500);
  const [lessonStatus, setLessonStatus] = useState<LessonStatus>("planned");
  const [paymentStatus, setPaymentStatus] = useState<PaymentStatus>("unpaid");
  const [paidAmount, setPaidAmount] = useState(0);
  const [recurring, setRecurring] = useState(false);
  const [comment, setComment] = useState("");

  useEffect(() => {
    if (!open) return;
    if (lesson) {
      setDate(lesson.date);
      setTimeStart(lesson.timeStart);
      setDuration(lesson.durationMinutes);
      setStudentId(lesson.studentId);
      setCreatingNew(false);
      setNewStudentName("");
      setSubject(lesson.subject);
      setFormat(lesson.format as LessonFormat);
      setLink(lesson.link ?? "");
      setPrice(lesson.price);
      setLessonStatus(lesson.lessonStatus as LessonStatus);
      setPaymentStatus(lesson.paymentStatus as PaymentStatus);
      setPaidAmount(lesson.paidAmount);
      setRecurring(lesson.recurring === "weekly");
      setComment(lesson.comment ?? "");
    } else {
      setDate(defaultDate ?? "");
      setTimeStart("15:00");
      setDuration(60);
      setStudentId(defaultStudentId ?? "");
      setCreatingNew(!defaultStudentId && students.length === 0);
      setNewStudentName("");
      setSubject("");
      setFormat("online");
      setLink("");
      setPrice(1500);
      setLessonStatus("planned");
      setPaymentStatus("unpaid");
      setRecurring(false);
      setPaidAmount(0);
      setComment("");
    }
  }, [open, lesson, defaultDate, defaultStudentId, students.length]);

  // Auto-fill price from the selected student's pricePerLesson (only when not
  // editing an existing lesson and the student changes).
  useEffect(() => {
    if (isEdit || creatingNew) return;
    if (!studentId) return;
    const st = students.find((s) => s.id === studentId);
    if (st?.pricePerLesson != null) {
      setPrice(st.pricePerLesson);
    }
  }, [studentId, creatingNew, isEdit, students]);

  // Auto-adjust paidAmount when payment status changes
  useEffect(() => {
    if (paymentStatus === "paid") setPaidAmount(price);
    if (paymentStatus === "unpaid") setPaidAmount(0);
    if (paymentStatus === "free_trial" || paymentStatus === "refund") setPaidAmount(0);
  }, [paymentStatus, price]);

  const canSubmit =
    date &&
    timeStart &&
    subject &&
    (creatingNew ? newStudentName.trim() : studentId);

  function handleSubmit() {
    if (!canSubmit) {
      toast.error("Заполните дату, время, предмет и ученика");
      return;
    }
    const body = {
      date,
      timeStart,
      durationMinutes: duration,
      studentId: creatingNew ? undefined : studentId,
      studentName: creatingNew ? newStudentName.trim() : undefined,
      subject: subject.trim(),
      format,
      link: link.trim() || null,
      price: Number(price) || 0,
      paidAmount: Number(paidAmount) || 0,
      lessonStatus,
      paymentStatus,
      recurring: recurring ? "weekly" : null,
      comment: comment.trim() || null,
    };
    const action = isEdit
      ? updateMut.mutateAsync({ id: lesson!.id, body })
      : createMut.mutateAsync(body);
    action
      .then(() => {
        toast.success(isEdit ? "Занятие обновлено" : "Занятие добавлено");
        onOpenChange(false);
      })
      .catch((e: Error) => toast.error(e.message));
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[92vh] overflow-y-auto sm:max-w-[560px]">
        <DialogHeader>
          <DialogTitle>{isEdit ? "Редактировать занятие" : "Новое занятие"}</DialogTitle>
          <DialogDescription>
            {isEdit
              ? "Обновите данные занятия, статус или оплату."
              : "Заполните данные о занятии. Поля со звёздочкой обязательны."}
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 py-2">
          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="lf-date">Дата *</Label>
              <Input
                id="lf-date"
                type="date"
                value={date}
                onChange={(e) => setDate(e.target.value)}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="lf-time">Время начала *</Label>
              <Input
                id="lf-time"
                type="time"
                value={timeStart}
                onChange={(e) => setTimeStart(e.target.value)}
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="lf-dur">Длительность, мин</Label>
              <Select
                value={String(duration)}
                onValueChange={(v) => setDuration(Number(v))}
              >
                <SelectTrigger id="lf-dur">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {[30, 45, 60, 75, 90, 120].map((d) => (
                    <SelectItem key={d} value={String(d)}>
                      {d} мин
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="lf-format">Формат</Label>
              <Select
                value={format}
                onValueChange={(v) => setFormat(v as LessonFormat)}
              >
                <SelectTrigger id="lf-format">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LESSON_FORMATS.map((f) => (
                    <SelectItem key={f} value={f}>
                      {LESSON_FORMAT_LABELS[f]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid gap-1.5">
            <div className="flex items-center justify-between">
              <Label>Ученик *</Label>
              <div className="flex items-center gap-2">
                <span className="text-xs text-muted-foreground">Новый</span>
                <Switch
                  checked={creatingNew}
                  onCheckedChange={setCreatingNew}
                  disabled={isEdit}
                />
              </div>
            </div>
            {creatingNew ? (
              <Input
                placeholder="Имя и фамилия ученика"
                value={newStudentName}
                onChange={(e) => setNewStudentName(e.target.value)}
              />
            ) : (
              <Select value={studentId} onValueChange={setStudentId}>
                <SelectTrigger>
                  <SelectValue placeholder="Выберите ученика" />
                </SelectTrigger>
                <SelectContent>
                  {students.map((s: StudentWithStats) => (
                    <SelectItem key={s.id} value={s.id}>
                      {s.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            )}
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="lf-subject">Предмет *</Label>
            <Input
              id="lf-subject"
              placeholder="Напр. Английский язык"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
            />
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="lf-link">Ссылка на занятие</Label>
            <Input
              id="lf-link"
              placeholder="https://zoom.us/..."
              value={link}
              onChange={(e) => setLink(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="lf-price">Стоимость, ₽</Label>
              <Input
                id="lf-price"
                type="number"
                min={0}
                value={price}
                onChange={(e) => setPrice(Number(e.target.value))}
              />
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="lf-status">Статус занятия</Label>
              <Select
                value={lessonStatus}
                onValueChange={(v) => setLessonStatus(v as LessonStatus)}
              >
                <SelectTrigger id="lf-status">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {LESSON_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {LESSON_STATUS_LABELS[s]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="grid gap-1.5">
              <Label htmlFor="lf-pay">Статус оплаты</Label>
              <Select
                value={paymentStatus}
                onValueChange={(v) => setPaymentStatus(v as PaymentStatus)}
              >
                <SelectTrigger id="lf-pay">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PAYMENT_STATUSES.map((s) => (
                    <SelectItem key={s} value={s}>
                      {PAYMENT_STATUS_LABELS[s]}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-1.5">
              <Label htmlFor="lf-paid">Оплачено, ₽</Label>
              <Input
                id="lf-paid"
                type="number"
                min={0}
                value={paidAmount}
                disabled={
                  paymentStatus === "paid" ||
                  paymentStatus === "unpaid" ||
                  paymentStatus === "free_trial" ||
                  paymentStatus === "refund"
                }
                onChange={(e) => setPaidAmount(Number(e.target.value))}
              />
            </div>
          </div>

          <div className="grid gap-1.5">
            <Label htmlFor="lf-comment">Комментарий</Label>
            <Textarea
              id="lf-comment"
              rows={2}
              placeholder="Напр. оплата после занятия"
              value={comment}
              onChange={(e) => setComment(e.target.value)}
            />
          </div>

          <label className="flex cursor-pointer items-center gap-2.5 rounded-lg border p-3">
            <Checkbox
              checked={recurring}
              onCheckedChange={(v) => setRecurring(v === true)}
            />
            <div>
              <span className="text-sm font-medium">Повторять каждую неделю</span>
              <p className="text-xs text-muted-foreground">
                Создаст занятие на этот день недели (только это одно)
              </p>
            </div>
          </label>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            Отмена
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={!canSubmit || createMut.isPending || updateMut.isPending}
          >
            {isEdit ? "Сохранить" : "Добавить"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// Re-export for convenience
export { STUDENT_COLORS };
