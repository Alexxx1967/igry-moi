import { NextResponse } from "next/server";
import { undoTaxReminderDone } from "@/lib/report";

// POST /api/tax-reminder/undo — clear today's "done" mark
export async function POST() {
  await undoTaxReminderDone();
  return NextResponse.json({ ok: true });
}
