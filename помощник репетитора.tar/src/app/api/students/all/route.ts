import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// DELETE /api/students/all — removes ALL students (and their lessons +
// monthly payments via cascade). Used to clear the roster before loading
// a fresh list from Word. Returns counts of what was deleted.
export async function DELETE() {
  // Count before delete for the response.
  const [studentCount, lessonCount, paymentCount] = await Promise.all([
    db.student.count(),
    db.lesson.count(),
    db.monthlyPayment.count(),
  ]);
  // MonthlyPayment & Lesson cascade on student delete, but to be safe and
  // avoid FK issues, delete lessons + payments first, then students.
  await db.monthlyPayment.deleteMany();
  await db.lesson.deleteMany();
  await db.student.deleteMany();
  return NextResponse.json({
    ok: true,
    deleted: {
      students: studentCount,
      lessons: lessonCount,
      monthlyPayments: paymentCount,
    },
  });
}
